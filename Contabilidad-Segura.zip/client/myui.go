package main

import (
	"bytes"
	"html/template"
	"net/url"
	"path/filepath"
	"strings"

	"./models"
	"github.com/zserge/lorca"
)

const indexTemplate = "./www/index.html"
const registerSuperTemplate = "./www/registerSuper.html"
const adminTemplate = "./www/managePermission.html"
const headerTemplate = "./www/header.html"
const headerIndexTemplate = "./www/headerIndex.html"
const headerAdminTemplate = "./www/headerAdmin.html"
const clientFormsTemplate = "./www/js/clientForms.js"

//MyUI is an struct to be able to charge views from javascript
type MyUI struct {
	ui lorca.UI
	c  models.Client
}

func (myui *MyUI) chargeView(filePath string) {
	tmpl := template.New("template")
	var err error

	if filePath == indexTemplate || filePath == registerSuperTemplate {
		tmpl, err = template.ParseFiles(filePath, headerIndexTemplate, clientFormsTemplate)
	} else if strings.Contains(filePath, "manage") {
		tmpl, err = template.ParseFiles(filePath, headerAdminTemplate, clientFormsTemplate)
	} else {
		tmpl, err = template.ParseFiles(filePath, headerTemplate, clientFormsTemplate)
	}
	if err != nil {
		panic(err)
	}

	buff := bytes.Buffer{}

	path := filePath
	file := filepath.Base(path)

	err = tmpl.ExecuteTemplate(&buff, file, nil)
	if err != nil {
		panic(err)
	}

	myui.ui.Load("data:text/html," + url.PathEscape(string(buff.Bytes())))
}
func (myui *MyUI) chargeView2(filePath string, id string) {

	tmpl := template.New("template")
	var err error

	if filePath == indexTemplate || filePath == registerSuperTemplate {
		tmpl, err = template.ParseFiles(filePath, headerIndexTemplate, clientFormsTemplate)
	} else if strings.Contains(filePath, "manage") {
		tmpl, err = template.ParseFiles(filePath, headerAdminTemplate, clientFormsTemplate)
	} else {
		tmpl, err = template.ParseFiles(filePath, headerTemplate, clientFormsTemplate)
	}
	if err != nil {
		panic(err)
	}

	buff := bytes.Buffer{}

	path := filePath
	file := filepath.Base(path)
	content := map[string]string{"id": id}

	err = tmpl.ExecuteTemplate(&buff, file, content)
	if err != nil {
		panic(err)
	}

	myui.ui.Load("data:text/html," + url.PathEscape(string(buff.Bytes())))
}

//Date is needed to show the date of the backups
type Date struct {
	Date string
}

func (myui *MyUI) chargeViewWithParam(filePath string, id int) {

	tmpl, err := template.ParseFiles(filePath)
	if err != nil {
		panic(err)
	}

	buff := bytes.Buffer{}

	err = tmpl.Execute(&buff, id)
	if err != nil {
		panic(err)
	}
	myui.ui.Load("data:text/html," + url.PathEscape(string(buff.Bytes())))
}
