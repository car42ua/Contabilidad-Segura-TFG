package main

import (
	"fmt"
	"os"
	"os/signal"
	"runtime"

	"./models"

	"github.com/zserge/lorca"
)

func main() {
	c := models.Client{}
	args := []string{}

	if runtime.GOOS == "linux" {
		args = append(args, "--class=Lorca")
	}

	ui, err := lorca.New("", "", 1200, 700, args...)
	if err != nil {
		panic(err)
	}
	defer ui.Close()
	myui := MyUI{ui, c}

	myui.chargeView("./www/index.html")
	ui.Bind("chargeView", myui.chargeView)
	ui.Bind("chargeView2", myui.chargeView2)

	ui.Bind("SignIn", myui.c.SignIn)
	ui.Bind("SignUp", myui.c.SignUp)
	ui.Bind("SignModify", myui.c.SignModify)
	ui.Bind("ModifySuper", myui.c.ModifySuper)
	ui.Bind("GetToken", myui.c.GetToken)
	ui.Bind("Logout", myui.c.Logout)
	ui.Bind("GetDNI", myui.c.GetDNI)
	ui.Bind("RefreshToken", myui.c.RefreshToken)
	// Bind of simple table Cruds
	ui.Bind("GetRows", myui.c.GetRows)
	ui.Bind("GetRowsByParcialID", myui.c.GetRowsByParcialID)
	ui.Bind("GetRow", myui.c.GetRow)
	ui.Bind("CreateRow", myui.c.CreateRow)
	ui.Bind("CreateCompany", myui.c.CreateCompany)
	ui.Bind("ModifyRow", myui.c.ModifyRow)
	ui.Bind("DeleteRow", myui.c.DeleteRow)
	ui.Bind("GetStructure", myui.c.GetStructure)
	ui.Bind("GetCount", myui.c.GetCount)
	ui.Bind("CreatePDF", myui.c.CreatePDF)
	ui.Bind("PermissionCompany", myui.c.PermissionCompany)
	// Wait until the interrupt signal arrives or browser window is closed
	sigc := make(chan os.Signal)
	signal.Notify(sigc, os.Interrupt)
	select {
	case <-sigc:
	case <-ui.Done():
	}

	fmt.Println("exiting...")
}
