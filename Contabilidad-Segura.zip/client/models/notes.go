package models

import (
	"bytes"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"

	"../utils"
)

type respDataNote struct {
	Ok        bool
	Msg       string
	Structure []SeatNoteEnc
}

//SeatNote is the struct merge Note and Seat to response from the server
type SeatNote struct {
	ID           int     `json:"id"`
	Seat         int     `json:"seat"`
	Journal      int     `json:"journal"`
	Account      int     `json:"account"`
	Company      int     `json:"company"`
	Concept      int     `json:"concept"`
	Amount       float64 `json:"amount"`
	DC           string  `json:"dc"`
	Section      int     `json:"section"`
	TitleSection string  `json:"titlesection"`
	TitleConcept string  `json:"titleconcept"`
	SeatDate     string  `json:"seatdate"`
	TitleAccount string  `json:"titleaccount"`
}

//SeatNoteEnc is the struct with encrypt data to send the note to server
type SeatNoteEnc struct {
	ID           int    `json:"id"`
	Seat         int    `json:"seat"`
	Journal      int    `json:"journal"`
	Account      int    `json:"account"`
	Company      int    `json:"company"`
	Concept      int    `json:"concept"`
	Amount       []byte `json:"amount"`
	DC           []byte `json:"dc"`
	Section      int    `json:"section"`
	TitleSection string `json:"titlesection"`
	TitleConcept string `json:"titleconcept"`
	SeatDate     string `json:"seatdate"`
	TitleAccount string `json:"titleaccount"`
}

func moveDataSet(s SeatNote) SeatNoteEnc {
	ss := SeatNoteEnc{}

	ss.ID = s.ID
	ss.Seat = s.Seat
	ss.Journal = s.Journal
	ss.Account = s.Account
	ss.Concept = s.Concept
	ss.Company = s.Company
	ss.Section = s.Section
	ss.TitleSection = s.TitleSection
	ss.TitleConcept = s.TitleConcept
	ss.SeatDate = s.SeatDate
	ss.TitleAccount = s.TitleAccount

	return ss
}
func moveDataSetEnc(ss SeatNoteEnc) SeatNote {
	s := SeatNote{}

	s.ID = ss.ID
	s.Seat = ss.Seat
	s.Journal = ss.Journal
	s.Account = ss.Account
	s.Concept = ss.Concept
	s.Company = ss.Company
	s.Section = ss.Section
	s.TitleSection = ss.TitleSection
	s.TitleConcept = ss.TitleConcept
	s.SeatDate = ss.SeatDate
	s.TitleAccount = ss.TitleAccount

	return s
}
func (c *Client) encryptDataNote(company int, structure interface{}) ([]byte, error) {
	var response []byte
	//First. we download the permissions and company keys and data

	permission, err := c.PermissionCompany(company)
	if err != nil {
		return response, err
	}
	encryptCompanyKey := permission.CompanyKey
	encryptDataKey := permission.DataKey
	//We decrypt the keys obtained with our private key
	companyKey, err := rsa.DecryptOAEP(sha256.New(), rand.Reader, c.privKey, encryptCompanyKey, nil)
	if err != nil {
		return response, err
	}
	dataKey, err := rsa.DecryptOAEP(sha256.New(), rand.Reader, c.privKey, encryptDataKey, nil)
	if err != nil {
		return response, err
	}
	//We obtain the public key to encrypt the channel
	pubKeyServer, err := c.getPublicKeyOfServer()
	if err != nil {
		return response, err
	}
	//And we encrypt this with the public key of the server
	encryptCompanyKey, err = rsa.EncryptOAEP(sha256.New(), rand.Reader, pubKeyServer, companyKey, nil)
	if err != nil {
		return response, err
	}
	//Finally we will prepare the note data to send it to the server.
	//We will encrypt with the Datakey using the AES algorithm the following fields of the note:
	//	- Amount
	//	- Debit/Credit

	//We cast the interface with the note structure saved by the server
	note := SeatNote{}
	marshallNote, err := json.Marshal(structure)
	if err != nil {
		return response, err
	}
	err = json.Unmarshal(marshallNote, &note)
	if err != nil {
		return response, err
	}

	//We transform the fields to [] byte and then encrypt them with the data key
	amount := utils.Float64bytes(note.Amount)
	dc := []byte(note.DC)

	amount, err = c.encrypt(amount, dataKey)
	if err != nil {
		return response, err
	}
	dc, err = c.encrypt(dc, dataKey)
	if err != nil {
		return response, err
	}

	//We move the data to a new structure in which we can store this information correctly to send it to the server
	noteWithEncData := moveDataSet(note)
	noteWithEncData.Amount = amount
	noteWithEncData.DC = dc
	//Finally we will create the structure with the company key

	structForSend := StructAndKey{
		Structure: noteWithEncData,
		Key:       encryptCompanyKey,
	}
	response, err = json.Marshal(structForSend)
	if err != nil {
		return response, err
	}

	return response, nil

}
func (c *Client) decryptDataNote(company int, structure *[]SeatNoteEnc) ([]SeatNote, error) {

	notesDecrypt := []SeatNote{}

	//First. we download the data key
	permission, err := c.PermissionCompany(company)
	if err != nil {
		return notesDecrypt, err
	}
	encryptDataKey := permission.DataKey

	dataKey, err := rsa.DecryptOAEP(sha256.New(), rand.Reader, c.privKey, encryptDataKey, nil)
	if err != nil {
		return notesDecrypt, err
	}
	fmt.Print("dataKey obtenida para descifrar contenido al crear compañia")
	fmt.Println(dataKey)

	//Later, we will process all the notes deciphering the content of Amount and DC
	for _, noteEnc := range *structure {
		note := moveDataSetEnc(noteEnc)
		amount, err := c.decrypt(noteEnc.Amount, dataKey)
		if err != nil {
			return notesDecrypt, err
		}
		note.Amount = utils.Float64frombytes(amount)
		fmt.Print(note.Amount)

		dc, err := c.decrypt(noteEnc.DC, dataKey)
		if err != nil {
			return notesDecrypt, err
		}
		note.DC = string(dc)

		fmt.Print(note.DC)
		notesDecrypt = append(notesDecrypt, note)
	}
	return notesDecrypt, nil
}


//CreateNote sends the interface to insert
func (c *Client) CreateNote(structure interface{}, company int) (utils.RespData, error) {

	response := utils.RespData{}
	var req *http.Request
	var err error

	requestBody, err := c.encryptDataNote(company, structure)
	req, err = http.NewRequest("POST", "https://localhost:9043/note/"+strconv.Itoa(company), bytes.NewBuffer(requestBody))

	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		return response, err
	}

	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)

	if err != nil {
		return response, err
	}
	err = json.Unmarshal(body, &response)

	if err != nil {
		return response, err
	}
	return response, nil
}

//ModifyNote sends the interface to update
func (c *Client) ModifyNote(structure interface{}, company int) (utils.RespData, error) {

	response := utils.RespData{}
	var req *http.Request
	var err error

	requestBody, err := c.encryptDataNote(company, structure)

	req, err = http.NewRequest("PUT", "https://localhost:9043/note/"+strconv.Itoa(company), bytes.NewBuffer(requestBody))

	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		log.Fatal(err)
	}
	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)

	if err != nil {
		return response, err
	}
	json.Unmarshal(body, &response)

	if err != nil {
		return response, err
	}
	return response, nil
}
