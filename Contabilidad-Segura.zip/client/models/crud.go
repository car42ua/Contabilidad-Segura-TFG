package models

import (
	"bytes"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"

	"../utils"
	"github.com/dgrijalva/jwt-go"
)

type User struct {
	DNI            string `json:"dni"`
	Name           string `json:"name"`
	Email          string `json:"email"`
	Role           string `json:"role"`
	PasswordHashed []byte `json:"pass"`
	Salt           []byte `json:"salt"`
	PubKey         []byte `json:"pubkey"`
	PrivKey        []byte `json:"privkey"`
}

//Permission is the struct of the table permission
type Permission struct {
	User            string `json:"user"`
	Company         int    `json:"company"`
	CompanyKey      []byte `json:"companykey"`
	DataKey         []byte `json:"datakey"`
	ReadPermission  bool   `json:"read_permission"`
	WritePermission bool   `json:"write_permission"`
}
type RespDataPermission struct {
	Ok        bool
	Msg       string
	Structure []Permission
}

//StructAndKey is the struct to use if the table need send the DatabaseKey
type StructAndKey struct {
	Structure interface{}
	Key       []byte
}

//StructAndKey is the struct to use if the table need send the DatabaseKey
type CompanyAndKeys struct {
	Company    interface{}
	CompanyKey []byte
	DataKey    []byte
}

func tableIsBase(table string) bool {
	isbase := true
	if table == "section" || table == "concept" || table == "account" ||
		table == "journal" || table == "seat" || table == "note" || table == "journalseat" {
		isbase = false
	}
	return isbase
}
// //PermissionCompany return the permission of the user/company to client
// func (c *Client) PermissionCompany(table string) (interface{}, error) {

// 	var response = utils.RespData{}

// 	req, err := http.NewRequest("GET", "https://localhost:9043/"+table+"_struct/", nil)
// 	req.Header.Add("Authorization", "Bearer "+c.token)

// 	if err != nil {
// 		log.Fatal(err)
// 	}
// 	res, err := c.httpclient.Do(req)

// 	if err != nil {
// 		log.Fatal(err)
// 	}
// 	defer res.Body.Close()
// 	//Unmarshal the response to a resp struct
// 	body, err := ioutil.ReadAll(res.Body)

// 	json.Unmarshal(body, &response)

// 	return response, nil
// }
func (c *Client) PermissionCompany(company int) (Permission, error) {
	//---------------------------------------------------------------------------------------------//
	//	1. We will obtain:
	//			The encrypted key of the connection to the database + the public key of the server
	//---------------------------------------------------------------------------------------------//
	response := Permission{}

	//Get the encrypted key of connection to the database
	permission := Permission{
		User:            c.dni,
		Company:         company,
		CompanyKey:      nil,
		DataKey:         nil,
		ReadPermission:  false,
		WritePermission: false,
	}
	fmt.Println(c.dni)
	fmt.Println(company)
	requestBody, err := json.Marshal(permission)
	if err != nil {
		return response, err
	}

	req, err := http.NewRequest("POST", "https://localhost:9043/permission_id/", bytes.NewBuffer(requestBody))
	req.Header.Add("Authorization", "Bearer "+c.token)
	if err != nil {
		return response, err
	}

	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}

	defer res.Body.Close()
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return response, err
	}

	err = json.Unmarshal(body, &response)
	if err != nil {
		return response, err
	}
	return response, nil
}
func (c *Client) getPublicKeyOfServer() (*rsa.PublicKey, error) {
	var key []byte
	var response *rsa.PublicKey

	//Get the public key from server
	req, err := http.NewRequest("GET", "https://localhost:9043/publickeyserver/", nil)
	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		return response, err
	}
	res, err := c.httpclient.Do(req)

	if err != nil {
		return response, err
	}
	defer res.Body.Close()
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return response, err
	}

	json.Unmarshal(body, &key)
	if err != nil {
		return response, err
	}

	response, err = jwt.ParseRSAPublicKeyFromPEM(key)
	if err != nil {
		fmt.Println("Error in ParsePKCS1PublicKey!!!" + err.Error())
		return response, err
	}
	return response, nil
}
func (c *Client) getPermissionKey(company int) ([]byte, error) {
	var key []byte

	permission, err := c.PermissionCompany(company)
	if err != nil {
		return key, err
	}
	companyKey := permission.CompanyKey

	pubKeyServer, err := c.getPublicKeyOfServer()

	key, err = rsa.DecryptOAEP(sha256.New(), rand.Reader, c.privKey, companyKey, nil)
	if err != nil {
		fmt.Println("Error in decrypt key!!!" + err.Error())
		panic(err)
	}

	key, err = rsa.EncryptOAEP(sha256.New(), rand.Reader, pubKeyServer, key, nil)
	if err != nil {
		fmt.Println("Error in encrypt key!!!" + err.Error())
		panic(err)
	}
	return key, nil
}

//GetStructure make a request to get the generic row
func (c *Client) GetStructure(table string) (interface{}, error) {

	var response = utils.RespData{}

	req, err := http.NewRequest("GET", "https://localhost:9043/"+table+"_struct/", nil)
	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		log.Fatal(err)
	}
	res, err := c.httpclient.Do(req)

	if err != nil {
		log.Fatal(err)
	}
	defer res.Body.Close()
	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)

	json.Unmarshal(body, &response)

	return response, nil
}

//GetRow make a request to get the generic row
func (c *Client) GetRow(structure interface{}, table string, company int) (interface{}, error) {
	var response = utils.RespData{}
	var req *http.Request
	var err error

	if company != 0 && !tableIsBase(table) {
		//First call to permission table to get the key of the database
		key, err := c.getPermissionKey(company)

		if err != nil {
			log.Fatal(err)
		}
		structKey := StructAndKey{
			Structure: structure,
			Key:       key,
		}
		requestBody, err := json.Marshal(structKey)
		if err != nil {
			return response, err
		}

		req, err = http.NewRequest("POST", "https://localhost:9043/"+table+"_id/"+strconv.Itoa(company), bytes.NewBuffer(requestBody))

	} else {
		requestBody, err := json.Marshal(structure)

		if err != nil {
			return response, err
		}
		req, err = http.NewRequest("POST", "https://localhost:9043/"+table+"_id/", bytes.NewBuffer(requestBody))
	}

	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		return response, err
	}
	res, err := c.httpclient.Do(req)

	if err != nil {
		return response, err
	}
	defer res.Body.Close()
	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return response, err
	}
	json.Unmarshal(body, &response)
	if err != nil {
		return response, err
	}

	return response, nil
}

//GetRows make a request to get the generic row
func (c *Client) GetRows(table string, company int) (interface{}, error) {

	var response = utils.RespData{}
	var req *http.Request
	var err error

	if company != 0 && !tableIsBase(table) {
		//First call to permission table to get the key of the database
		key, err := c.getPermissionKey(company)

		if err != nil {
			log.Fatal(err)
		}
		requestBody, err := json.Marshal(key)
		if err != nil {
			return response, err
		}

		req, err = http.NewRequest("POST", "https://localhost:9043/"+table+"_get/"+strconv.Itoa(company), bytes.NewBuffer(requestBody))

	} else {
		req, err = http.NewRequest("GET", "https://localhost:9043/"+table+"/", nil)
	}

	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		log.Fatal(err)
	}
	res, err := c.httpclient.Do(req)

	if err != nil {
		log.Fatal(err)
	}
	defer res.Body.Close()
	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)

	json.Unmarshal(body, &response)

	return response, nil
}

//GetRowsByParcialID make a request to get the generic rows by parcial ID(for multi primary key)
func (c *Client) GetRowsByParcialID(structure interface{}, table string, company int) (interface{}, error) {

	var response = utils.RespData{}
	var req *http.Request
	var err error

	if company != 0 && !tableIsBase(table) {
		//First call to permission table to get the key of the database
		key, err := c.getPermissionKey(company)

		if err != nil {
			log.Fatal(err)
		}
		structKey := StructAndKey{
			Structure: structure,
			Key:       key,
		}
		requestBody, err := json.Marshal(structKey)
		if err != nil {
			return response, err
		}

		req, err = http.NewRequest("POST", "https://localhost:9043/"+table+"_parcial_id/"+strconv.Itoa(company), bytes.NewBuffer(requestBody))

	} else {
		requestBody, err := json.Marshal(structure)

		if err != nil {
			return response, err
		}
		req, err = http.NewRequest("POST", "https://localhost:9043/"+table+"_parcial_id/", bytes.NewBuffer(requestBody))
	}
	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		return response, err
	}
	res, err := c.httpclient.Do(req)

	if err != nil {
		return response, err
	}
	defer res.Body.Close()
	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return response, err
	}
	if table == "note" {
		responseNote := respDataNote{}
		json.Unmarshal(body, &responseNote)
		if err != nil {
			return response, err
		}
		if responseNote.Ok {
			if len(responseNote.Structure) != 0 {
				note, err := c.decryptDataNote(company, &responseNote.Structure)
				if err != nil {
					return response, err
				}
				fmt.Println(note)
				response.Structure = note
			}
			response.Ok = true
			response.Msg = "Decrypt Note Successfully"
		} else {
			return response, err
		}
	} else {
		json.Unmarshal(body, &response)
		if err != nil {
			return response, err
		}
	}
	fmt.Println(response)
	return response, nil
}

//GetCount make a request to get the count of table
func (c *Client) GetCount(structure interface{}, table string, company int) (interface{}, error) {
	var response = utils.RespData{}
	var req *http.Request
	var err error

	if company != 0 && !tableIsBase(table) {
		//First call to permission table to get the key of the database
		key, err := c.getPermissionKey(company)

		if err != nil {
			log.Fatal(err)
		}
		structKey := StructAndKey{
			Structure: structure,
			Key:       key,
		}
		requestBody, err := json.Marshal(structKey)
		if err != nil {
			return response, err
		}

		req, err = http.NewRequest("POST", "https://localhost:9043/"+table+"_count/"+strconv.Itoa(company), bytes.NewBuffer(requestBody))

	} else {
		requestBody, err := json.Marshal(structure)

		if err != nil {
			return response, err
		}
		req, err = http.NewRequest("POST", "https://localhost:9043/"+table+"_count/", bytes.NewBuffer(requestBody))
	}
	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		log.Fatal(err)
	}
	res, err := c.httpclient.Do(req)

	if err != nil {
		log.Fatal(err)
	}
	defer res.Body.Close()
	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)

	json.Unmarshal(body, &response)

	return response, nil
}

//CreateRow sends the interface to insert
func (c *Client) CreateRow(structure interface{}, table string, company int) (interface{}, error) {
	response := utils.RespData{}
	var err error

	switch table {
	case "company":
		response, err = c.CreateCompany(structure)
	case "permission":
		response, err = c.CreatePermission(structure, company)
	case "note":
		response, err = c.CreateNote(structure, company)
	default:
		response, err = c.CreateRowDefault(structure, table, company)
	}
	if err != nil {
		return response, err
	}
	return response, nil
}

//CreateRowDefault sends the interface to insert
func (c *Client) CreateRowDefault(structure interface{}, table string, company int) (utils.RespData, error) {

	response := utils.RespData{}
	var req *http.Request
	var err error

	if company != 0 {
		//First call to permission table to get the key of the database
		key, err := c.getPermissionKey(company)

		if err != nil {
			log.Fatal(err)
		}
		structKey := StructAndKey{
			Structure: structure,
			Key:       key,
		}
		requestBody, err := json.Marshal(structKey)
		if err != nil {
			return response, err
		}

		req, err = http.NewRequest("POST", "https://localhost:9043/"+table+"/"+strconv.Itoa(company), bytes.NewBuffer(requestBody))

	} else {
		requestBody, err := json.Marshal(structure)

		if err != nil {
			return response, err
		}
		req, err = http.NewRequest("POST", "https://localhost:9043/"+table+"/", bytes.NewBuffer(requestBody))
	}
	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		return response, err
	}

	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)

	if err != nil {
		return response, err
	}
	err = json.Unmarshal(body, &response)

	if err != nil {
		return response, err
	}
	return response, nil
}

//ModifyRow sends the interface to insert
func (c *Client) ModifyRow(structure interface{}, table string, company int) (interface{}, error) {
	response := utils.RespData{}
	var err error

	switch table {
	case "note":
		response, err = c.ModifyNote(structure, company)
	default:
		response, err = c.ModifyRowDefault(structure, table, company)
	}
	if err != nil {
		return response, err
	}
	return response, nil
}

//ModifyRowDefault sends the interface to update
func (c *Client) ModifyRowDefault(structure interface{}, table string, company int) (utils.RespData, error) {

	response := utils.RespData{}
	var req *http.Request
	var err error

	if company != 0 && !tableIsBase(table) {
		//First call to permission table to get the key of the database
		key, err := c.getPermissionKey(company)

		if err != nil {
			log.Fatal(err)
		}
		structKey := StructAndKey{
			Structure: structure,
			Key:       key,
		}
		requestBody, err := json.Marshal(structKey)
		if err != nil {
			return response, err
		}

		req, err = http.NewRequest("PUT", "https://localhost:9043/"+table+"/"+strconv.Itoa(company), bytes.NewBuffer(requestBody))

	} else {
		requestBody, err := json.Marshal(structure)

		if err != nil {
			return response, err
		}
		req, err = http.NewRequest("PUT", "https://localhost:9043/"+table+"/", bytes.NewBuffer(requestBody))
	}
	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		log.Fatal(err)
	}
	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)

	if err != nil {
		return response, err
	}
	json.Unmarshal(body, &response)

	if err != nil {
		return response, err
	}
	return response, nil
}

//DeleteRow sends the interface to delete
func (c *Client) DeleteRow(structure interface{}, table string, company int) (utils.Resp, error) {

	response := utils.Resp{}
	var req *http.Request
	var err error

	if company != 0 && !tableIsBase(table) {
		//First call to permission table to get the key of the database
		key, err := c.getPermissionKey(company)

		if err != nil {
			log.Fatal(err)
		}
		structKey := StructAndKey{
			Structure: structure,
			Key:       key,
		}
		requestBody, err := json.Marshal(structKey)
		if err != nil {
			return response, err
		}

		req, err = http.NewRequest("DELETE", "https://localhost:9043/"+table+"/"+strconv.Itoa(company), bytes.NewBuffer(requestBody))

	} else {
		requestBody, err := json.Marshal(structure)

		if err != nil {
			return response, err
		}
		req, err = http.NewRequest("DELETE", "https://localhost:9043/"+table+"/", bytes.NewBuffer(requestBody))
	}
	req.Header.Add("Authorization", "Bearer "+c.token)
	if err != nil {
		log.Fatal(err)
	}

	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)

	if err != nil {
		return response, err
	}
	json.Unmarshal(body, &response)

	if err != nil {
		return response, err
	}
	return response, nil
}
//CreateCompany sends the company entered by the client to the server
func (c *Client) CreateCompany(structure interface{}) (utils.RespData, error) {

	response := utils.RespData{}
	var req *http.Request
	var err error

	//To create a company:
	//First we will create the keys aes to
	//	-  encrypt the company
	//  -  encrypt the data of company

	companyKey := make([]byte, 32)
	if _, err := rand.Read(companyKey); err != nil {
		return response, err
	}

	dataKey := make([]byte, 32)
	if _, err := rand.Read(dataKey); err != nil {
		return response, err
	}

	fmt.Print("dataKey creada al crear compañia")
	fmt.Println(dataKey)
	//Then, we encrypt the datakey with the administrator's public key

	encryptDataKey, err := rsa.EncryptOAEP(sha256.New(), rand.Reader, c.pubKey, dataKey, nil)
	if err != nil {
		return response, err
	}
	//After this we will send it along with the company information
	companyAndKeys := CompanyAndKeys{
		Company:    structure,
		CompanyKey: companyKey,
		DataKey:    encryptDataKey,
	}
	requestBody, err := json.Marshal(companyAndKeys)
	if err != nil {
		return response, err
	}

	req, err = http.NewRequest("POST", "https://localhost:9043/company/", bytes.NewBuffer(requestBody))

	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		return response, err
	}

	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)

	if err != nil {
		return response, err
	}
	err = json.Unmarshal(body, &response)

	if err != nil {
		return response, err
	}
	return response, nil
}
func (c *Client) getUserJSON(user string) (UserJSON, error) {

	response := UserJSON{}
	requestBody, err := json.Marshal(user)
	if err != nil {
		return response, err
	}
	req, err := http.NewRequest("POST", "https://localhost:9043/userclient/", bytes.NewBuffer(requestBody))
	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		log.Fatal(err)
	}
	res, err := c.httpclient.Do(req)

	if err != nil {
		log.Fatal(err)
	}
	defer res.Body.Close()
	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)

	json.Unmarshal(body, &response)

	return response, nil
}
func (c *Client) getPublicKey(user string) (*rsa.PublicKey, error) {
	var pubkey *rsa.PublicKey
	//Then we will obtain the data of the user to whom we are going to grant permissions

	userJSON, err := c.getUserJSON(user)
	if err != nil {
		return pubkey, err
	}
	fmt.Println(userJSON)
	uncompressPubKey := utils.UncompressData(utils.Decode64(userJSON.PubKey))
	pubkey, err = x509.ParsePKCS1PublicKey(uncompressPubKey)
	if err != nil {
		panic(err)
	}
	return pubkey, nil
}

//CreatePermission sends the permission entered by the client to the server
func (c *Client) CreatePermission(structure interface{}, company int) (utils.RespData, error) {

	response := utils.RespData{}
	//First, we get the structure sent from the browser.
	permission := Permission{}
	JSON, err := json.Marshal(structure)
	if err != nil {
		return response, err
	}
	err = json.Unmarshal(JSON, &permission)
	if err != nil {
		return response, err
	}

	//Then we obtain the permissions for the company from the administrator
	//We will obtain both the company key and the data key
	adminpermission, err := c.PermissionCompany(company)

	//We will decrypt the keys with the administrator's private key
	companyKey, err := rsa.DecryptOAEP(sha256.New(), rand.Reader, c.privKey, adminpermission.CompanyKey, nil)
	if err != nil {
		return response, err
	}

	dataKey, err := rsa.DecryptOAEP(sha256.New(), rand.Reader, c.privKey, adminpermission.DataKey, nil)
	if err != nil {
		return response, err
	}
	fmt.Print("dataKey descifrada al dar permisos al crear compañia")
	fmt.Println(dataKey)

	pubKey, err := c.getPublicKey(permission.User)
	if err != nil {
		return response, err
	}
	//We will use your public key to encrypt the decrypted keys
	encryptCompanyKey, err := rsa.EncryptOAEP(sha256.New(), rand.Reader, pubKey, companyKey, nil)
	if err != nil {
		return response, err
	}
	encryptDataKey, err := rsa.EncryptOAEP(sha256.New(), rand.Reader, pubKey, dataKey, nil)
	if err != nil {
		return response, err
	}
	//Finally, update and send the permission to save it.
	permission.CompanyKey = encryptCompanyKey
	permission.DataKey = encryptDataKey

	response, err = c.CreateRowDefault(permission, "permission", 0)
	if err != nil {
		return response, err
	}

	return response, nil
}
