package models

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"reflect"

	"../utils"
)

//Client is used to save all the data from user logged
type Client struct {
	dni                       string
	passwordLogInServerHassed []byte
	cipherKey                 []byte
	httpclient                *http.Client
	token                     string
	pubKey                    *rsa.PublicKey
	privKey                   *rsa.PrivateKey
}

//UserJSON is the struct of send user to server
type UserJSON struct {
	DNI      string `json:"dni"`
	Name     string `json:"name, omitempty"`
	Email    string `json:"email, omitempty"`
	Role     string `json:"role, omitempty"`
	Password string `json:"pass"`
	Salt     string `json:"salt, omitempty"`
	PubKey   string `json:"pubkey, omitempty"`
	PrivKey  string `json:"privkey, omitempty"`
}

//Hash the password and save 50% to encrypt files or folders,
//and the other 50% to be used as a passwd to log in the server
func (c *Client) Hash(password string) {
	hash := sha256.New()
	_, err := hash.Write([]byte(password))
	if err != nil {
		panic(err)
	}
	passwordHashed := hash.Sum(nil)

	c.cipherKey = passwordHashed[:16]
	c.passwordLogInServerHassed = passwordHashed[16:]
}

func (c *Client) singInPrepare(dni, password string) []byte {
	c.pubKey = &rsa.PublicKey{}
	c.privKey = &rsa.PrivateKey{}

	c.dni = dni
	c.Hash(password)

	// Not verifying the credentials because they are autosigned
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	c.httpclient = &http.Client{Transport: tr}

	u := UserJSON{
		DNI:      dni,
		Password: utils.Encode64(c.passwordLogInServerHassed),
	}

	JSONSingUp, err := json.Marshal(u)
	if err != nil {
		panic(err)
	}
	return JSONSingUp
}

//checkSuperAdminFirst we will verify that we are the superadmin by checking the token.
//	If we are, we will delete the super user since it will not need to exist in the database
func (c *Client) checkSuperAdmin() (bool, error) {
	response := utils.Resp{}
	isSuper := false

	req, err := http.NewRequest("GET", "https://localhost:9043/superadmin/", nil)
	req.Header.Add("Authorization", "Bearer "+c.token)
	res, err := c.httpclient.Do(req)
	if err != nil {
		return isSuper, err
	}
	defer res.Body.Close()

	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return isSuper, err
	}

	json.Unmarshal(body, &response)

	if response.Ok {
		isSuper = true
	}

	return isSuper, nil
}

//insertFirtsAdmin. We will proceed to create a new admin with the data provided in
//	the registerSuper form.
func (c *Client) insertFirtsAdmin(dni, password string) (utils.Resp, error) {
	response := utils.Resp{}

	requestBody := c.singUpPrepare(dni, "", "", "admin", password)

	req, err := http.NewRequest("POST", "https://localhost:9043/registerSuper/", bytes.NewBuffer(requestBody))
	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		log.Println(err)
	}
	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}
	defer res.Body.Close()

	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return response, err
	}
	json.Unmarshal(body, &response)

	return response, nil
}

//ModifySuper ModifySuper prepares the first system administrator. The steps are the following:
// 	1st checkSuperAdmin
// 	2nd InsertFirstAdmin
func (c *Client) ModifySuper(dni, password string) (utils.Resp, error) {
	response := utils.Resp{}

	c.checkSuperAdmin()
	response, err := c.insertFirtsAdmin(dni, password)

	c.token = response.Token
	return response, err
}

//SignIn initializes the variables of Client and tries to log in
func (c *Client) SignIn(dni, password string) (utils.Resp, error) {
	response := utils.Resp{}

	requestBody := c.singInPrepare(dni, password)

	req, err := http.NewRequest("POST", "https://localhost:9043/login/", bytes.NewBuffer(requestBody))

	if err != nil {
		log.Fatal(err)
	}
	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}
	defer res.Body.Close()

	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return response, err
	}
	json.Unmarshal(body, &response)

	if response.Ok {
		c.token = response.Token
		if response.Msg != "superadmin" {
			responseUser := UserJSON{}
			//request keys to server
			req, err := http.NewRequest("GET", "https://localhost:9043/keys/", nil)
			req.Header.Add("Authorization", "Bearer "+c.token)

			res, err := c.httpclient.Do(req)
			if err != nil {
				return response, err
			}
			defer res.Body.Close()
			body, err := ioutil.ReadAll(res.Body)
			if err != nil {
				return response, err
			}

			json.Unmarshal(body, &responseUser)

			uncompressPubKey := utils.UncompressData(utils.Decode64(responseUser.PubKey))
			c.pubKey, err = x509.ParsePKCS1PublicKey(uncompressPubKey)
			if err != nil {
				panic(err)
			}

			privKeyEncrypted := utils.UncompressData(utils.Decode64(responseUser.PrivKey))
			privKeyDecrypted, err := c.decrypt(privKeyEncrypted, nil)
			if err != nil {
				panic(err)
			}

			c.privKey, err = x509.ParsePKCS1PrivateKey(privKeyDecrypted)
			if err != nil {
				panic(err)
			}
		}
	}

	return response, nil
}

func (c *Client) generateRSA() {
	privKey, err := rsa.GenerateKey(rand.Reader, 1024)
	if err != nil {
		panic(err)
	}
	privKey.Precompute()
	c.pubKey = &privKey.PublicKey
	c.privKey = privKey
}
func (c *Client) singUpPrepare(dni, name, email, role, password string) []byte {
	c.generateRSA()

	c.dni = dni

	c.Hash(password)
	// Not verifying the credentials because they are autosigned
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	c.httpclient = &http.Client{Transport: tr}

	pubKeyJSON := x509.MarshalPKCS1PublicKey(c.pubKey)
	privKeyJSON := x509.MarshalPKCS1PrivateKey(c.privKey)

	privKeyEncrypted, err := c.encrypt(privKeyJSON, nil)
	if err != nil {
		panic(err)
	}

	u := UserJSON{
		DNI:      dni,
		Name:     name,
		Email:    email,
		Role:     role,
		Password: utils.Encode64(c.passwordLogInServerHassed),
		PubKey:   utils.Encode64(utils.CompressData(pubKeyJSON)),
		PrivKey:  utils.Encode64(utils.CompressData(privKeyEncrypted)),
	}

	JSONSingUp, err := json.Marshal(u)
	if err != nil {
		panic(err)
	}
	return JSONSingUp
}

//SignUp is used to register the Client
func (c *Client) SignUp(dni, name, email, role, password string) (utils.RespData, error) {

	response := utils.RespData{}
	client := Client{}

	client.generateRSA()
	requestBody := client.singUpPrepare(dni, name, email, role, password)

	req, err := http.NewRequest("POST", "https://localhost:9043/user/", bytes.NewBuffer(requestBody))
	req.Header.Add("Authorization", "Bearer "+c.token)
	if err != nil {
		log.Fatal(err)
	}
	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}
	defer res.Body.Close()

	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return response, err
	}
	json.Unmarshal(body, &response)

	return response, nil
}

func (c *Client) permissionsUser(dniAdmin string) ([]Permission, error) {
	//Get the encrypted key of connection to the database
	response := RespDataPermission{}
	permission := Permission{
		User:            dniAdmin,
		Company:         0,
		CompanyKey:      nil,
		ReadPermission:  false,
		WritePermission: false,
	}
	requestBody, err := json.Marshal(permission)
	if err != nil {
		return response.Structure, err
	}

	req, err := http.NewRequest("POST", "https://localhost:9043/permission_parcial_id/", bytes.NewBuffer(requestBody))
	req.Header.Add("Authorization", "Bearer "+c.token)
	if err != nil {
		return response.Structure, err
	}
	res, err := c.httpclient.Do(req)
	if err != nil {
		return response.Structure, err
	}

	defer res.Body.Close()
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return response.Structure, err
	}

	err = json.Unmarshal(body, &response)
	if err != nil {
		return response.Structure, err
	}
	if !response.Ok {
		return response.Structure, err
	}
	return response.Structure, nil
}
func (c *Client) permissionTableAdmin(company int) ([]byte, error) {
	responsePermission := Permission{}
	var companyKey []byte

	//Get the encrypted key of connection to the database
	permission := Permission{
		User:            c.dni,
		Company:         company,
		CompanyKey:      nil,
		ReadPermission:  false,
		WritePermission: false,
	}
	requestBody, err := json.Marshal(permission)
	if err != nil {
		return companyKey, err
	}

	req, err := http.NewRequest("POST", "https://localhost:9043/permission_id/", bytes.NewBuffer(requestBody))
	req.Header.Add("Authorization", "Bearer "+c.token)
	if err != nil {
		return companyKey, err
	}
	res, err := c.httpclient.Do(req)
	if err != nil {
		return companyKey, err
	}

	defer res.Body.Close()
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return companyKey, err
	}

	err = json.Unmarshal(body, &responsePermission)
	if err != nil {
		return companyKey, err
	}

	companyKey = responsePermission.CompanyKey

	return companyKey, nil
}
func (c *Client) getPublicRSA() ([]byte, error) {
	var key []byte

	//Get the public key from server
	req, err := http.NewRequest("GET", "https://localhost:9043/publickeyserver/", nil)
	req.Header.Add("Authorization", "Bearer "+c.token)
	if err != nil {
		return key, err
	}
	res, err := c.httpclient.Do(req)
	if err != nil {
		return key, err
	}

	defer res.Body.Close()
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return key, err
	}

	json.Unmarshal(body, &key)
	if err != nil {
		return key, err
	}
	return key, nil
}
func (c *Client) decryptAndEncriptKeyCompany(encryptCompanyOfAdmin []byte, publicKeyUser *rsa.PublicKey) ([]byte, error) {
	var key []byte
	//After this we will decipher the database key with the administrator's private key
	keyCompany, err := rsa.DecryptOAEP(sha256.New(), rand.Reader, c.privKey, encryptCompanyOfAdmin, nil)
	if err != nil {
		fmt.Println("Error in decrypt key!!!" + err.Error())
		return key, err
	}
	//Now, we will first encrypt the key with the user's public key
	key, err = rsa.EncryptOAEP(sha256.New(), rand.Reader, publicKeyUser, keyCompany, nil)
	if err != nil {
		fmt.Println("Error in encrypt key!!!" + err.Error())
		return key, err
	}

	return key, nil
}

func (c *Client) updatePermission(permission Permission) (utils.RespData, error) {
	//Get the encrypted key of connection to the database
	var response = utils.RespData{}

	requestBody, err := json.Marshal(permission)
	if err != nil {
		return response, err
	}

	req, err := http.NewRequest("PUT", "https://localhost:9043/permission/", bytes.NewBuffer(requestBody))
	req.Header.Add("Authorization", "Bearer "+c.token)
	if err != nil {
		return response, err
	}
	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}

	defer res.Body.Close()
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return response, err
	}

	err = json.Unmarshal(body, &response)
	if err != nil {
		return response, err
	}
	return response, nil
}

//modifyPermissionUser
func (c *Client) modifyPermissionUser(user Client) error {
	//-----------------------------------------------//
	// c -> admin logged to modify 				     //
	// dniUser -> dni of the admin modify the user   //
	//-----------------------------------------------//

	//First we obtain the permissions of the user that we just modified   dni of user
	userPermissions, err := c.permissionsUser(user.dni)
	if err != nil {
		return err
	}
	//After this we will deal with all the permissions
	if userPermissions != nil {
		for _, userpermission := range userPermissions {
			//Get key from permission table
			encryptCompanyOfAdmin, err := c.permissionTableAdmin(userpermission.Company)
			if err != nil {
				return err
			}
			//Decrypt company key and encrypt it with our own key
			keyEncrypt, err := c.decryptAndEncriptKeyCompany(encryptCompanyOfAdmin, user.pubKey)
			if err != nil {
				return err
			}
			userpermission.CompanyKey = keyEncrypt

			//Update permission
			response, err := c.updatePermission(userpermission)
			if err != nil {
				return err
			}
			if !response.Ok {
				return err
			}
		}
	}
	return nil
}

//SignModify is used to modify the Client
func (c *Client) SignModify(dni, name, email, role, password string) (utils.RespData, error) {

	response := utils.RespData{}
	client := Client{}

	client.generateRSA()
	requestBody := client.singUpPrepare(dni, name, email, role, password)

	req, err := http.NewRequest("PUT", "https://localhost:9043/user/", bytes.NewBuffer(requestBody))
	req.Header.Add("Authorization", "Bearer "+c.token)
	if err != nil {
		log.Fatal(err)
	}
	res, err := c.httpclient.Do(req)
	if err != nil {
		return response, err
	}
	defer res.Body.Close()

	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return response, err
	}
	json.Unmarshal(body, &response)

	//If the user modify the password correctly
	if response.Ok {
		err = c.modifyPermissionUser(client)
		if err != nil {
			return response, err
		}
	}
	return response, nil
}

func (c *Client) encrypt(content, key []byte) ([]byte, error) {
	if key == nil {
		key = c.cipherKey
	}
	//Creates the cipher
	cb, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(cb)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err = io.ReadFull(rand.Reader, nonce); err != nil {
		fmt.Println(err)
	}
	//Seal the content to be retorned encrypted
	encryptedContent := gcm.Seal(nonce, nonce, content, nil)

	return encryptedContent, nil
}

func (c *Client) decrypt(content, key []byte) ([]byte, error) {
	if key == nil {
		key = c.cipherKey
	}
	//Creates the cipher
	cb, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(cb)
	if err != nil {
		return nil, err
	}
	nonceSize := gcm.NonceSize()
	if len(content) < nonceSize {
		return nil, fmt.Errorf("Error: the encrypted content doens't correspond to this key because it's too small")
	}
	//Get the content without nonce and decrypt that
	nonce, content := content[:nonceSize], content[nonceSize:]
	decryptedContent, err := gcm.Open(nil, nonce, content, nil)
	if err != nil {
		return nil, err
	}

	return decryptedContent, nil
}

//GetToken returns the client token
func (c *Client) GetToken() string {
	return c.token
}

//Logout returns the client token
func (c *Client) Logout() bool {
	result := true

	p := reflect.ValueOf(c).Elem()
	p.Set(reflect.Zero(p.Type()))

	return result
}

//GetDNI returns the client dni
func (c *Client) GetDNI() string {
	return c.dni
}

//RefreshToken refresh the token of client
func (c *Client) RefreshToken() (interface{}, error) {

	var response = utils.Resp{}

	req, err := http.NewRequest("GET", "https://localhost:9043/refreshToken/", nil)
	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		log.Fatal(err)
	}
	res, err := c.httpclient.Do(req)

	if err != nil {
		log.Fatal(err)
	}
	defer res.Body.Close()
	//Unmarshal the response to a resp struct
	body, err := ioutil.ReadAll(res.Body)

	json.Unmarshal(body, &response)

	if response.Ok {
		c.token = response.Token
	}

	return response, nil
}
