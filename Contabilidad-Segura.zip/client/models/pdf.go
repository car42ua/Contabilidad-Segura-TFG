package models

import (
	"bytes"
	// "crypto/rand"
	// "crypto/rsa"
	// "crypto/sha256"
	// "crypto/x509"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"
	"time"

	// "../utils"
	// "github.com/dgrijalva/jwt-go"
	"github.com/jung-kurt/gofpdf"
	"janouch.name/pdf-simple-sign/pdf"
)

//Account is the struct for get one account.
type Account struct {
	ID          int     `json:"id"`
	Company     int     `json:"company"`
	Title       string  `json:"title"`
	TotalDebit  float64 `json:"totaldebit"`
	TotalCredit float64 `json:"totalcredit"`
	Balance     float64 `json:"balance"`
}

//CreatePDFJournal sends the acyear with company for create a journal or account list .
func (c *Client) CreatePDF(structure interface{}, typeDocument string, company int,acyear string) (bool, error) {

	var req *http.Request
	var err error

	if err != nil {
		return false, err
	}
	key, err := c.getPermissionKey(company)

	if err != nil {
		log.Fatal(err)
	}
	structKey := StructAndKey{
		Structure: structure,
		Key:       key,
	}
	requestBody, err := json.Marshal(structKey)

	if err != nil {
		return false, err
	}
	if (typeDocument == "journal"){
		req, err = http.NewRequest("POST", "https://localhost:9043/pdf_journal/"+strconv.Itoa(company), bytes.NewBuffer(requestBody))
	}else{
		req, err = http.NewRequest("POST", "https://localhost:9043/pdf_account/"+strconv.Itoa(company), bytes.NewBuffer(requestBody))
	}
	
	req.Header.Add("Authorization", "Bearer "+c.token)

	if err != nil {
		log.Fatal(err)
	}

	res, err := c.httpclient.Do(req)
	if err != nil {
		return false, err
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)

	if err != nil {
		return false, err
	}

	responseNote := respDataNote{}
	json.Unmarshal(body, &responseNote)
	if err != nil {
		return false, err
	}
	if responseNote.Ok {
		if len(responseNote.Structure) != 0 {
			note, err := c.decryptDataNote(company, &responseNote.Structure)
			if err != nil {
				return false, err
			}

			inputPath := "./list/"+typeDocument+"_"+time.Now().Format("20060102150405")
			//Then Create the pdf with data and signature the pdf
			if (typeDocument == "journal"){
				_ = createJournalPDF(note, inputPath +".nosign",company,acyear)
			}else{
				_ = createAccountPDF(note, inputPath +".nosign",company,acyear)
			}
			//Sign the pdf
			err = signPDF(inputPath)
			if err != nil {
				fmt.Println(err)
				return false, err
			}
		}
	} else {
		return false, err
	}

	return true, nil
}


func addHead(pdf *gofpdf.Fpdf, headText string) {
	var head []string
	if headText == "journal" {
		headJournal := []string{"Note", "Seat", "Section", "Seat Date", "Account", "Title Account", "Concept", "Debit/Credit", "Amount"}
		head = headJournal
	} else {
		headAccount := []string{"Account", "Title Account", "Total Debit", "Total Credit", "Balance"}
		head = headAccount
	}
	pdf.SetFont("Arial", "B", 7)
	pdf.SetFillColor(240, 240, 240)
	for _, str := range head {
		pdf.CellFormat(20, 7, str, "1", 0, "L", true, 0, "")
	}
	pdf.Ln(-1)
}
func createJournalPDF(pdflist []SeatNote, inputPath string,company int, acyear string) *gofpdf.Fpdf {
	//Then Create the pdf with data and signature the pdf
	pdf := gofpdf.New("L", "mm", "A4", "")
	pdf.AddPage()
	pdf.SetFont("Arial", "B", 16)
	pdf.Cell(40, 10, "List of Journal")
	pdf.Ln(12)
	pdf.SetFont("Arial", "B", 12)
	pdf.Cell(40, 7, "Company: "+strconv.Itoa(company)+" ,Accounting Year : "+acyear+" .")
	pdf.Ln(12)

	addHead(pdf, "journal")
	var count = 0
	pdf.SetFillColor(255, 255, 255)
	for _, str := range pdflist {
		if pdf.PageNo() == 1 {
			if count == 21 {
				pdf.AddPage()
				addHead(pdf, "journal")
				count = 0
			}
		} else {
			if count == 24 {
				pdf.AddPage()
				addHead(pdf, "journal")
				count = 0
			}

		}
		pdf.CellFormat(20, 7, strconv.Itoa(str.ID), "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, strconv.Itoa(str.Seat), "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, str.TitleSection, "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, str.SeatDate, "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, strconv.Itoa(str.Account), "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, str.TitleAccount, "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, str.TitleConcept, "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, str.DC, "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, fmt.Sprintf("%.2f", str.Amount), "1", 0, "L", false, 0, "")
		pdf.Ln(-1)
		count++
	}
	pdf.Ln(-1)

	err := pdf.OutputFileAndClose(inputPath)
	if err != nil {
		fmt.Println(err)
	}

	return pdf
}
func updateDC(account *Account , value SeatNote){
	if value.DC == "D" {
		account.TotalDebit = account.TotalDebit + value.Amount
	}else{
		account.TotalCredit = account.TotalCredit + value.Amount
	}
	account.Balance = account.TotalDebit - account.TotalCredit
}
func createGroupOfAccount(pdflist []SeatNote)[]Account{
	var result[]Account
	var mapOfAccounts = make(map[int]Account)

	for _,value := range pdflist{
		if ac,ok := mapOfAccounts[value.Account]; ok{
			updateDC(&ac,value)
			mapOfAccounts[ac.ID] = ac
		}else{
			var auxAccount Account
			auxAccount.ID = value.Account
			auxAccount.Company = value.Company
			auxAccount.Title = value.TitleAccount
			auxAccount.TotalDebit = 0
			auxAccount.TotalCredit = 0
			auxAccount.Balance = 0
			updateDC(&auxAccount,value)

			mapOfAccounts[auxAccount.ID] = auxAccount
		}
	}
	for _,value := range mapOfAccounts{
		result = append(result,value)
	}

	return result
}

func createAccountPDF(pdflist []SeatNote, inputPath string,company int, acyear string) *gofpdf.Fpdf {

	accounts := createGroupOfAccount(pdflist)
	//Then Create the pdf with data and signature the pdf
	pdf := gofpdf.New("P", "mm", "A4", "")
	pdf.AddPage()
	pdf.SetFont("Arial", "B", 16)
	pdf.Cell(40, 10, "List of Accounts")
	pdf.Ln(12)
	pdf.SetFont("Arial", "B", 8)
	pdf.Cell(40, 7, "Company: "+strconv.Itoa(company)+" ,Accounting Year : "+acyear+" .")
	pdf.Ln(12)

	addHead(pdf, "account")
	var count = 0
	pdf.SetFillColor(255, 255, 255)
	for _, str := range accounts {
		if pdf.PageNo() == 1 {
			if count == 21 {
				pdf.AddPage()
				addHead(pdf, "account")
			}
		} else {
			if count == 24 {
				pdf.AddPage()
				addHead(pdf, "account")
			}
		}
		pdf.CellFormat(20, 7, strconv.Itoa(str.ID), "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, str.Title, "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, fmt.Sprintf("%.2f", str.TotalDebit), "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, fmt.Sprintf("%.2f", str.TotalCredit), "1", 0, "L", false, 0, "")
		pdf.CellFormat(20, 7, fmt.Sprintf("%.2f", str.Balance), "1", 0, "L", false, 0, "")

		pdf.Ln(-1)
		count++
	}
	count = 0
	pdf.Ln(-1)

	err := pdf.OutputFileAndClose(inputPath)
	if err != nil {
		fmt.Println(err)
	}

	return pdf
}
func signPDF(filename string) error {

	inputPath := filename + ".nosign"
	outputPath := filename + ".pdf"

	doc, err := ioutil.ReadFile(inputPath)
	if err != nil {
		return err
	}
	p12, err := ioutil.ReadFile("./signature/key-pair.p12")
	if err != nil {
		return err
	}
	key, certs, err := pdf.PKCS12Parse(p12, "")
	if err != nil {
		return err
	}
	if doc, err = pdf.Sign(doc, key, certs, 4096); err != nil {
		return err
	}
	if err = ioutil.WriteFile(outputPath, doc, 0666); err != nil {
		return err
	}
	return nil
}
