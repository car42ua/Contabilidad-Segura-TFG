
///////////////////////////////////////////////////////////////////////////
//                         Validation Methods                            //
///////////////////////////////////////////////////////////////////////////


function printSuccess(node){
    node.classList.remove("border-danger");
    node.classList.add("border-success");

    if(TABLE != "note"){
        node.previousElementSibling.textContent = "Valid";
        node.previousElementSibling.classList.remove("text-danger");
        node.previousElementSibling.classList.add("text-success");
    }
}

function printDanger(node,error){
    node.classList.remove("border-success");
    node.classList.add("border-danger");

    if(TABLE != "note"){
        node.previousElementSibling.textContent = error;
        node.previousElementSibling.classList.remove("text-success");
        node.previousElementSibling.classList.add("text-danger");
    }
}
function clearPrint(node){
    node.classList.remove("border-success");
    node.classList.remove("border-danger");
    span = node.parentNode.querySelector("span");
    if(span!=null){
        span.textContent = "";
        span.classList.remove("text-success");
        span.classList.remove("text-danger");
    }
}

function fillNumber(num,length){
    var result = "";
    if(num.length < length ){
        if(num.includes(".")){
            var indexDot = num.indexOf('.');
            var startPart = num.substring(0,indexDot);
            var endPart = num.substring(indexDot+1,num.length);
            result = startPart;

            var zeros = (length-num.length+1);
            for(let i=0;i<zeros;i++){
                result = result+"0";
            }
            result = result + endPart;
        }else{
            var zeros = (length-num.length);
            for(let i=0;i<zeros;i++){
                result = "0" +result;
            }
            result = result + num.toString();
        }
    }else{
        result = num;
    }

    return result;
}
function regexFilter(value,regex){
    var newRegex = new RegExp(regex);
    return (newRegex.test(value));
}
async function validEmptyOrNumber(node){
    if(await checkEmptyOrNumber(node)){
        printSuccess(node);
        return true;
    }else{
        printDanger(node,"Error. Enter a value");
        return false;
    }
}
async function checkEmptyOrNumber(node){
    result = true;
    if(!checkEmpty(node)){
        result = validNumber(node);
        // if(result){
        //     obj = await getRowByID(node.id,node.name.replace(node.id,""),formatValue(node.value))
        //     title = document.getElementById("title"+node.id);
        //     if(obj.title != null){
        //         title.value = obj.title;
        //     }else{
        //         alert("The "+node.id+" is not exist");
        //         node.value = "";
        //         title.value = "";
        //     }

        // }
    }
    return result;
}
function validNumber(node){
    const NUMBER_REGEX = /^([0-9\S]+)\.+?[0-9]+$|^([0-9]+$)/; //Ejemplo 5.56
    fill = node.getAttribute("data-fill");
    if(regexFilter(node.value.toString(),NUMBER_REGEX)){
        node.value = fillNumber(node.value,fill);
        printSuccess(node);
        return true;
    }else{
        printDanger(node,"Error. Use numbers!");
        return false;
    }
}
function validInput(node){
    var value;
    if(node.placeholder!=""){
        if(node.value==""){ 
            value = node.placeholder;
        }else{
            value = node.value;
        }
    }else{
        value = node.value;
    }
    return value;
}
function validRegex(node,regex){

    value = validInput(node);

    if(regexFilter(value,regex)){
        printSuccess(node);
        return true;
    }else{
        printDanger(node,"Error. Incorrect value");
        return false;
    }
}
function validDate(node){
    const DATE_REGEX = /^([0-9]{4}[-](0[1-9]|1[0-2])[-]([0-2]{1}[0-9]{1}|3[0-1]{1})|([0-2]{1}[0-9]{1}|3[0-1]{1})[-](0[1-9]|1[0-2])[-][0-9]{4})/;
    return validRegex(node,DATE_REGEX);
}
function validDC(node){
    const dcRegex = /^[CD]$/;
    return validRegex(node,dcRegex);
}
function validEmpty(node){
    if(!checkEmpty(node)){
        printSuccess(node);
        return true;
    }else{
        printDanger(node,"Error. Enter a value");
        return false;
    }
}
function checkEmpty(node){
    value = (node.placeholder=="")?node.value:node.placeholder; //If the placeholder is empty
    if(value.length== 0){
        return true;
    }else{
        return false;
    }
}
function validEmail(node){
    const EMAIL_REGEX = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
    return validRegex(node,EMAIL_REGEX);
}
function validPassword(node){
    /*
    The password : 
        - Must have at least 4 characters
        - Must contain at least 1 uppercase letter, 1 lowercase letter, and 1 number
        - Can contain special characters
    */
    const PASSWORD_REGEX = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{4,}$/;
    const ADMIN_REGEX = /^admin$/;
    if(!validRegex(node,ADMIN_REGEX)){
        if(!validRegex(node,PASSWORD_REGEX)){
            return false
        }
    }
    return true
}
function validCIF(node){
    const DNI_REGEX = /^(\d{8})([A-Z])$/;
    const CIF_REGEX = /^([ABCDEFGHJKLMNPQRSUVW])(\d{7})([0-9A-J])$/;
    const NIE_REGEX = /^[XYZ]\d{7,8}[A-Z]$/;
    const ADMIN_REGEX = /^admin$/;

    if(!validRegex(node,DNI_REGEX)){
        if(!validRegex(node,CIF_REGEX)){
            if(!validRegex(node,NIE_REGEX)){
                if(!validRegex(node,ADMIN_REGEX)){
                    return false;
                }
            }
        }
    }
    return true
    
}
//checkValidation send form node and validates all the inputs
function checkValidation(){

    var inputs = document.querySelectorAll("[data-input]");
    var result = true;
    
    inputs.forEach(function(element){
        func = element.getAttribute("data-valid");
        if(func != null){
            if(!window[func](element)){
                result = false
            }
        }
    });
    return result;
}
//function writeInTable()
function writeNote(event){
    //Check all the inputs after write on the table
    var node = event.target;

    if(!checkValidation()){
        printDanger(node,"Revisar entrada!");
    }else{
        printSuccess(node);
        //Write the Note into the table.action-button
    }
}
///////////////////////////////////////////////////////////////////////////
//                              TOKENS                                   //
///////////////////////////////////////////////////////////////////////////

function parseJwt (token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
};

function setModal(typeModal){
    var header;
    var modal;
    modal = document.createElement("div");
    modal.classList.add("modal");
    modal.setAttribute("id","modal"+typeModal);
    modal.innerHTML = `
    <div class="modal-dialog"><div class="modal-content">
        <!-- Modal Header -->
        <div class="modal-header">
            <h4 id="modalTitle`+typeModal+`" class="modal-title"></h4>
        </div>
        <div class="modal-body">
            <p id="modalText`+typeModal+`"></p>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
            <button id="modalButton`+typeModal+`" type="button" class="btn"data-dismiss="modal"></button>
        </div>
        
        </div>
    </div>
    `;
    body = document.querySelector("body");
    body.appendChild(modal);

    let title = document.getElementById("modalTitle"+typeModal);
    let modalButton = document.getElementById("modalButton"+typeModal);
    let modalText = document.getElementById("modalText"+typeModal);

    if(typeModal == "refresh"){
        title.innerText = "Your session expired very soon...";
        modalText.innerText ="Please Refresh for continue";
        modalButton.addEventListener('click',refreshToken);
        modalButton.innerText="Refresh";
        modalButton.classList.add("btn-success");

    }else{
        title.innerText = "Your session has expired..."
        modalText.innerText ="You need LOGIN for continue...";
        modalButton.setAttribute('onclick', "chargeView('./www/index.html')");
        modalButton.innerText="SignIn";
        modalButton.classList.add("btn-danger");
    }

}
async function getToken(){
    try{
        token = await GetToken();// Call Go function
        parseToken = parseJwt(token);
        expires = parseToken.exp;
        //expires = new Date(parseToken.exp * 1000);
        now = Math.round((new Date()).getTime()/1000);
        expiredTimeSeconds = expires - now; //Time for expired in seconds
        timeAlert = 60;//is is the time(in seconds) to alert the client to reloggin.
        oneMinuteLeft = (expiredTimeSeconds - timeAlert)*1000;//one minute left for expired (in milliseconds)
        logOutTime = expiredTimeSeconds * 1000; //expiredTimeSeconds(in milliseconds)

        timeOutRefresh = setTimeout(function(){
            setModal("refresh");
            $("#modalrefresh").modal({
                show:true,
                keyboard: false,
                backdrop: 'static'
              })
            }, oneMinuteLeft);
        
        timeOutLogOut = setTimeout(function(){
            setModal("logout");
            $('#modallogin').modal('hide');
            $("#modallogout").modal({
                show:true,
                keyboard: false,
                backdrop: 'static'
              })
            }, logOutTime);
    }catch(error){
        alert(error)
    }
}
async function refreshToken(){
    try{
        response = await RefreshToken();
        if(response.Ok) {
            getToken();
            clearTimeout(timeOutLogOut);
        } else {
            alert(response.Msg);
        }
    }catch(error){
        alert(error);
    }
}

async function logout(){
    try{
        response = await Logout();
        if(response) {
            chargeView('./www/index.html');
        } else {
            alert("I cant Logout!");
        }
    }catch(error){
        alert(error);
    }
}
async function getDNI(){
    try{
        response = await GetDNI();
        if(response != null) {
            navbarDNI = document.getElementById("navbardrop");
            navbarDNI.innerText = response
        } else {
            alert("I cant get the DNI!");
        }
    }catch(error){
        alert(error);
    }
}

///////////////////////////////////////////////////////////////////////////
//                       FORM AND GENERAL CRUD                           //
///////////////////////////////////////////////////////////////////////////
function createWaitingModal(){
    var modal;
    modal = document.createElement("div");
    modal.classList.add("modal","modalwaiting");
    modal.setAttribute("id","waitingModal");
    modal.innerHTML = `
    <div class="modal-dialog">
        <div class="modal-content">
                <span class="spinner text-primary"></span>
        </div>
    </div>
    `;
    body = document.querySelector("body");
    body.appendChild(modal);
}
function openWaitingModal(){
    $("#waitingModal").modal({
        show:true,
        keyboard: false,
        backdrop: 'static'
      })
}
function closeWaitingModal(){
    $('#waitingModal').modal('hide');
}
//newRow Insert new row in table 
function newRow(obj,tableNode){

    var tbody = tableNode.querySelector("tbody");
    var headmatches = tableNode.querySelectorAll("[data-head= true]");

    let tr = document.createElement('tr');

    if(tableNode.hasAttribute("data-form")){
        let td = document.createElement('td');
        let spanDelete = document.createElement('span');
        let spanModify = document.createElement('span');
        if(TABLE != 'acyear'){
    
            spanDelete.classList.add("btn","text-danger","px-1");
            spanDelete.innerText = String.fromCodePoint(0x1F5D1);
            spanDelete.addEventListener('click',deleteRow);
        }
        if(TABLE != 'permission'){
            spanModify.classList.add("btn","text-warning","px-1");
            spanModify.innerText = String.fromCodePoint(0x270F);
            spanModify.addEventListener('click',modifyRowIcon);

        }
        tr.appendChild(td);
        td.appendChild(spanDelete);td.appendChild(spanModify);
    }
    if(tableNode.hasAttribute("data-pop")){
        tr.setAttribute('onclick',"loadPopoverRow(this)");
    }

    var entries = Object.entries(obj);
    var pk = "";
    for(var i = 0; i < headmatches.length;i++){
        let td = document.createElement('td');
        column = headmatches[i].getAttribute("name");
        td.setAttribute("data-type",column);
        td.setAttribute("data-value",obj[column]);
        if(headmatches[i].hasAttribute("hidden")){
            td.style.display = "none";
        }
        td.innerText = obj[column];
        tr.appendChild(td);
        
        if(headmatches[i].hasAttribute("data-pk")){
            pk = pk + obj[column] + "|";
            tr.setAttribute("pk",pk);
        }
    }
    if(TABLE == "note" && tableNode.hasAttribute("data-form") ){
        //tdseat = tableNode.querySelectorAll("tr [data-type = 'seat'], td [data-value]")
        tdseat = tr.querySelector("td[data-type = 'seat']");
        value = formatValue(tdseat.getAttribute("data-value"));
        count = tableNode.querySelectorAll("[data-type = 'seat'][data-value = '"+value+"']").length;

        let td = document.createElement('td');
        if (count == 0){
            let inputUpdate = document.createElement('input');
            inputUpdate.setAttribute("type","checkbox");
            td.appendChild(inputUpdate);
        }
        tr.appendChild(td);
    }
    if (TABLE == "company"){
        let td = document.createElement('td');
        let spanYear = document.createElement('span');
        spanYear.classList.add("btn","text-success","px-1");
        spanYear.innerText = String.fromCodePoint(0X1F50E);
        spanYear.setAttribute('onclick',"chargeView2('www/manageAcYear.html','"+obj.id+"')");
        td.appendChild(spanYear);
        tr.appendChild(td);
    }
    tbody.appendChild(tr);
}
//formatValue check and format string for table formats
function formatValue(string){
    if(string == "" || string == null){
        return null;
    }else if (string == "true"){
        return true;
    }else if (string == "false"){
        return false;
    }else{
        value = Number(string)
        if (isNaN(value)){
            return string
        }else{
            return value;
        }
    }

}
//createObjectOfRow create a object for a row
async function createObjectOfRow(row,tableNode){
    var obj;
    var tableName = tableNode.getAttribute("data-table");
    var rowmatches = row.querySelectorAll("[data-type]");
    
    if(rowmatches.length != 0){
        var obj = await getStructure(tableName);

        var headmatches = tableNode.querySelectorAll("[data-head= true]");
    
        for(var i = 0; i < headmatches.length;i++){
            obj[headmatches[i].getAttribute("name")] = formatValue(rowmatches[i].textContent);
        } 
    }

    return obj;
}
async function deleteRowProcess(event){
    row = event.target.parentNode.parentNode;
    tableNode = row.parentNode.parentNode;

    obj = await createObjectOfRow(row,tableNode);
    
    var r = confirm("Are you sure to delete the row?");
    if (r == true) {
        result = await sendDeleteRow(obj,TABLE)
        if (result == true){
            row.parentNode.removeChild(row)
        }else{
            alert("Imposible to delete this row")
        }
            
    } 
}
async function deleteRow(event){

    if(TABLE == "note"){
        company = formatValue(document.getElementById("company").value);
        permission = await loadWritePermission(company); 
        if(!permission){
            alert("you dont have permission for this action.");
        }else{
            await deleteRowProcess(event);
        }     
    }else{
        await deleteRowProcess(event);
    }
}
async function deleteContentElement(tbody){
    while (tbody.firstChild) {
        tbody.removeChild(tbody.lastChild);
      }
}

async function sendDeleteRow(obj,table){
    var result = false;
    openWaitingModal();
    try{
        response = await DeleteRow(obj,table,attach);// Call Go function
        if(response.Ok) {
            result = true;
        }else{
            closeWaitingModal();
            alert(response.Msg);
        }
    }catch(error){
        closeWaitingModal();
        alert(error)
    }
    closeWaitingModal();
    return result;
}
function clearInputs(inputs){
    
    inputs.forEach(element=>{
        if(element.hasAttribute("data-pk")){
            element.removeAttribute("disabled")
        }
        // if (!element.hasAttribute("data-parcial")){
            element.value = "";
            element.placeholder = "";
            clearPrint(element);
        // }
    });
}
function disabledInputs(inputs){
    
    inputs.forEach(element=>{
        element.setAttribute("disabled","");
    });
}
function enabledInputs(inputs){
    
    inputs.forEach(element=>{
        element.removeAttribute("disabled");
    });
}
async function modifyRowIcon(event){
    if(TABLE == "note"){
        company = formatValue(document.getElementById("company").value);
        permission = await loadWritePermission(company); 
        if(!permission){
            alert("you dont have permission for this action.");
        }else{
            await modifyRowIconProcess(event);
        }     
    }else{
        await modifyRowIconProcess(event);
    }
}
async function modifyRowIconProcess(event){
    
    row = event.target.parentNode.parentNode;
    tableNode = row.parentNode.parentNode;

    obj = await createObjectOfRow(row,tableNode);
    
    var entries = Object.entries(obj);

    entries.forEach(element => {
        input = form.querySelector('[id = "'+element[0]+'"]');

        if (input != null){
            if(input.hasAttribute("data-pk")){
                input.setAttribute("disabled","")
            }
            if(input.type == "checkbox"){
                input.checked = element[1] ; //Convert string to bool
            }else if(input.type == "date"){
                $('#'+input.id).val(element[1]);
            }else if(input.type == "select-one"){
                input.value = element[1];
            }else{
                if(input.hasAttribute("data-pk")){
                    input.value = element[1];
                }else{
                    input.placeholder = element[1];
                }
            }
        }
    });

    showModifyButton();

    if(TABLE == 'note'){
        inputs = document.querySelectorAll("[data-seat]");
        disabledInputs(inputs);
    }
}
function searchRow(headmatches,obj){
    search = "";
    for(var i = 0; i < headmatches.length;i++){
        if(headmatches[i].hasAttribute("data-pk")){
            search = search + obj[headmatches[i].getAttribute("name")]+"|";
        } ;
    } 
    row = document.querySelector('tr[pk="'+search+'"]')

    return row;
}
function modifyRow(obj){

    var tableNode = document.querySelector("table[data-form]");
    var headmatches = tableNode.querySelectorAll("[data-head= true]");

    row = searchRow(headmatches,obj);
    if (row == null){
        var nameTable = tableNode.getAttribute("data-table");
        var inputID = document.querySelector("input[data-"+nameTable+" ='id']");
        row = document.querySelector('tr[pk="'+inputID.value+"|"+'"]')
        row.setAttribute("pk",obj.id+"|");
    }
    var entries = Object.entries(obj);

    entries.forEach(element => {
        if(element[1]!= null && element[1]!= ""){
            td = row.querySelector('td[data-type="'+element[0]+'"]');
            if(td != null){
                td.setAttribute("data-value",element[1]);
                td.innerText = element[1];
            }
        }
     });

}

async function updateRow(event){
    
    openWaitingModal();

    if(checkValidation()){
        var obj;
        if(TABLE == "note"){
            inputs = document.querySelectorAll("[data-note]");
            obj = await prepareRow("note",inputs);
        }else{
            inputs = document.querySelectorAll("[data-input]");
            obj = await prepareRow(TABLE,inputs);
            //obj = prepareInputs(struct,inputs,TABLE);
        }

        try{
            if(TABLE =="user" && obj.pass!= null){
                response = await SignModify(obj.dni,obj.name,obj.email,obj.role,obj.pass);// Call Go function
                if(response.Ok){
                    var tableNode = document.querySelector("table[data-form]");
                    newRow(obj,tableNode);
                }else{
                    closeWaitingModal();
                    alert(response.Msg);
                }
            }else{
                response = await ModifyRow(obj,TABLE,attach);// Call Go function
                if(response.Ok) {
                    if(TABLE == "note"){
                        await loadNote();
                    }else{
                        modifyRow(obj);
                    }
                    cancelUpdateRow();
                }else{
                    closeWaitingModal();
                    alert("ErrorControlado");
                }
            }

        }catch(error){
            closeWaitingModal();
            alert(error)
        }
    }
    closeWaitingModal();
}

async function getStructure(table){
    try{
        response = await GetStructure(table);// Call Go function
        if(response.Ok) {
            return response.Structure
        } else {
            alert(response.Msg);
        }
    }catch(error){
        alert(error)
    }
}
async function loadTable(table,tableNode){
    var tbody = tableNode.querySelector("tbody");
    deleteContentElement(tbody);

    rows = await getAllRows(table);
    rows.forEach(element => {
            newRow(element,tableNode);
    });
}
async function getAllRows(table){
    try{
        response = await GetRows(table,attach);// Call Go function
        if(response.Ok) {
            return response.Structure;
        } else {
            alert(response.Msg);
        }
    }catch(error){
        alert(error)
    }
}

async function arrayToObj(table,arrayIdName,arrayIdValue){
    var obj;
    if(arrayIdName == null && arrayIdValue == null){
        obj = prepareGetObject();
    }else{
        obj = await getStructure(table);
        for(var i = 0 ; i < arrayIdName.length ; i++){
            obj[arrayIdName[i]] = arrayIdValue[i];
        }
    }
    return obj;
}

//loadTableParcial gets all rows of table with parcial ID
//  1- If the query is for the main table, the 2 attribute of the method must be null.
//  2- If the query is for another table, you should pass the id field you want to search for
async function loadTableParcial(table,arrayIdName,arrayIdValue,tableNode){
    var tbody = tableNode.querySelector("tbody");
    deleteContentElement(tbody);

    obj = await arrayToObj(table,arrayIdName,arrayIdValue);

    rows = await getAllRowsByParcialID(obj,table);
    if(rows != null){
        rows.forEach(element => {
            newRow(element,tableNode);
        });
    }
}
function prepareGetObject(){
    var inputs = document.querySelectorAll("[data-input]");

    var obj = new Object();
    for(var i = 0; i < headmatches.length;i++){
        if (headmatches[i].hasAttribute("data-pk")){
            obj[headmatches[i].getAttribute("name")] = formatValue(inputs[i].value);
        }else{
            obj[headmatches[i].getAttribute("name")] = null;
        }
    } 
    return obj;
}
async function getAllRowsByParcialID(obj,table){
    try{
        response = await GetRowsByParcialID(obj,table,attach);// Call Go function
        if(response.Ok) {
            return response.Structure;
        } else {
            alert(response.Msg);
        }
    }catch(error){
        alert(error)
    }
}
async function getRowByID(table,arrayIdName,arrayIdValue){
    obj = await arrayToObj(table,arrayIdName,arrayIdValue);
    row = await sendGetRowByID(obj,table)
    return row;
}
async function sendGetRowByID(obj,table){
    try{
        response = await GetRow(obj,table,attach);// Call Go function
        if(response.Ok) {
            return response.Structure;
        } else {
            if(response.Msg == "sql: no rows in result set"){
                return null;
            }else{
                return response.Msg;
            }
        }
    }catch(error){
        alert(error)
    }
}
function extractValue(element,nameField){
    var value ; 

    if(nameField != null || element.innerText != "🔎"){ //comprobar si no es un i!!!
        if (element.type == "checkbox"){
            value = element.checked;
        }else if (element.type == "select-one"){
            selected = element.options[element.selectedIndex];
            attr = selected.attributes.getNamedItem(nameField);    //First check if column value is the same
            if(attr == null){
                attr = selected.attributes.getNamedItem("id");      //If dont check if column value is id
                if(attr == null ){
                    attr = selected.attributes.getNamedItem("dni"); //Finally check if column value is dni(for user table)
                }
            }
            value = formatValue(attr.value);
        }else if (element.getAttribute("data-type") == "nav"){
            value = element.querySelector(".active").value;
        }else {
            if(element.value!= ""){
                value = formatValue(element.value)
            } else {
                value = null;   
            }
        }
    }
    return value;
}

function prepareInputs(struct,inputs,tableName){
    //preguntar si existe data-pk

    // var obj = new Object();
    var entries = Object.entries(struct);
    inputs.forEach(element => {
        //we will obtain if the element contains information about the structure. 
        //if so, we will obtain your name and save it. 
        //This information could be in both the id and the name
        var nameField = null;
        var dataTable = element.attributes.getNamedItem("data-"+tableName);
        if(dataTable != null){
            if(struct.hasOwnProperty(dataTable.nodeValue)){
                nameField = dataTable.nodeValue;
            }
        }else{
            if(struct.hasOwnProperty(element.id)){
                nameField = element.id;
            }
        }

        if(nameField != null){
            var value;
            //if we have obtained the name of this attribute we will try to initialize the field of the structure. 
            //otherwise, we will continue with the next field.
            value = extractValue(element,nameField);
            struct[nameField] = value;
        }
    });

    return struct;
}
async function prepareRow(table,inputs){
    var obj;
    struct = await getStructure(table);
    obj = prepareInputs(struct,inputs,table);

    return obj;
}
async function insertRow(event){
    openWaitingModal();
    if(TABLE == "note"){
        var inputs;
        var obj;
        var response;
        var tableNode = document.querySelector("table[data-form]");
        if(checkValidation()){
            inputs = document.querySelectorAll("[data-note]");
            obj = await prepareRow("note",inputs);
            response = await CreateRow(obj,"note",attach);  

            if (response.Ok){
                var note = response.Structure;

                var noteInput = document.getElementById("id");
                noteInput.value = note.id;

                var seatInput = document.getElementById("seat");
                seatInput.value = note.seat;

                var sectionInput = document.getElementById("section");
                sectionInput.value = note.section;

                var conceptInput = document.getElementById("concept");
                conceptInput.value = note.concept;

                //newRow(note,tableNode);
                newRow(obj,tableNode);
                await loadAccountForm();
                unblockAllInputArea();
                cleanInputArea();
            }
        }
    }else{
        if(TABLE == "permission"){
            companyElement = document.getElementById("company")
            attach = formatValue(companyElement.options[companyElement.selectedIndex].id);
        }
        if(checkValidation()){
            inputs = document.querySelectorAll("[data-input]");
            obj = await prepareRow(TABLE,inputs);
            if(obj!= null){
                if(IS_AUTOINCREMENT){
                    obj.id = null;
                }   
                obj = await sendInsertRow(obj,TABLE);
                var tableNode = document.querySelector("table[data-form]");
                newRow(obj,tableNode);
            }
        }
    }
    closeWaitingModal();
   
}
async function sendInsertRow(obj,table){
    try{
        if(table =="user"){
            response = await SignUp(obj.dni,obj.name,obj.email,obj.role,obj.pass);// Call Go function
            if(!response.Ok){
                alert(response.Msg);
            }
        }else{
            response = await CreateRow(obj,table,attach);// Call Go function
            if(!response.Ok){
                alert(response.Msg);
            }
        }
    }catch(error){
        alert(error)
    }
    if(IS_AUTOINCREMENT) {
        obj.id = response.Msg;
    }
    return obj;
}


const newRowB = IS_FORM ? document.getElementById("newRowB"):null;
const modifyRowB = IS_FORM ? document.getElementById("modifyRowB"):null;
const cancelModifyRowB = IS_FORM ? document.getElementById("cancelModifyRowB"):null;
const form = IS_FORM ? document.getElementById("form"):null;
const headmatches = IS_TABLE ? document.querySelectorAll("[data-head= true]"):null;
var attach  = 0 ;
if(TABLE == "acyear"){
    attach = formatValue(document.getElementById("company").value);
}

function haveButtonsForm(){
    if(IS_FORM){
        showInsertButton();
        newRowB.addEventListener('click', insertRow);
        modifyRowB.addEventListener('click', updateRow);
        cancelModifyRowB.addEventListener('click', cancelUpdateRow);
    }
}
function cancelUpdateRow(){
    var inputs = document.querySelectorAll("[data-input]");
    clearInputs(inputs);
    showInsertButton();
}
function showModifyButton(){
    newRowB.parentNode.style.display = "none";
    modifyRowB.parentNode.style.display = "block";
    cancelModifyRowB.parentNode.style.display = "block";
}
function showInsertButton(){
    newRowB.parentNode.style.display = "block";
    modifyRowB.parentNode.style.display = "none";
    cancelModifyRowB.parentNode.style.display = "none";
}
function disabledFormButton(){
    newRowB.disabled = true;
    modifyRowB.disabled = true;
    cancelModifyRowB.disabled = true;
}
function enabledFormButton(){
    newRowB.disabled = false;
    modifyRowB.disabled = false;
    cancelModifyRowB.disabled = false;
}

async function loadSelect(select,table,arrayValues){
    response = await GetRows(table,attach);

    if (response.Structure != null){
        response.Structure.forEach(element => {
            if((table != "user" )|| (table == "user" && element.role=="client")){//if get user rows table only load the users are client
                var option = document.createElement('option');
                var label = "";
                for(var i = 0; i < arrayValues.length;i++){
                    nombre = arrayValues[i];
                    valor = element[arrayValues[i]];
                    option.setAttribute(nombre,valor);
                    option.setAttribute("name",valor);
                    label = label +" "+ nombre+": "+ valor;
                }
                option.innerText = label;
                select.appendChild(option);
            }
        });
    }
}

function checkSelect(value){
    var inputs = document.querySelectorAll("[data-input]");
    var result = true;
    if(value.includes("...")){
        disabledInputs(inputs);
        if(IS_FORM){
            disabledFormButton();
        }
        result = false;
    }else{
        enabledInputs(inputs);
        if(IS_FORM){
            enabledFormButton();
        }
    }
    return result;
}
async function onChanges(event){
    openWaitingModal();
    changeListView(event);
    await loadNote();
    closeWaitingModal();
}

function changeFilter(event){
    changeListView(event);
}
async function onAccount(event){
    validNumber(event);
    loadAccountForm();
}
function changeListView(event){
    a = event.target;
    ul = a.parentNode.parentNode;

    links = ul.querySelectorAll("a");

    links.forEach(element => {
        if(element.id == a.id){
            element.classList.add("active");
        }else{
            element.classList.remove("active");
        }
    });
}

$('body').on('click', function (e) {
    $('[data-toggle="popover"]').each(function () {
        //the 'is' for buttons that trigger popups
        //the 'has' for icons within a button that triggers a popup
        if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            // $(this).popover('hide');
            $('.popover').remove();
        }
    });
});

async function loadPopover(event){

    openWaitingModal();
    var table = event.getAttribute("data-table");
    var tableNode = document.querySelector("table[data-table ='"+table+"']");
    await loadTable(table,tableNode)

    var tbody = tableNode.querySelector("tbody");

    if(tbody.hasChildNodes()){
        $('.popper').popover({
            placement: 'top',
            container: 'body',
            html: true,
            content: function () {
                return $(this).next('.popper-content').html();
            }
            });
        $(event).popover('show')
    }
    closeWaitingModal();
}
async function loadPopoverParcial(event){
    openWaitingModal();
    var table = event.getAttribute("data-table");
    var tableNode = document.querySelector("table[data-table ='"+table+"']");

    var idName = event.getAttribute("data-load-parcial-name");
    var nodeValue = document.getElementById(idName);
    var idValue = extractValue(nodeValue,idName);

    await loadTableParcial(table,[idName],[idValue],tableNode);

    var tbody = tableNode.querySelector("tbody");

    if(tbody.hasChildNodes()){
        $('.popper').popover({
            placement: 'top',
            container: 'body',
            html: true,
            content: function () {
                return $(this).next('.popper-content').html();
            }
            });
        $(event).popover('show')
    }
    closeWaitingModal();
}
async function loadPopoverRow(event){
    openWaitingModal();
    tableNode = event.parentNode.parentNode;
    tableName = tableNode.getAttribute("data-table");
    inputs = document.querySelectorAll("[data-"+tableName+"]");
    clearInputs(inputs);
    disabledInputs(inputs);
    unlock = document.getElementById("unlock"+tableName);
    unlock. removeAttribute("hidden");
    
    obj = await createObjectOfRow(event,tableNode);

    var entries = Object.entries(obj);

    entries.forEach(element => {
        array = Array.from(inputs);
        
        indexOf = array.findIndex(x => x.attributes.getNamedItem("data-"+tableName).nodeValue  === element[0]);

        if (indexOf != -1){

            input = inputs[indexOf];

            if(input.type == "checkbox"){
                input.checked = element[1] ;
            }else if(input.type == "date"){
                $('#'+input.id).val(element[1]);
            }else if(input.type == "select-one"){
                input.value = element[1];
            }else{
                if(input.hasAttribute("data-pk")){
                    input.value = element[1];
                }else{
                    input.placeholder = element[1];
                }
            }
        }

    });
    if (tableName == "account"){
        loadAccountForm();
    }

    //hide popover!
    $(event.parentNode.parentNode.parentNode.parentNode.parentNode).popover('hide')

    closeWaitingModal();
}
function cleanInputArea(event){
    if (event == null){
        dataTable = "data-input";
    }else{
        dataTable = event.getAttribute("data-area");
    }
    inputs = document.querySelectorAll("["+dataTable+"]");
    enabledInputs(inputs);
    clearInputs(inputs);
    
    if(dataTable == "data-input"){
        showInsertButton();
    }
}

function unblockInputArea(event){
    dataTable = event.getAttribute("data-area");
    inputs = document.querySelectorAll("["+dataTable+"]");
    enabledInputs(inputs);
    event.setAttribute("hidden","");

}
function unblockAllInputArea(){

    unblockButtons = document.querySelectorAll("[id^='unlock']");

    unblockButtons.forEach(element => {
        dataTable = element.getAttribute("data-area");
        inputs = document.querySelectorAll("["+dataTable+"]");
        enabledInputs(inputs);
        element.setAttribute("hidden","");
    });

}

async function changeForm(event){
    openWaitingModal();
				
    var acyearcompany = document.getElementById("acyearcompany");
    var id = acyearcompany.value;

    company = document.getElementById("company");
    acyear = document.getElementById("acyear");
    if(checkSelect(id)){
        //Use the accounting year to load the journal ids of accounting year
        struct = await getStructure("journal");
        option = event.target[event.target.selectedIndex];
        struct.ac_year = formatValue(option.attributes.id.nodeValue);
        struct.company = formatValue(option.attributes.company.nodeValue);

        company.value = struct.company;
        attach = formatValue(company.value);

        acyear.value = struct.ac_year;
        

        journals= await getAllRowsByParcialID(struct,"journal");
        navEraser = document.getElementById("navEraser");
        navGeneral = document.getElementById("navGeneral");
        if(TABLE == "note"){
            journals.forEach(element => {
                if(element.general == 0){
                    navGeneral.value = element.id;
                }else{
                    navEraser.value = element.id;
                }
            });
            await loadNote();

            //Load the Select of Filter with Sections
            var filterselect = document.getElementById("filter");
            await deleteContentElement(filterselect);
            var option = document.createElement("option");
            option.text = "All";
            option.name = "";
            filterselect.add(option);
            await loadSelect(filterselect,"section",["title"]);

            var formNotes = document.getElementById("form-notes");
            if(await loadWritePermission(attach)){
                if(formNotes.hasAttribute("hidden")){
                    formNotes.removeAttribute("hidden");  
                }
            }else{
                if(!formNotes.hasAttribute("hidden")){
                    formNotes.setAttribute("hidden","");
                }
            }
        }
    }else{
        company.value = "";
        acyear.value  = "";
        if(TABLE == "note"){
            var tableNode = document.querySelector("table[data-table='note']");
            var tbody = tableNode.querySelector("tbody");
            deleteContentElement(tbody);
        }
    }
    closeWaitingModal();
}
async function loadWritePermission(company){
    try{
        permission = await PermissionCompany(company);// Call Go function
        if(permission.write_permission) {
            return true;
        } else {
            return false;
        }
    }catch(error){
        alert(error)
    }
}
async function loadNote(){
    var journals = document.getElementById("journal");
    var journalSelect = journals.querySelector(".active").value;
    
    var tableNode = document.querySelector("table[data-form]");
    await loadTableParcial(TABLE,["journal"],[journalSelect],tableNode);
}

function myFunction() {
    var element, filter, table, tr, td, i;
    element = document.getElementById("filter");
    filter = element.options[element.selectedIndex].title.toLowerCase();
    table = document.getElementById("table");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[5];//5 its the section index
      td2 = tr[i].getElementsByTagName("td");
      if (td) {
        if (td.innerHTML.toLowerCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }
  }


tbody = document.getElementById("tbody");
updateJ = document.getElementById("updateJ");

$("#table").bind("DOMSubtreeModified", function() {

    if (tbody.children.length == 0){
        updateJ.setAttribute("disabled","")
    }else{
        updateJ.removeAttribute("disabled")
    }
});