package utils

import (
	"encoding/base64"
	"encoding/binary"
	"math"
	"math/rand"
	"time"
)

//Resp Response type recieve from the server a msg and token
type Resp struct {
	Ok    bool
	Token string
	Msg   string
}

//RespData Response type recieve from the server a msg and structure of table
type RespData struct {
	Ok        bool
	Msg       string
	Structure interface{}
}

//Only readable characters to avoid problems with json
const letterBytes = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

//RandStringBytes generates random readable array of bytes to be used as salt
func RandStringBytes(n int) []byte {
	rand.Seed(time.Now().UTC().UnixNano())
	b := make([]byte, n)
	for i := range b {
		b[i] = letterBytes[rand.Intn(len(letterBytes))]
	}
	return b
}

//Encode64 take a []bytes to base64 string
func Encode64(data []byte) string {
	return base64.StdEncoding.EncodeToString(data)
}

//Decode64 take a base64 string to []bytes
func Decode64(s string) []byte {
	b, err := base64.StdEncoding.DecodeString(s)
	if err != nil {
		panic(err)
	}
	return b
}

//Float64frombytes convert []byte to float64
func Float64frombytes(bytes []byte) float64 {
	bits := binary.LittleEndian.Uint64(bytes)
	float := math.Float64frombits(bits)
	return float
}

//Float64bytes convert a float64 to []byte
func Float64bytes(float float64) []byte {
	bits := math.Float64bits(float)
	bytes := make([]byte, 8)
	binary.LittleEndian.PutUint64(bytes, bits)
	return bytes
}
