package main

import (
	"crypto/sha256"
	"fmt"
	"net/http"
	"os"

	"github.com/gorilla/mux"

	"./models"
	"./routes"
	"./utils"
	"syscall"
	"golang.org/x/crypto/ssh/terminal")

func insertCredentials() ([]byte, []byte) {

	fmt.Println("Please, insert user:")
	byteDNI, err := terminal.ReadPassword(int(syscall.Stdin))
	if err != nil {
		panic(err)
	}

	fmt.Println("Please, insert password:")
	bytePassword, err := terminal.ReadPassword(int(syscall.Stdin))

	if err != nil {
		panic(err)
	}

	return byteDNI, bytePassword
}
func passClient(pass []byte) ([]byte, error) {
	hash := sha256.New()
	_, err := hash.Write(pass)
	if err != nil {
		panic(err)
	}
	passwordHashed := hash.Sum(nil)
	return passwordHashed[16:], nil
}

//insertFirstAdmin create an administrator as if a request from the client were.
func insertFirstAdmin() {

	fmt.Println("------------------------------------------------------------------------")
	fmt.Println("To run the server for the first time, first choose username and password")
	fmt.Println("------------------------------------------------------------------------")
	fmt.Println("user:admin, password:admin")
	fmt.Println("------------------------------------------------------------------------")
	byteDNI := []byte("admin")
	bytePassword := []byte("admin")

	u := models.User{
		DNI: string(byteDNI),
	}

	passClient, err := passClient(bytePassword)
	if err != nil {
		panic(err)
	}
	u.Hash(passClient, utils.RandStringBytes(10))
	u.Role = "superadmin"
	err = models.InsertUser(&u)

	if err != nil {
		panic(err)
	} else {
		fmt.Println("Admin Create.Please modify the credentials for more secure.")
	}
}

//enterAdmin will perform the function of asking for username and password of our system to be able to validate our server
//	If it returns true, it means that the login was successful.
//	In another case, the login has failed and the user will be asked to re-enter it
func enterAdmin() bool {
	result := false
	byteDNI, bytePassword := insertCredentials()
	admin, err := models.GetUserByDNI(string(byteDNI))

	if err != nil {
		fmt.Println("Invalid credentials.")
	}
	if admin != nil {
		if admin.Role == "admin" {
			passClient, err := passClient(bytePassword)
			if err != nil {
				panic(err)
			}
			result = admin.CompareHash(passClient)
			if !result {
				fmt.Println("Invalid credentials.")
				fmt.Println(result)
			}
		} else {
			fmt.Println("Invalid user. Most be administrator.")
		}
	}

	return result
}

//createDB is used to create both the database and all its tables. We will also insert the first system administrator user
func createDB() {
	//Create the database and tables
	err := models.CreateCompanyTable()
	if err != nil {
		panic(err)
	}
	err = models.CreateUserTable()
	if err != nil {
		panic(err)
	}
	err = models.CreatePermisionTable()
	if err != nil {
		panic(err)
	}
	err = models.CreateAcYearTable()
	if err != nil {
		panic(err)
	}
	//Create the server admin
	insertFirstAdmin()
}
func main() {

	r := mux.NewRouter()
	routes.RegisterCompanyRoutes(r)
	routes.RegisterAcYearRoutes(r)
	routes.RegisterUserRoutes(r)
	routes.RegisterCredentialRoutes(r)
	routes.RegisterPermissionRoutes(r)
	routes.RegisterJournalRoutes(r)
	routes.RegisterSectionRoutes(r)
	routes.RegisterConceptRoutes(r)
	routes.RegisterSeatRoutes(r)
	routes.RegisterNoteRoutes(r)
	routes.RegisterAccountRoutes(r)
	routes.RegisterJournalSeatRoutes(r)
	routes.RegisterPDFRoutes(r)

	http.Handle("/", r)

	if _, err := os.Stat("./database.db"); os.IsNotExist(err) {
		createDB()
	} else {
		for {
			ok := enterAdmin()
			if ok {
				break
			}
		}
	}

	fmt.Println("Server ON")
	err := http.ListenAndServeTLS(":9043", "autentication/certificate/https/server.crt", "autentication/certificate/https/server.key", nil)
	if err != nil {
		panic(err)
	}
}
