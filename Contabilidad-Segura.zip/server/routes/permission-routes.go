package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterPermissionRoutes define all the routes for permission table
var RegisterPermissionRoutes = func(router *mux.Router) {
	router.HandleFunc("/permission/", c.ValidateTokenMiddleware(c.CreatePermission)).Methods("POST")
	//router.HandleFunc("/permission/", c.ValidateTokenMiddleware(c.GetPermission)).Methods("GET")
	router.HandleFunc("/permission_id/", c.ValidateTokenMiddleware(c.GetPermissionByID)).Methods("POST")
	router.HandleFunc("/permission_parcial_id/", c.ValidateTokenMiddleware(c.GetPermissionParcialID)).Methods("POST")
	router.HandleFunc("/permission/", c.ValidateTokenMiddleware(c.UpdatePermission)).Methods("PUT")
	router.HandleFunc("/permission/", c.ValidateTokenMiddleware(c.DeletePermission)).Methods("DELETE")
	router.HandleFunc("/permission_struct/", c.ValidateTokenMiddleware(c.GetPermissionStruct)).Methods("GET")

}
