package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterUserRoutes define all the routes for user table
var RegisterUserRoutes = func(router *mux.Router) {
	router.HandleFunc("/user/", c.ValidateTokenMiddleware(c.CreateUser)).Methods("POST")
	router.HandleFunc("/user/", c.ValidateTokenMiddleware(c.GetUser)).Methods("GET")
	router.HandleFunc("/user_id/", c.ValidateTokenMiddleware(c.GetUserByID)).Methods("POST")
	router.HandleFunc("/user/", c.ValidateTokenMiddleware(c.UpdateUser)).Methods("PUT")
	router.HandleFunc("/user/", c.ValidateTokenMiddleware(c.DeleteUser)).Methods("DELETE")
	router.HandleFunc("/user_struct/", c.ValidateTokenMiddleware(c.GetUserStruct)).Methods("GET")
	router.HandleFunc("/userclient/", c.ValidateTokenMiddleware(c.GetUserByIDClient)).Methods("POST")
}
