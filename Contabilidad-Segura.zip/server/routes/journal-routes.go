package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterJournalRoutes define all the routes for journal table
var RegisterJournalRoutes = func(router *mux.Router) {
	router.HandleFunc("/journal/{company}", c.ValidateTokenMiddleware(c.CreateJournal)).Methods("POST")
	router.HandleFunc("/journal_get/{company}", c.ValidateTokenMiddleware(c.GetJournal)).Methods("POST")
	router.HandleFunc("/journal_id/{company}", c.ValidateTokenMiddleware(c.GetJournalByID)).Methods("POST")
	router.HandleFunc("/journal_parcial_id/{company}", c.ValidateTokenMiddleware(c.GetJournalByAcYear)).Methods("POST")
	router.HandleFunc("/journal/{company}", c.ValidateTokenMiddleware(c.UpdateJournal)).Methods("PUT")
	router.HandleFunc("/journal/{company}", c.ValidateTokenMiddleware(c.DeleteJournal)).Methods("DELETE")
	router.HandleFunc("/journal_struct/", c.ValidateTokenMiddleware(c.GetJournalStruct)).Methods("GET")
}
