package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterJournalSeatRoutes define all the routes for journalseat table
var RegisterJournalSeatRoutes = func(router *mux.Router) {
	router.HandleFunc("/journalseat/{company}", c.ValidateTokenMiddleware(c.CreateJournalSeat)).Methods("POST")
	router.HandleFunc("/journalseat_id/{company}", c.ValidateTokenMiddleware(c.GetJournalSeatByID)).Methods("POST")
	router.HandleFunc("/journalseat_struct/", c.ValidateTokenMiddleware(c.GetJournalSeatStruct)).Methods("GET")
}
