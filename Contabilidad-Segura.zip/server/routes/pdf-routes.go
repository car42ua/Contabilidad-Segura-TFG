package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterPDFRoutes define all the routes for pdf table
var RegisterPDFRoutes = func(router *mux.Router) {
	router.HandleFunc("/pdf_journal/{company}", c.ValidateTokenMiddleware(c.CreateJournalPDF)).Methods("POST")
	router.HandleFunc("/pdf_account/{company}", c.ValidateTokenMiddleware(c.CreateAccountPDF)).Methods("POST")
}
