package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterAcYearRoutes define all the routes for acyear table
var RegisterAcYearRoutes = func(router *mux.Router) {
	router.HandleFunc("/acyear/{id}", c.ValidateTokenMiddleware(c.CreateAcYear)).Methods("POST")
	router.HandleFunc("/acyear/", c.ValidateTokenMiddleware(c.GetAcYear)).Methods("GET")
	router.HandleFunc("/acyear_id/", c.ValidateTokenMiddleware(c.GetAcYearByID)).Methods("POST")
	router.HandleFunc("/acyear_parcial_id/", c.ValidateTokenMiddleware(c.GetAcYearParcialID)).Methods("POST")
	router.HandleFunc("/acyear/", c.ValidateTokenMiddleware(c.UpdateAcYear)).Methods("PUT")
	router.HandleFunc("/acyear/", c.ValidateTokenMiddleware(c.DeleteAcYear)).Methods("DELETE")
	router.HandleFunc("/acyear_struct/", c.ValidateTokenMiddleware(c.GetAcYearStruct)).Methods("GET")
}
