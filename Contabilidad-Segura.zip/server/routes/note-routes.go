package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterNoteRoutes define all the routes for note table
var RegisterNoteRoutes = func(router *mux.Router) {
	router.HandleFunc("/note/{company}", c.ValidateTokenMiddleware(c.CreateNote)).Methods("POST")
	//router.HandleFunc("/note/", c.ValidateTokenMiddleware(c.GetNote)).Methods("GET")
	router.HandleFunc("/note_id/{company}", c.ValidateTokenMiddleware(c.GetNoteByID)).Methods("POST")
	router.HandleFunc("/note_parcial_id/{company}", c.ValidateTokenMiddleware(c.GetNoteParcialID)).Methods("POST")
	router.HandleFunc("/note/{company}", c.ValidateTokenMiddleware(c.UpdateNote)).Methods("PUT")
	router.HandleFunc("/note/{company}", c.ValidateTokenMiddleware(c.DeleteNote)).Methods("DELETE")
	router.HandleFunc("/note_struct/", c.ValidateTokenMiddleware(c.GetNoteStruct)).Methods("GET")
	router.HandleFunc("/note_count/{company}", c.ValidateTokenMiddleware(c.GetNoteCount)).Methods("POST")
}
