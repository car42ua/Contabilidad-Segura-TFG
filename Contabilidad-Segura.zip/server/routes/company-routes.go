package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterCompanyRoutes define all the routes for company table
var RegisterCompanyRoutes = func(router *mux.Router) {
	router.HandleFunc("/company/", c.ValidateTokenMiddleware(c.CreateCompany)).Methods("POST")
	router.HandleFunc("/company/", c.ValidateTokenMiddleware(c.GetCompany)).Methods("GET")
	router.HandleFunc("/company_id/", c.ValidateTokenMiddleware(c.GetCompanyByID)).Methods("POST")
	router.HandleFunc("/company/", c.ValidateTokenMiddleware(c.UpdateCompany)).Methods("PUT")
	router.HandleFunc("/company/", c.ValidateTokenMiddleware(c.DeleteCompany)).Methods("DELETE")
	router.HandleFunc("/company_struct/", c.ValidateTokenMiddleware(c.GetCompanyStruct)).Methods("GET")
}
