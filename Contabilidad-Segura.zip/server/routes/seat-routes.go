package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterSeatRoutes define all the routes for seat table
var RegisterSeatRoutes = func(router *mux.Router) {
	router.HandleFunc("/seat/{company}", c.ValidateTokenMiddleware(c.CreateSeat)).Methods("POST")
	router.HandleFunc("/seat_get/{company}", c.ValidateTokenMiddleware(c.GetSeat)).Methods("POST")
	router.HandleFunc("/seat_id/{company}", c.ValidateTokenMiddleware(c.GetSeatByID)).Methods("POST")
	router.HandleFunc("/seat_parcial_id/{company}", c.ValidateTokenMiddleware(c.GetSeatParcialID)).Methods("POST")
	router.HandleFunc("/seat/{company}", c.ValidateTokenMiddleware(c.UpdateSeat)).Methods("PUT")
	router.HandleFunc("/seat/{company}", c.ValidateTokenMiddleware(c.DeleteSeat)).Methods("DELETE")
	router.HandleFunc("/seat_struct/", c.ValidateTokenMiddleware(c.GetSeatStruct)).Methods("GET")
}
