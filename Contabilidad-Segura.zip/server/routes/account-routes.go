package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterAccountRoutes define all the routes for account table
var RegisterAccountRoutes = func(router *mux.Router) {
	router.HandleFunc("/account/{company}", c.ValidateTokenMiddleware(c.CreateAccount)).Methods("POST")
	router.HandleFunc("/account_get/{company}", c.ValidateTokenMiddleware(c.GetAccount)).Methods("POST")
	router.HandleFunc("/account_id/{company}", c.ValidateTokenMiddleware(c.GetAccountByID)).Methods("POST")
	router.HandleFunc("/account_parcial_id/{company}", c.ValidateTokenMiddleware(c.GetAccountParcialID)).Methods("POST")
	router.HandleFunc("/account/{company}", c.ValidateTokenMiddleware(c.UpdateAccount)).Methods("PUT")
	router.HandleFunc("/account/{company}", c.ValidateTokenMiddleware(c.DeleteAccount)).Methods("DELETE")
	router.HandleFunc("/account_struct/", c.ValidateTokenMiddleware(c.GetAccountStruct)).Methods("GET")
}
