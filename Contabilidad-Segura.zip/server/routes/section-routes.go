package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterSectionRoutes define all the routes for section table
var RegisterSectionRoutes = func(router *mux.Router) {
	router.HandleFunc("/section/{company}", c.ValidateTokenMiddleware(c.CreateSection)).Methods("POST")
	router.HandleFunc("/section_get/{company}", c.ValidateTokenMiddleware(c.GetSection)).Methods("POST")
	router.HandleFunc("/section_id/{company}", c.ValidateTokenMiddleware(c.GetSectionByID)).Methods("POST")
	router.HandleFunc("/section/{company}", c.ValidateTokenMiddleware(c.UpdateSection)).Methods("PUT")
	router.HandleFunc("/section/{company}", c.ValidateTokenMiddleware(c.DeleteSection)).Methods("DELETE")
	router.HandleFunc("/section_struct/", c.ValidateTokenMiddleware(c.GetSectionStruct)).Methods("GET")
}
