package routes

import (
	"github.com/gorilla/mux"

	c "../controllers"
)

//RegisterConceptRoutes define all the routes for concept table
var RegisterConceptRoutes = func(router *mux.Router) {
	router.HandleFunc("/concept/{company}", c.ValidateTokenMiddleware(c.CreateConcept)).Methods("POST")
	router.HandleFunc("/concept_get/{company}", c.ValidateTokenMiddleware(c.GetConcept)).Methods("POST")
	router.HandleFunc("/concept_id/{company}", c.ValidateTokenMiddleware(c.GetConceptByID)).Methods("POST")
	router.HandleFunc("/concept/{company}", c.ValidateTokenMiddleware(c.UpdateConcept)).Methods("PUT")
	router.HandleFunc("/concept/{company}", c.ValidateTokenMiddleware(c.DeleteConcept)).Methods("DELETE")
	router.HandleFunc("/concept_struct/", c.ValidateTokenMiddleware(c.GetConceptStruct)).Methods("GET")
}
