package routes

import (
	"github.com/gorilla/mux"

	a "../autentication"
	c "../controllers"
)

//RegisterCredentialRoutes define all the routes for credential of server
var RegisterCredentialRoutes = func(router *mux.Router) {
	router.HandleFunc("/login/", c.LoginUser).Methods("POST")
	router.HandleFunc("/keys/", c.ValidateTokenMiddleware(c.GetKeys)).Methods("GET")
	router.HandleFunc("/superadmin/", c.ValidateTokenMiddleware(c.ValidateAndEraseSA)).Methods("GET")
	router.HandleFunc("/registerSuper/", c.ValidateTokenMiddleware(c.CreateUser)).Methods("POST")
	router.HandleFunc("/refreshToken/", c.ValidateTokenMiddleware(c.RefreshToken)).Methods("GET")
	router.HandleFunc("/publickeyserver/", c.ValidateTokenMiddleware(a.GetPublicKeyFromServer)).Methods("GET")

}
