package autentication

import (
	"crypto/rsa"
	"encoding/json"
	"io/ioutil"
	"net/http"

	jwt "github.com/dgrijalva/jwt-go"
)

var (
	publicBytesBD  []byte
	privateBytesBD []byte
	privateKeyBD   *rsa.PrivateKey
	publicKeyBD    *rsa.PublicKey
)

func init() {
	var err error
	privateBytesBD, err = ioutil.ReadFile("./autentication/privateKey.pem")
	if err != nil {
		panic(err)
	}

	publicBytesBD, err = ioutil.ReadFile("autentication/publicKey.pem")
	if err != nil {
		panic(err)
	}

	privateKeyBD, err = jwt.ParseRSAPrivateKeyFromPEM(privateBytesBD)
	if err != nil {
		panic(err)
	}

	publicKeyBD, err = jwt.ParseRSAPublicKeyFromPEM(publicBytesBD)
	if err != nil {
		panic(err)
	}
}

//GetPublicKeyFromServer send to client the public key of server
func GetPublicKeyFromServer(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	rJSON, err := json.Marshal(&publicBytesBD)
	if err != nil {
		panic(err)
	}
	w.Write(rJSON)
}
