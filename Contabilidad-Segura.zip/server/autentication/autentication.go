package autentication

import (
	"crypto/rsa"
	"fmt"
	"io/ioutil"
	"net/http"
	"time"

	"../models"
	jwt "github.com/dgrijalva/jwt-go"
	"github.com/dgrijalva/jwt-go/request"
)

var (
	publicBytes  []byte
	privateBytes []byte
	privateKey   *rsa.PrivateKey
	publicKey    *rsa.PublicKey
)

func init() {
	var err error
	privateBytes, err = ioutil.ReadFile("./autentication/privateToken.rsa")
	if err != nil {
		panic(err)
	}

	publicBytes, err = ioutil.ReadFile("autentication/publicToken.rsa.pub")
	if err != nil {
		panic(err)
	}

	privateKey, err = jwt.ParseRSAPrivateKeyFromPEM(privateBytes)
	if err != nil {
		panic(err)
	}

	publicKey, err = jwt.ParseRSAPublicKeyFromPEM(publicBytes)
	if err != nil {
		panic(err)
	}
}

//RefreshJWT refresh the token from user
func RefreshJWT(role, userDNI string) (string, error) {
	u := &models.User{
		DNI:  userDNI,
		Role: role,
	}
	return GenerateJWT(u)
}

//GenerateJWT create token for specified issuing user
func GenerateJWT(user *models.User) (string, error) {
	claims := models.Claim{
		UserDNI: user.DNI,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: time.Now().Add(time.Hour * 1).Unix(),
			Issuer:    user.Role,
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodRS256, claims)
	result, err := token.SignedString(privateKey)
	if err != nil {
		panic(err)
	}
	return result, nil
}

//ValidateJWT validate the token of the request
func ValidateJWT(w http.ResponseWriter, r *http.Request) bool {
	token, err := request.ParseFromRequestWithClaims(r, request.OAuth2Extractor, &models.Claim{}, func(token *jwt.Token) (interface{}, error) {
		return publicKey, nil
	})
	var isValid = false
	if err != nil {
		switch err.(type) {
		case *jwt.ValidationError:
			vErr := err.(*jwt.ValidationError)
			switch vErr.Errors {
			case jwt.ValidationErrorExpired:
				fmt.Println("token expired")
				return isValid
			case jwt.ValidationErrorSignatureInvalid:
				fmt.Println("signature invalid")
				return isValid
			default:
				fmt.Println("the token is invalid")
				return isValid
			}

		default:
			fmt.Println("the token is invalid")
			return isValid
		}
	}
	if token.Valid {
		isValid = true
	} else {
		fmt.Println("Your token is NOT valid")
	}

	return isValid
}

//GetClaims returns a struct of Claims to the request
func GetClaims(r *http.Request) (*models.Claim, error) {
	claims := new(models.Claim)
	token, err := request.ParseFromRequestWithClaims(r, request.OAuth2Extractor, &models.Claim{},
		func(token *jwt.Token) (interface{}, error) {
			return publicKey, nil
		})
	if err != nil {
		return claims, err
	}
	claims = token.Claims.(*models.Claim)

	return claims, nil
}

//IsAdmin return true if claims.StandardClaims.Issuer is administrator , false if is client
func IsAdmin(claims *models.Claim) bool {
	isAdmin := false
	if claims.StandardClaims.Issuer == "administrator" {
		isAdmin = true
	}
	return isAdmin
}
