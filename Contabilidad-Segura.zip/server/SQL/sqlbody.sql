PRAGMA foreign_keys = ON;

CREATE TABLE company(
	id INTEGER CONSTRAINT cpcompany PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(30),
    cif VARCHAR(9)
);

INSERT INTO company VALUES(001,"Pepes Company","12345678L");
INSERT INTO company VALUES(002,"Lennon Bones","87654321H");
INSERT INTO company VALUES(003,"Ainara Horses","11122233A");

CREATE TABLE user(
    DNI TEXT PRIMARY KEY,
    email TEXT ,
    name TEXT,
    role TEXT,
    pass TEXT,
    salt TEXT,
    pubKey TEXT,
	privKey TEXT
);
INSERT INTO user VALUES("45837823L","pepe@hotmail.com","Pepe","admin","1234","X","http","pubKey");
INSERT INTO user VALUES("45897845P","lennon@hotmail.com","Lennon","client","1234","X","http","pubKey");
INSERT INTO user VALUES("78953214O","ainara@hotmail.com","Ainara","client","1234","X","http","pubKey");

CREATE TABLE permission(
    company INTEGER(3) NOT NULL,
    user TEXT NOT NULL,
    read_permission BOOL,
    write_permission BOOL,
    PRIMARY KEY(company,user),
    CONSTRAINT fkcompany FOREIGN KEY(company) REFERENCES company(id),
    CONSTRAINT fkuser FOREIGN KEY(user) REFERENCES user(dni)
);

INSERT INTO permission VALUES(001,"45837823L",1,1);
INSERT INTO permission VALUES(002,"45837823L",1,1);
INSERT INTO permission VALUES(003,"45837823L",1,0);
INSERT INTO permission VALUES(002,"45897845P",1,0);
INSERT INTO permission VALUES(003,"78953214O",0,0);


CREATE TABLE ac_year(
    id INTEGER(4),
    company INTEGER(3),
    open_date TEXT,
    close_date TEXT,
    opened BOOL,
    CONSTRAINT fkid FOREIGN KEY (company) REFERENCES company (id),
    CONSTRAINT cpac_year PRIMARY KEY(id,company)
);
INSERT INTO ac_year VALUES(2018,001,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2019,001,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2020,001,DATE('now'),DATE('now','+1 year'),1);
INSERT INTO ac_year VALUES(2018,002,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2019,002,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2020,002,DATE('now'),DATE('now','+1 year'),1);
INSERT INTO ac_year VALUES(2018,003,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2019,003,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2020,003,DATE('now'),DATE('now','+1 year'),1);

CREATE TABLE account(
    id INTEGER(8),
    company INTEGER(3),
    title VARCHAR(20),
    CONSTRAINT fkcompany FOREIGN KEY(company) REFERENCES company(id),
    CONSTRAINT cpaccount PRIMARY KEY(id,company)
);
INSERT INTO account VALUES(43000001,001,"Wine Tomasico S.L.");
INSERT INTO account VALUES(43000002,001,"Beer Juan S.L.");
INSERT INTO account VALUES(43000003,001,"Water José S.L.");
INSERT INTO account VALUES(43000004,001,"Gin Fulgencio S.L.");
INSERT INTO account VALUES(43000005,001,"Cola Carlos S.L.");
INSERT INTO account VALUES(43000001,002,"Wine Tomasico S.L.");
INSERT INTO account VALUES(43000002,002,"Beer Juan S.L.");
INSERT INTO account VALUES(43000003,002,"Water José S.L.");
INSERT INTO account VALUES(43000004,002,"Gin Fulgencio S.L.");
INSERT INTO account VALUES(43000005,002,"Cola Carlos S.L.");
INSERT INTO account VALUES(43000001,003,"Wine Tomasico S.L.");
INSERT INTO account VALUES(43000002,003,"Beer Juan S.L.");
INSERT INTO account VALUES(43000003,003,"Water José S.L.");
