PRAGMA foreign_keys = ON;

CREATE TABLE company(
	id INTEGER CONSTRAINT cpcompany PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(30),
    cif VARCHAR(9)
);
INSERT INTO company VALUES(001,"Pepes Company","12345678L");
INSERT INTO company VALUES(002,"Lennon Bones","87654321H");
INSERT INTO company VALUES(003,"Ainara Horses","11122233A");

CREATE TABLE user(
    DNI TEXT PRIMARY KEY,
    email TEXT ,
    name TEXT,
    role TEXT,
    pass TEXT,
    salt TEXT,
    pubKey TEXT,
	privKey TEXT
);
INSERT INTO user VALUES("45837823L","pepe@hotmail.com","Pepe","admin","1234","X","http","pubKey");
INSERT INTO user VALUES("45897845P","lennon@hotmail.com","Lennon","client","1234","X","http","pubKey");
INSERT INTO user VALUES("78953214O","ainara@hotmail.com","Ainara","client","1234","X","http","pubKey");

CREATE TABLE permission(
    company INTEGER(3) NOT NULL,
    user TEXT NOT NULL,
    read_permission BOOL,
    write_permission BOOL,
    PRIMARY KEY(company,user),
    CONSTRAINT fkcompany FOREIGN KEY(company) REFERENCES company(id),
    CONSTRAINT fkuser FOREIGN KEY(user) REFERENCES user(dni)
);

INSERT INTO permission VALUES(001,"45837823L",1,1);
INSERT INTO permission VALUES(002,"45837823L",1,1);
INSERT INTO permission VALUES(003,"45837823L",1,0);
INSERT INTO permission VALUES(002,"45897845P",1,0);
INSERT INTO permission VALUES(003,"78953214O",0,0);


CREATE TABLE ac_year(
    id INTEGER(4),
    company INTEGER(3),
    open_date TEXT,
    close_date TEXT,
    opened BOOL,
    CONSTRAINT fkid FOREIGN KEY (company) REFERENCES company (id),
    CONSTRAINT cpac_year PRIMARY KEY(id,company)
);
INSERT INTO ac_year VALUES(2018,001,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2019,001,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2020,001,DATE('now'),DATE('now','+1 year'),1);
INSERT INTO ac_year VALUES(2018,002,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2019,002,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2020,002,DATE('now'),DATE('now','+1 year'),1);
INSERT INTO ac_year VALUES(2018,003,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2019,003,DATE('now'),DATE('now','+1 year'),0);
INSERT INTO ac_year VALUES(2020,003,DATE('now'),DATE('now','+1 year'),1);

CREATE TABLE account(
    id INTEGER(8),
    company INTEGER(3),
    title VARCHAR(20),
    CONSTRAINT fkcompany FOREIGN KEY(company) REFERENCES company(id),
    CONSTRAINT cpaccount PRIMARY KEY(id,company)
);
INSERT INTO account VALUES(43000001,001,"Wine Tomasico S.L.");
INSERT INTO account VALUES(43000002,001,"Beer Juan S.L.");
INSERT INTO account VALUES(43000003,001,"Water José S.L.");
INSERT INTO account VALUES(43000004,001,"Gin Fulgencio S.L.");
INSERT INTO account VALUES(43000005,001,"Cola Carlos S.L.");
INSERT INTO account VALUES(43000001,002,"Wine Tomasico S.L.");
INSERT INTO account VALUES(43000002,002,"Beer Juan S.L.");
INSERT INTO account VALUES(43000003,002,"Water José S.L.");
INSERT INTO account VALUES(43000004,002,"Gin Fulgencio S.L.");
INSERT INTO account VALUES(43000005,002,"Cola Carlos S.L.");
INSERT INTO account VALUES(43000001,003,"Wine Tomasico S.L.");
INSERT INTO account VALUES(43000002,003,"Beer Juan S.L.");
INSERT INTO account VALUES(43000003,003,"Water José S.L.");

CREATE TABLE journal(
    id INTEGER CONSTRAINT cpjournal PRIMARY KEY AUTOINCREMENT,
    general INTEGER(4),
    ac_year INTEGER(4) NOT NULL,
    company INTEGER(3) NOT NULL,
    title VARCHAR(20),
    CONSTRAINT fkjournal FOREIGN KEY (ac_year,company)REFERENCES ac_year(id,company),
    CONSTRAINT fkjournale FOREIGN KEY (general) REFERENCES journal(id)
);
--Diario General, "1". Diario que se generará automaticamente al crear empresa nueva)
INSERT INTO journal VALUES(0001,NULL,2018,001,"Diario General");
INSERT INTO journal VALUES(0002,NULL,2019,001,"Diario General");
INSERT INTO journal VALUES(0003,NULL,2020,001,"Diario General");
INSERT INTO journal VALUES(0004,NULL,2018,002,"Diario General");
INSERT INTO journal VALUES(0005,NULL,2019,002,"Diario General");
INSERT INTO journal VALUES(0006,NULL,2020,002,"Diario General");
INSERT INTO journal VALUES(0007,NULL,2018,003,"Diario General");
INSERT INTO journal VALUES(0008,NULL,2019,003,"Diario General");
INSERT INTO journal VALUES(0009,NULL,2020,003,"Diario General");
INSERT INTO journal VALUES(0010,0001,2018,001,"Diario Borrador");
INSERT INTO journal VALUES(0011,0002,2019,001,"Diario Borrador");
INSERT INTO journal VALUES(0012,0003,2020,001,"Diario Borrador");
INSERT INTO journal VALUES(0013,0004,2018,002,"Diario Borrador");
INSERT INTO journal VALUES(0014,0005,2019,002,"Diario Borrador");
INSERT INTO journal VALUES(0015,0006,2020,002,"Diario Borrador");
INSERT INTO journal VALUES(0016,0007,2018,003,"Diario Borrador");
INSERT INTO journal VALUES(0017,0008,2019,003,"Diario Borrador");
INSERT INTO journal VALUES(0018,0009,2020,003,"Diario Borrador");

CREATE TABLE section(
    id INTEGER CONSTRAINT cpsection PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(20)
);
INSERT INTO section VALUES(01,"Ventas");
INSERT INTO section VALUES(02,"Cobros");
INSERT INTO section VALUES(03,"Otros asuntos");

CREATE TABLE concept(
    id INTEGER CONSTRAINT cpconcept PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(20)
);
INSERT INTO concept VALUES(01,"Concepto de venta");
INSERT INTO concept VALUES(02,"Concepto de cobros");
INSERT INTO concept VALUES(03,"Concepto de asuntos");

CREATE TABLE seat(
    id INTEGER(5),
    journal INTEGER(4),
    section INTEGER(2),
    seatdate TEXT,
    CONSTRAINT fkseat FOREIGN KEY (section) REFERENCES section(id),
    CONSTRAINT fkseat2 FOREIGN KEY (journal) REFERENCES journal(id),
    CONSTRAINT cpseat PRIMARY KEY (id,journal)
);
-- CREATE TABLE auto_increment (id INT, table_name TEXT);
-- INSERT INTO auto_increment VALUES (0, 'seat');

-- CREATE TRIGGER seatpk AFTER INSERT ON seat
-- BEGIN
--     UPDATE  auto_increment 
--     SET     id = id + 1 
--     WHERE   table_name = 'seat';

--     UPDATE  seat
--     SET     id = (
--                 SELECT id 
--                 FROM auto_increment 
--                 WHERE table_name = 'seat')
--     WHERE   ROWID = new.ROWID;
-- END;
CREATE TABLE auto_increment_seat (id INT, journal INT);

CREATE TRIGGER seat_bef_ins BEFORE INSERT ON seat
WHEN NOT EXISTS( SELECT 1 FROM auto_increment_seat 
                    WHERE (journal = new.journal))
BEGIN                   
        INSERT INTO auto_increment_seat (id,journal) VALUES (0,new.journal);
END;

CREATE TRIGGER seat_aft_ins AFTER INSERT ON seat
BEGIN
    UPDATE  auto_increment_seat
    SET     id = id + 1 
    WHERE   journal = new.journal ;

    UPDATE  seat
    SET     id = (
                SELECT id 
                FROM auto_increment_seat
                WHERE journal = new.journal)
    WHERE   ROWID = new.ROWID;
END;

-- --Insert seat on eraser journal
-- INSERT INTO seat VALUES(00001,0012,01,"2020-02-01");
-- INSERT INTO seat VALUES(00002,0012,01,"2020-02-02");
-- INSERT INTO seat VALUES(00003,0012,02,"2020-02-02");
-- INSERT INTO seat VALUES(00004,0012,02,"2020-02-04");
-- INSERT INTO seat VALUES(00005,0012,03,"2020-02-04");
-- --Insert seat on general journal 
-- INSERT INTO seat VALUES(00006,0003,01,"2020-01-01");
-- INSERT INTO seat VALUES(00007,0003,02,"2020-01-02");
-- INSERT INTO seat VALUES(00008,0003,02,"2020-01-02");
-- INSERT INTO seat VALUES(00009,0003,03,"2020-01-04");
-- INSERT INTO seat VALUES(00010,0003,01,"2020-01-04");
-- INSERT INTO seat VALUES(00006,0002,01,"2020-01-01");
-- INSERT INTO seat VALUES(00007,0002,02,"2020-01-02");
-- INSERT INTO seat VALUES(00008,0002,02,"2020-01-02");
-- INSERT INTO seat VALUES(00009,0002,03,"2020-01-04");
-- INSERT INTO seat VALUES(00010,0002,01,"2020-01-04");
-- INSERT INTO seat VALUES(00011,0006,01,"2020-01-15");
-- INSERT INTO seat VALUES(00012,0006,02,"2020-01-16");
-- INSERT INTO seat VALUES(00013,0006,02,"2020-01-16");
-- INSERT INTO seat VALUES(00014,0006,02,"2020-01-16");
-- INSERT INTO seat VALUES(00015,0006,02,"2020-01-19");

CREATE TABLE note(
    id INTEGER(8) CONSTRAINT cpnote,
    seat INTEGER(5),
    journal INTEGER (4),
    account INTEGER(8) NOT NULL,
    company INTEGER(3) NOT NULL,
    concept VARCHAR(20),
    amount DOUBLE(7,2),
    dc CHAR(1),
    CONSTRAINT fkaccount FOREIGN KEY(account,company) REFERENCES account(id,company),
    CONSTRAINT fkseat FOREIGN KEY(seat,journal) REFERENCES seat(id,journal),
    CONSTRAINT cpnote PRIMARY KEY (id,seat,journal)
);
-- INSERT INTO auto_increment VALUES (0, 'note');

-- CREATE TRIGGER notepk AFTER INSERT ON note
-- BEGIN
--     UPDATE  auto_increment 
--     SET     id = id + 1 
--     WHERE   table_name = 'note';

--     UPDATE  note
--     SET     id = (
--                 SELECT id 
--                 FROM auto_increment 
--                 WHERE table_name = 'note')
--     WHERE   ROWID = new.ROWID;
-- END;

CREATE TABLE auto_increment_note (id INT,seat INT, journal INT);

CREATE TRIGGER note_bef_ins  BEFORE INSERT ON note
WHEN NOT EXISTS( SELECT 1 FROM auto_increment_note
                    WHERE seat = new.seat
                        AND journal = new.journal)
BEGIN                   
        INSERT INTO auto_increment_note (id,seat,journal) VALUES (0,new.seat,new.journal);
END;

CREATE TRIGGER note_aft_ins  AFTER INSERT ON note
BEGIN
    UPDATE  auto_increment_note
    SET     id = id + 1 
    WHERE   seat = new.seat 
    AND  journal = new.journal ;

    UPDATE  note
    SET     id = (
                SELECT id 
                FROM auto_increment_note
                WHERE seat = new.seat
      			AND journal = new.journal)
    WHERE   ROWID = new.ROWID;
END;

CREATE TRIGGER note_bef_del AFTER DELETE ON note

	WHEN NOT EXISTS( SELECT 1 FROM note
                        WHERE seat = old.seat
                          AND journal = old.journal)
	BEGIN                   
          DELETE FROM seat 
          WHERE id = old.seat
          AND journal = old.journal;
    END;

CREATE TRIGGER note_bef_upd AFTER UPDATE ON note

	WHEN new.seat <> old.seat
    AND
    NOT EXISTS( SELECT 1 FROM note
                        WHERE seat = old.seat
                          AND journal = old.journal)
    BEGIN 
		DELETE FROM seat 
        WHERE id = old.seat
        AND journal = old.journal; 
    END;
-- INSERT INTO note VALUES(00000000,00006,0003,43000001,001,"Vinos Tarima",5000.5,"D");
-- INSERT INTO note VALUES(00000000,00006,0003,43000002,001,"Cobro 21%",4000.5,"H");
-- INSERT INTO note VALUES(00000000,00006,0003,43000003,001,"Comisión",1000,"H");
-- INSERT INTO note VALUES(00000000,00007,0002,43000001,002,"Vinos Tarima",5000.5,"D");
-- INSERT INTO note VALUES(00000000,00007,0002,43000002,002,"Cobro 21%",4000.5,"H");
-- INSERT INTO note VALUES(00000000,00007,0002,43000003,002,"Comisión",1000,"H");
-- INSERT INTO note VALUES(00000000,00008,0003,43000001,002,"Vinos Tarima",5000.5,"D");
-- INSERT INTO note VALUES(00000000,00008,0003,43000002,002,"Cobro 21%",4000.5,"H");
-- INSERT INTO note VALUES(00000000,00008,0003,43000003,002,"Comisión",1000,"H");
-- INSERT INTO note VALUES(00000000,00009,0002,43000001,003,"Vinos Tarima",5000.5,"D");
-- INSERT INTO note VALUES(00000000,00009,0002,43000002,003,"Cobro 21%",4000.5,"H");
-- INSERT INTO note VALUES(00000000,00009,0002,43000003,003,"Comisión",1000,"H");
-- INSERT INTO note VALUES(00000000,00010,0002,43000001,003,"Vinos Tarima",5000.5,"D");
-- INSERT INTO note VALUES(00000000,00010,0002,43000002,003,"Cobro 21%",4000.5,"H");
-- INSERT INTO note VALUES(00000000,00010,0002,43000003,003,"Comisión",1000,"H");


-- INSERT INTO seat VALUES(0000,0018,2,"2020-01-31");
-- INSERT INTO note VALUES(00000000,22,18,43000001,001,"Vinos Tarima",5000.5,"D");
-- INSERT INTO note VALUES(00000000,22,18,43000002,003,"Cobro 21%",4000.5,"H");
-- INSERT INTO note VALUES(00000000,22,18,43000003,003,"Comisión",1000,"H");





-- CREATE TABLE client(
--     dni TEXT PRIMARY KEY, 
--     CONSTRAINT fkuser FOREIGN KEY(dni) REFERENCES user(dni)
-- );
-- INSERT INTO client VALUES("45897845P");
-- INSERT INTO client VALUES("78953214O");

-- CREATE TABLE administrator(
--     dni TEXT  PRIMARY KEY,
--     CONSTRAINT fkuser FOREIGN KEY(dni) REFERENCES user(dni)
-- );
-- INSERT INTO administrator VALUES("45837823L");
