

CREATE TABLE section(
    id INTEGER CONSTRAINT cpsection PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(20)
);
INSERT INTO section VALUES(01,"Ventas");
INSERT INTO section VALUES(02,"Cobros");
INSERT INTO section VALUES(03,"Otros asuntos");

CREATE TABLE concept(
    id INTEGER CONSTRAINT cpconcept PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(20)
);
INSERT INTO concept VALUES(01,"Concepto de venta");
INSERT INTO concept VALUES(02,"Concepto de cobros");
INSERT INTO concept VALUES(03,"Concepto de asuntos");


--have tables of body
CREATE TABLE journal(
    id INTEGER CONSTRAINT cpjournal PRIMARY KEY AUTOINCREMENT,
    general INTEGER(4),
    ac_year INTEGER(4) NOT NULL,
    company INTEGER(3) NOT NULL,
    title VARCHAR(20),
    CONSTRAINT fkjournal FOREIGN KEY (ac_year,company)REFERENCES ac_year(id,company),
    CONSTRAINT fkjournale FOREIGN KEY (general) REFERENCES journal(id)
);
CREATE TABLE seat(
    id INTEGER CONSTRAINT cpseat PRIMARY KEY AUTOINCREMENT,
    section INTEGER(2),
    seatdate TEXT,
    CONSTRAINT fkseat FOREIGN KEY (section) REFERENCES section(id)
);
CREATE TRIGGER seat_aft_del AFTER DELETE ON seat

	BEGIN                   
          DELETE FROM journalseat
          WHERE seat = seat;

          DELETE FROM auto_increment_note
          WHERE seat = seat; 
    END;
CREATE TABLE journalseat(
    journal INTEGER NOT NULL,
    seat INTEGER NOT NULL,
    PRIMARY KEY(journal,seat),
    CONSTRAINT fkjournal FOREIGN KEY(journal) REFERENCES journal(id),
    CONSTRAINT fkseat FOREIGN KEY(seat) REFERENCES seat(id)
);

--have tables of body
CREATE TABLE note(
    id INTEGER(8) CONSTRAINT cpnote,
    seat INTEGER,
    account INTEGER(8) NOT NULL,
    company INTEGER(3) NOT NULL,
    concept VARCHAR(20),
    amount DOUBLE(7,2),
    dc CHAR(1),
    CONSTRAINT fkaccount FOREIGN KEY(account,company) REFERENCES account(id,company),
    CONSTRAINT fkseat FOREIGN KEY(seat) REFERENCES seat(id),
    CONSTRAINT cpnote PRIMARY KEY (id,seat)
);
CREATE TABLE auto_increment_note (id INT, seat INT);

CREATE TRIGGER note_bef_ins BEFORE INSERT ON note
WHEN NOT EXISTS( SELECT 1 FROM auto_increment_note 
                    WHERE (seat = new.seat))
BEGIN                   
        INSERT INTO auto_increment_note (id,seat) VALUES (0,new.seat);
END;

CREATE TRIGGER note_aft_ins AFTER INSERT ON note
BEGIN
    UPDATE  auto_increment_note
    SET     id = id + 1 
    WHERE   seat = new.seat ;

    UPDATE  note
    SET     id = (
                SELECT id 
                FROM auto_increment_note
                WHERE seat = new.seat)
    WHERE   ROWID = new.ROWID;
END;

CREATE TRIGGER note_aft_del AFTER DELETE ON note

	WHEN NOT EXISTS( SELECT 1 FROM note
                        WHERE seat = seat)
	BEGIN                   
          DELETE FROM seat 
          WHERE id = id;
    END;
