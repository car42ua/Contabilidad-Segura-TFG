package utils

import (
	"bytes"
	"compress/zlib"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"math/rand"
	"reflect"
	"time"

	"../models"
)

type resp struct {
	Ok  bool
	Msg string
}
type respData struct {
	Ok        bool
	Msg       string
	Structure interface{}
}
type respArrayData struct {
	Ok   bool
	Msg  string
	Rows []interface{}
}
type respDataPermission struct {
	Ok        bool
	Msg       string
	Structure []models.Permission
}
type respDataNote struct {
	Ok        bool
	Msg       string
	Structure []models.NoteEnc
}

//Only readable characters to avoid problems with json
const letterBytes = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

//CheckNils check all the fields of struct and if have nil return true if dont return false
func CheckNils(x interface{}) bool {
	theType := reflect.TypeOf(x)
	theValue := reflect.ValueOf(x)

	haveNils := false

	for i := 0; i < theType.NumField(); i++ {
		valueOfField := theValue.Field(i)
		if valueOfField.Kind() != reflect.Bool {
			if valueOfField.IsZero() {
				haveNils = true
			}
		}
	}
	return haveNils
}

//MakeStruct ,if the interface is a pointer it will transform it to a structure
func MakeStruct(x interface{}) interface{} {

	var result interface{}
	theType := reflect.TypeOf(x)
	theValue := reflect.ValueOf(x)

	switch theType.Kind() {
	case reflect.Struct:
		result = x
	case reflect.Ptr:
		valueOfPtr := reflect.Indirect(theValue)
		result = valueOfPtr.Interface()
	default:
		fmt.Println("The interface isnt struct!")
	}
	return result
}

//MergeStructs if the a struct hace fields with nil, set the value of b.
func MergeStructs(x, y interface{}) {

	theTypeX := reflect.TypeOf(x).Elem()
	theValueX := reflect.ValueOf(x).Elem()
	theValueY := reflect.ValueOf(y).Elem()

	numFields := theTypeX.NumField()

	for i := 0; i < numFields; i++ {
		fieldX := theValueX.Field(i)
		fieldY := theValueY.Field(i)

		if fieldX.IsZero() {
			if fieldX.IsValid() {
				if fieldX.CanSet() {
					if fieldX.Kind() == reflect.Int {
						fieldX.SetInt(fieldY.Int())
					} else if fieldX.Kind() == reflect.String {
						fieldX.SetString(fieldY.String())
					} else if fieldX.Kind() == reflect.Float64 {
						fieldX.SetFloat(fieldY.Float())
					} else if fieldX.Kind() == reflect.Bool {
						fieldX.SetBool(fieldY.Bool())
					} else if fieldX.Kind() == reflect.Uint8 {
						fieldX.SetBytes(fieldY.Bytes())
					} else if fieldX.Kind() == reflect.Slice {
						fieldX.SetBytes(fieldY.Bytes())
					} else {
						fmt.Println("NoKind!!")
					}
				} else {
					fmt.Println("No CanSet")
				}
			} else {
				fmt.Println("No Valid")
			}
		}
	}
}

//RandStringBytes generates random readable array of bytes to be used as salt
func RandStringBytes(n int) []byte {
	rand.Seed(time.Now().UTC().UnixNano())
	b := make([]byte, n)
	for i := range b {
		b[i] = letterBytes[rand.Intn(len(letterBytes))]
	}
	return b
}

//Response Fill the struct and send the response
func Response(w io.Writer, ok bool, msg string) {
	r := resp{Ok: ok, Msg: msg}
	rJSON, err := json.Marshal(&r)
	if err != nil {
		panic(err)
	}
	w.Write(rJSON)
}

//ResponseData Fill the struct and send the response
func ResponseData(w io.Writer, ok bool, msg string, structure interface{}) {
	r := respData{Ok: ok, Msg: msg, Structure: structure}
	rJSON, err := json.Marshal(&r)
	if err != nil {
		panic(err)
	}
	w.Write(rJSON)
}

//ResponsePermission Fill the struct and send the response
func ResponsePermission(w io.Writer, ok bool, msg string, permissions []models.Permission) {
	r := respDataPermission{Ok: ok, Msg: msg, Structure: permissions}
	rJSON, err := json.Marshal(&r)
	if err != nil {
		panic(err)
	}
	w.Write(rJSON)
}

//ResponseNotes Fill the struct and send the response
func ResponseNotes(w io.Writer, ok bool, msg string, notes []models.NoteEnc) {
	r := respDataNote{Ok: ok, Msg: msg, Structure: notes}
	rJSON, err := json.Marshal(&r)
	if err != nil {
		panic(err)
	}
	w.Write(rJSON)
}

//Encode64 take a []bytes to base64 string
func Encode64(data []byte) string {
	return base64.StdEncoding.EncodeToString(data)
}

//Decode64 take a base64 string to []bytes
func Decode64(s string) []byte {
	b, err := base64.StdEncoding.DecodeString(s)
	if err != nil {
		panic(err)
	}
	return b
}

//CompressData compress a []bytes
func CompressData(data []byte) []byte {
	var b bytes.Buffer
	w := zlib.NewWriter(&b)
	w.Write(data)
	w.Close()
	return b.Bytes()
}

//UncompressData uncompress a []bytes
func UncompressData(data []byte) []byte {
	var b bytes.Buffer
	r, err := zlib.NewReader(bytes.NewReader(data))
	if err != nil {
		panic(err)
	}
	defer r.Close()

	io.Copy(&b, r)
	return b.Bytes()
}
