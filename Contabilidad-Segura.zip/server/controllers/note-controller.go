package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"
	"strings"

	"../autentication"
	"../models"
	"../utils"
	"github.com/gorilla/mux"
)

//CheckNewValuesSeat is use to check and create a new row of the values are empty for seat.
func CheckNewValuesSeat(note *models.SeatNoteEnc) error {

	if note.Section == 0 {
		section := models.Section{
			ID:    0,
			Title: note.TitleSection,
		}
		id, err := models.InsertSection(section)
		if err != nil {
			return err
		}
		note.Section = int(id)
	}

	return nil
}

//CheckNewValuesNote is use to check and create a new row of the values are empty for notes.
func CheckNewValuesNote(note *models.SeatNoteEnc) error {

	if note.Concept == 0 {
		concept := models.Concept{
			ID:    0,
			Title: note.TitleConcept,
		}
		id, err := models.InsertConcept(concept)
		if err != nil {
			return err
		}
		note.Concept = int(id)
	}
	account := models.Account{
		ID:      note.Account,
		Company: note.Company,
		Title:   note.TitleAccount,
	}
	_, err := models.InsertAccount(account)

	if err != nil {
		fmt.Println(err)
		if !strings.Contains(err.Error(), "UNIQUE") {
			return err
		}
	}
	return nil
}

//isGeneral returns true if Journal is General Journal
func isGeneral(journal int) (bool, error) {
	var result = false

	result, err := models.IsGeneralJournal(journal)
	if err != nil {
		return result, err
	}
	return result, nil
}

// CreateNote allows us to handle requests to the '/ note' route with the POST method.
func CreateNote(w http.ResponseWriter, r *http.Request) {
	var note models.SeatNoteEncKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &note); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(note.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	//We check if the note has new entry, section or concept values,
	// if so we will create them first and use them to create our note
	err = CheckNewValuesSeat(&note.Structure)

	if err != nil {
		utils.Response(w, false, "Error in CheckNewValuesSeat: "+err.Error())
		return
	}

	if note.Structure.Seat == 0 {
		seat := models.Seat{
			ID:       0,
			Journal:  note.Structure.Journal,
			Section:  note.Structure.Section,
			SeatDate: note.Structure.SeatDate,
		}
		id, err := models.InsertSeat(seat) //controlar si existe si es General
		if err != nil {
			utils.Response(w, false, "Error in InsertSeat: "+err.Error())
			return
		}
		note.Structure.Seat = int(id)

	}
	err = CheckNewValuesNote(&note.Structure)

	if err != nil {
		utils.Response(w, false, "Error in CheckNewValuesNote: "+err.Error())
		return
	}

	n := models.NoteEnc{
		ID:      0,
		Seat:    note.Structure.Seat,
		Journal: note.Structure.Journal,
		Account: note.Structure.Account,
		Company: note.Structure.Company,
		Concept: note.Structure.Concept,
		Amount:  note.Structure.Amount,
		DC:      note.Structure.DC,
	}
	id, err := models.InsertNote(n)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, "Error in InsertNote: "+err.Error())
		return
	}
	note.Structure.ID = int(id)

	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Note create Successfully", note.Structure)

}

// GetNoteByID allows us to handle requests to the '/ note/id/' route with the GET method.
func GetNoteByID(w http.ResponseWriter, r *http.Request) {

	var note models.NoteKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &note); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(note.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	n, err := models.GetNoteByID(note.Structure.ID, note.Structure.Seat, claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", n)
}

// GetNoteParcialID allows us to handle requests to the '/ note/{id}' route with the GET method.
func GetNoteParcialID(w http.ResponseWriter, r *http.Request) {

	var note models.NoteKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &note); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(note.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}
	var seatnote []models.SeatNoteEnc

	// Queries about specific journal.

	if note.Structure.Journal != 0 {
		
		if note.Structure.Account != 0{ 
			seatnote, err = models.GetNoteParcialIDAccountJournal(note.Structure.Account, note.Structure.Journal, claims.StandardClaims.Issuer, claims.UserDNI)
		}else if note.Structure.ID != 0 {
			seatnote, err = models.GetNoteParcialIDJournal(note.Structure.ID, note.Structure.Journal, claims.StandardClaims.Issuer, claims.UserDNI)
		}else if  note.Structure.Seat != 0  {
			seatnote, err = models.GetNoteParcialSeatJournal(note.Structure.Seat, note.Structure.Journal, claims.StandardClaims.Issuer, claims.UserDNI)
		}else {
			seatnote, err = models.GetNoteParcialJournal(note.Structure.Journal, claims.StandardClaims.Issuer, claims.UserDNI)
		}
	}

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, "GetNoteParcial"+err.Error())
		return
	}

	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", seatnote)
}

// UpdateNote allows us to handle requests to the '/ note/{id}' route with the PUT method.
func UpdateNote(w http.ResponseWriter, r *http.Request) {

	var note models.SeatNoteEncKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &note); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(note.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	if note.Structure.Seat == 0 {
		//---------------------------------------------------------------------------------------/
		//                                  Create the New Seat                                  /
		//---------------------------------------------------------------------------------------/
		err = CheckNewValuesSeat(&note.Structure)

		if err != nil {
			utils.Response(w, false, "Error in CheckNewValuesSeat: "+err.Error())
			return
		}

		newSeat := models.Seat{
			ID:       note.Structure.Seat,
			Journal:  note.Structure.Journal,
			Section:  note.Structure.Section,
			SeatDate: note.Structure.SeatDate,
		}

		//get the seat of the note for check if this note is the only one of this seat
		seatnote, err := models.GetNoteParcialIDJournal(note.Structure.ID, note.Structure.Journal, claims.StandardClaims.Issuer, claims.UserDNI)
		if err != nil {
			utils.Response(w, false, "Error in GetNoteParcialIDJournal: "+err.Error())
			return
		}
		seatRequest := utils.MakeStruct(newSeat)
		haveNils := utils.CheckNils(seatRequest)
		if haveNils {
			s, err := models.GetSeatByID(seatnote[0].Seat, claims.StandardClaims.Issuer, claims.UserDNI)
			if err != nil {
				utils.Response(w, false, "Error in GetSeatByID: "+err.Error())
				return
			}
			utils.MergeStructs(&newSeat, &s)
		}

		newSeat.ID = 0 // The Seat is new, Make ID 0 for create a new Seat
		newSeatID, err := models.InsertSeat(newSeat)
		if err != nil {
			utils.Response(w, false, "Error in InsertSeat: "+err.Error())
			return
		}
		//---------------------------------------------------------------------------------------/
		//                                  Create the New Note                                  /
		//---------------------------------------------------------------------------------------/
		note.Structure.Seat = int(newSeatID)

		err = CheckNewValuesNote(&note.Structure)

		if err != nil {
			utils.Response(w, false, "Error in CheckNewValuesNote: "+err.Error())
			return
		}
		newNote := models.NoteEnc{
			ID:      0,
			Seat:    note.Structure.Seat,
			Journal: note.Structure.Journal,
			Account: note.Structure.Account,
			Company: note.Structure.Company,
			Concept: note.Structure.Concept,
			Amount:  note.Structure.Amount,
			DC:      note.Structure.DC,
		}
		noteRequest := utils.MakeStruct(newNote)
		haveNils = utils.CheckNils(noteRequest)

		if haveNils {
			n, err := models.GetNoteByID(seatnote[0].ID, seatnote[0].Seat, claims.StandardClaims.Issuer, claims.UserDNI)
			if err != nil {
				utils.Response(w, false, "Error in GetNoteByID: "+err.Error())
				return
			}
			utils.MergeStructs(&newNote, &n)
		}

		id, err := models.InsertNote(newNote)
		if err != nil {
			utils.Response(w, false, "Error in InsertNote: "+err.Error())
			return
		}
		note.Structure.ID = id
		//---------------------------------------------------------------------------------------/
		//                Finally Delete the Old Seat(If required) and Old Note                  /
		//---------------------------------------------------------------------------------------/
		//First count the notes of the old seat
		count, err := models.GetCountSeatsOfNote(seatnote[0].Seat, claims.StandardClaims.Issuer, claims.UserDNI)
		if err != nil {
			utils.Response(w, false, "Error in GetCountSeatsOfNote: "+err.Error())
			return
		}
		if count == 1 {
			err = models.DeleteNote(seatnote[0].ID, seatnote[0].Seat)
			if err != nil {
				utils.Response(w, false, "Error in DeleteNote: "+err.Error())
				return
			}
		}

	} else {
		//---------------------------------------------------------------------------------------/
		//                                  Modify the New Seat                                  /
		//---------------------------------------------------------------------------------------/

		err = CheckNewValuesSeat(&note.Structure)

		if err != nil {
			utils.Response(w, false, "Error in CheckNewValuesSeat: "+err.Error())
			return
		}
		seat := models.Seat{
			ID:       note.Structure.Seat,
			Journal:  note.Structure.Journal,
			Section:  note.Structure.Section,
			SeatDate: note.Structure.SeatDate,
		}
		seatRequest := utils.MakeStruct(seat)
		haveNils := utils.CheckNils(seatRequest)

		if haveNils {
			s, err := models.GetSeatByID(seat.ID, claims.StandardClaims.Issuer, claims.UserDNI)
			if err != nil {
				utils.Response(w, false, "Error in GetSeatByID: "+err.Error())
				return
			}
			utils.MergeStructs(&seat, &s)
		}

		err = models.UpdateSeat(seat)

		if err != nil {
			utils.Response(w, false, "Error in UpdateSeat: "+err.Error())
			return
		}
		//---------------------------------------------------------------------------------------/
		//                                  Modify the New Note                                  /
		//---------------------------------------------------------------------------------------/
		err = CheckNewValuesNote(&note.Structure)

		if err != nil {
			utils.Response(w, false, "Error in CheckNewValuesNote: "+err.Error())
		}

		noteRequest := utils.MakeStruct(note.Structure)
		haveNils = utils.CheckNils(noteRequest)

		newNote := models.NoteEnc{
			ID:      note.Structure.ID,
			Seat:    note.Structure.Seat,
			Journal: note.Structure.Journal,
			Account: note.Structure.Account,
			Company: note.Structure.Company,
			Concept: note.Structure.Concept,
			Amount:  note.Structure.Amount,
			DC:      note.Structure.DC,
		}
		if haveNils {
			oldNote, err := models.GetNoteByID(note.Structure.ID, note.Structure.Seat, claims.StandardClaims.Issuer, claims.UserDNI)
			if err != nil {
				utils.Response(w, false, "Error in GetNoteByID: "+err.Error())
			}
			utils.MergeStructs(&newNote, &oldNote)
		}

		err = models.UpdateNote(newNote)

		if err != nil {
			utils.Response(w, false, "Error in Update: "+err.Error())
			return
		}
	}
	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}
	utils.Response(w, true, "Row modified Successfully")
}

// DeleteNote allows us to handle requests to the '/ note/' route with the DELETE method.
func DeleteNote(w http.ResponseWriter, r *http.Request) {
	var note models.SeatNoteKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &note); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(note.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	//---------------------------------------------------------------------------------------/
	//                                  Delete the Note                                      /
	//---------------------------------------------------------------------------------------/
	err = models.DeleteNote(note.Structure.ID, note.Structure.Seat)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}
	if err != nil {
		utils.Response(w, false, "Error in DeleteNote: "+err.Error())
		return
	}

	utils.Response(w, true, "Row deleted Successfully")
}

// GetNoteStruct allows us to handle requests to the '/ note/' route with the GET method.
func GetNoteStruct(w http.ResponseWriter, r *http.Request) {
	note := models.SeatNote{}
	utils.ResponseData(w, true, "Struct send Successfully", note)
}

// GetNoteCount allows us to handle requests to the '/ note_count/' route with the GET method.
func GetNoteCount(w http.ResponseWriter, r *http.Request) {

	var note models.NoteKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &note); err != nil {
		panic(err)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(note.Key, companydb)

	if errAttach != nil {
		panic(errAttach)
	}

	count, err := models.GetCountSeatsOfNote(note.Structure.Seat, claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", count)
}
