package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"

	"../autentication"
	"../models"
	"../utils"
)

// CreateAcYear allows us to handle requests to the '/ acyear' route with the POST method.
func CreateAcYear(w http.ResponseWriter, r *http.Request) {
	var acyearStruct models.AcYearKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}

	if err := json.Unmarshal(body, &acyearStruct); err != nil {
		panic(err)
	}

	id, err := models.InsertAcYear(acyearStruct.Structure)

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	//------------------------------------------------------------------------------------//
	//					Always create a new Acyear creates 2 journals.
	//------------------------------------------------------------------------------------//

	//Then create the journals
	journal := models.Journal{
		ID:      0,
		General: 0,
		AcYear:  acyearStruct.Structure.ID,
		Company: acyearStruct.Structure.Company,
		Title:   "General Journal",
	}
	fmt.Print("acyearStruct.Key")
	fmt.Println(acyearStruct.Key)
	err = models.AttachDatabase(acyearStruct.Key, acyearStruct.Structure.Company)
	if err != nil {
		panic(err)
	}
	id, err = models.InsertJournal(journal)
	if err != nil {
		utils.Response(w, false, "Error in InsertJournal"+err.Error())
		return
	}
	journal.General = int(id)
	journal.Title = "Eraser Journal"

	id, err = models.InsertJournal(journal)
	if err != nil {
		utils.Response(w, false, "Error in Second InsertJournal"+err.Error())
		return
	}
	//Make the Detach for the foreing keys
	err = models.DetachDatabase()
	if err != nil {
		panic(err)
	}
	utils.Response(w, true, "AcYear and Journals for "+strconv.Itoa(acyearStruct.Structure.ID)+","+strconv.Itoa(acyearStruct.Structure.Company)+" creates!")
}

//GetAcYear allows us to handle requests to the '/ acyear' route with the GET method.
func GetAcYear(w http.ResponseWriter, r *http.Request) {

	var acyear []models.AcYear

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	acyear, err = models.GetAcYear(claims.StandardClaims.Issuer, claims.UserDNI)

	if err != nil {
		utils.Response(w, false, err.Error())
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", acyear)
}

//GetAcYearByID allows us to handle requests to the '/ acyear' route with the GET method.
func GetAcYearByID(w http.ResponseWriter, r *http.Request) {

	var acyear models.AcYear // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &acyear); err != nil {
		panic(err)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	a, err := models.GetAcYearByID(acyear.ID, acyear.Company, claims.StandardClaims.Issuer, claims.UserDNI)

	if err != nil {
		utils.Response(w, false, err.Error())
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", a)
}

// GetAcYearParcialID allows us to handle requests to the '/ acyear/{id}' route with the GET method.
func GetAcYearParcialID(w http.ResponseWriter, r *http.Request) {

	var acyear models.AcYear // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &acyear); err != nil {
		panic(err)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}
	var a []models.AcYear

	if acyear.ID != 0 {
		a, err = models.GetAcYearParcialID(acyear.ID, claims.StandardClaims.Issuer, claims.UserDNI)
	} else {
		a, err = models.GetAcYearParcialCompany(acyear.Company, claims.StandardClaims.Issuer, claims.UserDNI)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", a)
}

// UpdateAcYear allows us to handle requests to the '/ acyear/{id}' route with the PUT method.
func UpdateAcYear(w http.ResponseWriter, r *http.Request) {

	var acyear models.AcYear

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &acyear); err != nil {
		panic(err)
	}

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	acyearRequest := utils.MakeStruct(acyear)
	haveNils := utils.CheckNils(acyearRequest)

	if haveNils {
		a, err := models.GetAcYearByID(acyear.ID, acyear.Company, claims.StandardClaims.Issuer, claims.UserDNI)
		if err != nil {
			utils.Response(w, false, err.Error())
		}
		utils.MergeStructs(&acyear, &a)
	}

	err = models.UpdateAcYear(acyear)

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row modified Successfully")
}

// DeleteAcYear allows us to handle requests to the '/ acyear/' route with the DELETE method.
func DeleteAcYear(w http.ResponseWriter, r *http.Request) {
	var acyear models.AcYear

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &acyear); err != nil {
		panic(err)
	}
	err = models.DeleteAcYear(acyear.ID, acyear.Company)

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row deleted Successfully")
}

// GetAcYearStruct allows us to handle requests to the '/ acyear/' route with the DELETE method.
func GetAcYearStruct(w http.ResponseWriter, r *http.Request) {
	acyear := models.AcYear{}
	utils.ResponseData(w, true, "Struct send Successfully", acyear)
}
