package controllers

import (
	"net/http"

	"../autentication"
	"../utils"
)

//ValidateTokenMiddleware use to validate the token for all the request . Serve the Handler for your role
func ValidateTokenMiddleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if autentication.ValidateJWT(w, r) {
			next.ServeHTTP(w, r)
			return
		}
		utils.Response(w, false, "invalid Token")
	}
}
