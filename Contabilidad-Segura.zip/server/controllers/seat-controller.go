package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"
	"strings"

	"../autentication"
	"../models"
	"../utils"
	"github.com/gorilla/mux"
)

// CreateSeat allows us to handle requests to the '/ seat' route with the POST method.
func CreateSeat(w http.ResponseWriter, r *http.Request) {
	var seat models.SeatKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &seat); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(seat.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	var id int64

	id, err = models.InsertSeat(seat.Structure)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		fmt.Println(err)
		if !strings.Contains(err.Error(), "UNIQUE") {
			utils.Response(w, false, err.Error())
		} else {
			fmt.Println("its unique, because id exist")
			id = 0
		}
	}

	utils.Response(w, true, strconv.Itoa(int(id)))
}

//GetSeat allows us to handle requests to the '/ seat' route with the GET method.
func GetSeat(w http.ResponseWriter, r *http.Request) {

	var seat []models.SendSeat
	var key []byte

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &key); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}
	seat, err = models.GetSeat(claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", seat)
}

// GetSeatByID allows us to handle requests to the '/ note/id/' route with the GET method.
func GetSeatByID(w http.ResponseWriter, r *http.Request) {

	var seat models.SeatKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &seat); err != nil {
		panic(err)
	}

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(seat.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	s, err := models.GetSeatByID(seat.Structure.ID, claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", s)
}

// GetSeatParcialID allows us to handle requests to the '/ seat/{id}' route with the GET method.
func GetSeatParcialID(w http.ResponseWriter, r *http.Request) {

	var seat models.SeatKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &seat); err != nil {
		panic(err)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(seat.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	a, err := models.GetSeatParcialJournal(seat.Structure.Journal, claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", a)
}

// UpdateSeat allows us to handle requests to the '/ seat/{id}' route with the PUT method.
func UpdateSeat(w http.ResponseWriter, r *http.Request) {

	var seat models.SeatKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &seat); err != nil {
		panic(err)
	}

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	seatRequest := utils.MakeStruct(seat.Structure)
	haveNils := utils.CheckNils(seatRequest)

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(seat.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	if haveNils {
		s, err := models.GetSeatByID(seat.Structure.ID, claims.StandardClaims.Issuer, claims.UserDNI)
		if err != nil {
			utils.Response(w, false, err.Error())
		}
		utils.MergeStructs(&seat, &s)
	}

	err = models.UpdateSeat(seat.Structure)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row modified Successfully")
}

// DeleteSeat allows us to handle requests to the '/ seat/' route with the DELETE method.
func DeleteSeat(w http.ResponseWriter, r *http.Request) {
	var seat models.SeatKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &seat); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(seat.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	err = models.DeleteSeat(seat.Structure.ID)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row deleted Successfully")
}

// GetSeatStruct allows us to handle requests to the '/ seat/' route with the DELETE method.
func GetSeatStruct(w http.ResponseWriter, r *http.Request) {
	seat := models.Seat{}
	utils.ResponseData(w, true, "Struct send Successfully", seat)
}
