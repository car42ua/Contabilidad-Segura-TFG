package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"
	"strings"

	"../autentication"
	"../models"
	"../utils"
	"github.com/gorilla/mux"
)

// CreateAccount allows us to handle requests to the '/ account' route with the POST method.
func CreateAccount(w http.ResponseWriter, r *http.Request) {
	var account models.AccountKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &account); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(account.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}
	id, err := models.InsertAccount(account.Structure)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		fmt.Println(err)
		if !strings.Contains(err.Error(), "UNIQUE") {
			utils.Response(w, false, err.Error())
		} else {
			fmt.Println("its unique, because id exist")
		}
	}

	utils.Response(w, true, strconv.FormatInt(id, 10))
}

// GetAccount allows us to handle requests to the '/ account' route with the GET method.
func GetAccount(w http.ResponseWriter, r *http.Request) {

	var accounts []models.Account
	var key []byte

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &key); err != nil {
		panic(err)
	}

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	accounts, err = models.GetAccount(claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
	}
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", accounts)
}

// GetAccountByID allows us to handle requests to the '/ account/{id}' route with the GET method.
func GetAccountByID(w http.ResponseWriter, r *http.Request) {

	var account models.AccountKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &account); err != nil {
		panic(err)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(account.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	a, err := models.GetAccountByID(account.Structure.ID, account.Structure.Company, claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", a)
}

// GetAccountParcialID allows us to handle requests to the '/ acyear/{id}' route with the GET method.
func GetAccountParcialID(w http.ResponseWriter, r *http.Request) {

	var account models.AccountKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &account); err != nil {
		panic(err)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(account.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	a, err := models.GetAccountParcialCompany(account.Structure.Company, claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", a)
}

// UpdateAccount allows us to handle requests to the '/ account/{id}' route with the PUT method.
func UpdateAccount(w http.ResponseWriter, r *http.Request) {

	var account models.AccountKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &account); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(account.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	err = models.UpdateAccount(account.Structure)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row modified Successfully")
}

// DeleteAccount allows us to handle requests to the '/ account/' route with the DELETE method.
func DeleteAccount(w http.ResponseWriter, r *http.Request) {
	var account models.AccountKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &account); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(account.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	err = models.DeleteAccount(account.Structure.ID, account.Structure.Company)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row deleted Successfully")
}

// GetAccountStruct allows us to handle requests to the '/ acount/' route with the DELETE method.
func GetAccountStruct(w http.ResponseWriter, r *http.Request) {
	account := new(models.Account)
	utils.ResponseData(w, true, "Struct send Successfully", account)
}
