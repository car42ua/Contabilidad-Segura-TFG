package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"

	"../autentication"
	"../models"
	"../utils"
	"github.com/gorilla/mux"
)

// CreateJournalSeat allows us to handle requests to the '/ journalseat' route with the POST method.
func CreateJournalSeat(w http.ResponseWriter, r *http.Request) {
	var journalseat models.JournalSeatKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &journalseat); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(journalseat.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	err = models.InsertJournalSeat(journalseat.Structure)
	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}
	if err != nil {
		utils.Response(w, false, "Error in InsertJournalSeat"+err.Error())
		return
	}

	utils.Response(w, true, "JournalSeat create Successfully")
}

// GetJournalSeat allows us to handle requests to the '/ journalseat' route with the GET method.
func GetJournalSeat(w http.ResponseWriter, r *http.Request) {

	var journalseats []models.JournalSeat
	var key []byte
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &key); err != nil {
		panic(err)
	}

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}
	journalseats, err = models.GetJournalSeat(claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", journalseats)
}

// GetJournalSeatByID allows us to handle requests to the '/ journalseat/{id}' route with the GET method.
func GetJournalSeatByID(w http.ResponseWriter, r *http.Request) {

	var journalseat models.JournalSeatKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &journalseat); err != nil {
		panic(err)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(journalseat.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	j, err := models.GetJournalSeatByID(journalseat.Structure.Journal, journalseat.Structure.Seat, claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", j)
}

// GetJournalSeatStruct allows us to handle requests to the '/ journalseat/' route with the DELETE method.
func GetJournalSeatStruct(w http.ResponseWriter, r *http.Request) {
	journalseat := new(models.JournalSeat)
	utils.ResponseData(w, true, "Struct send Successfully", journalseat)
}
