package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"

	"../autentication"
	"../models"
	"../utils"
	"github.com/gorilla/mux"
)

// CreateJournal allows us to handle requests to the '/ journal' route with the POST method.
func CreateJournal(w http.ResponseWriter, r *http.Request) {
	var journal models.JournalKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &journal); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(journal.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}
	id, err := models.InsertJournal(journal.Structure)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	utils.Response(w, true, strconv.FormatInt(id, 10))
}

// GetJournal allows us to handle requests to the '/ journal' route with the GET method.
func GetJournal(w http.ResponseWriter, r *http.Request) {

	var journals []models.Journal
	var key []byte
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &key); err != nil {
		panic(err)
	}

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	journals, err = models.GetJournal(claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
	}

	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", journals)
}

// GetJournalByID allows us to handle requests to the '/ journal/{id}' route with the GET method.
func GetJournalByID(w http.ResponseWriter, r *http.Request) {

	var journal models.JournalKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &journal); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(journal.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	j, err := models.GetJournalByID(journal.Structure.ID, claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", j)
}

// GetJournalByAcYear allows us to handle requests to the '/ journal/{id}' route with the GET method.
func GetJournalByAcYear(w http.ResponseWriter, r *http.Request) {

	var journal models.JournalKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		utils.Response(w, false, "Error in ReadAll"+err.Error())
		return
	}
	if err := json.Unmarshal(body, &journal); err != nil {
		utils.Response(w, false, "Error in Unmarshal"+err.Error())
		return
	}
	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(journal.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, "Error in GetClaims"+err.Error())
	}

	j, err := models.GetJournalByAcYear(journal.Structure.AcYear, journal.Structure.Company, claims.StandardClaims.Issuer, claims.UserDNI)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, "Error in GetJournalByAcYear: "+err.Error())
		return
	}

	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", j)
}

// UpdateJournal allows us to handle requests to the '/ journal/{id}' route with the PUT method.
func UpdateJournal(w http.ResponseWriter, r *http.Request) {

	var journal models.JournalKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &journal); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(journal.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	journalRequest := utils.MakeStruct(journal)
	haveNils := utils.CheckNils(journalRequest)

	if haveNils {
		j, err := models.GetJournalByID(journal.Structure.ID, claims.StandardClaims.Issuer, claims.UserDNI)
		if err != nil {
			utils.Response(w, false, err.Error())
			return
		}
		utils.MergeStructs(&journal, &j)
	}

	err = models.UpdateJournal(journal.Structure)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	utils.Response(w, true, "Row modified Successfully")
}

// DeleteJournal allows us to handle requests to the '/ journal/' route with the DELETE method.
func DeleteJournal(w http.ResponseWriter, r *http.Request) {
	var journal models.JournalKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &journal); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(journal.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}
	err = models.DeleteJournal(journal.Structure.ID)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row deleted Successfully")
}

// GetJournalStruct allows us to handle requests to the '/ journal/' route with the DELETE method.
func GetJournalStruct(w http.ResponseWriter, r *http.Request) {
	journal := new(models.Journal)
	utils.ResponseData(w, true, "Struct send Successfully", journal)
}
