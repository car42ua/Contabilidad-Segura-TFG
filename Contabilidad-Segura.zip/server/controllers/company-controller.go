package controllers

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"

	"../autentication"
	"../models"
	"../utils"
)

// CreateCompany allows us to handle requests to the '/ company' route with the POST method.
func CreateCompany(w http.ResponseWriter, r *http.Request) {
	var company models.CompanyAndKeys // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &company); err != nil {
		panic(err)
	}
	//---------------------------------------------------------------------------------------------//
	//									First create a the company                                 //
	//---------------------------------------------------------------------------------------------//
	id, err := models.InsertCompany(company.Company)

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	//---------------------------------------------------------------------------------------------//
	//								Then create the key for the database
	//---------------------------------------------------------------------------------------------//

	// key := make([]byte, 32) //Generate a random 32 byte key for AES-256
	// if _, err := rand.Read(key); err != nil {
	// 	panic(err.Error())
	// }
	//---------------------------------------------------------------------------------------------//
	//					And use the key for create new database for the new company
	//---------------------------------------------------------------------------------------------//
	err = models.CreateTablesCompany(int(id), company.CompanyKey)
	//---------------------------------------------------------------------------------------------//
	//						Then ,save the key with the public key of logged admin
	//---------------------------------------------------------------------------------------------//
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}
	//We will give the administrator permissions next to the encrypted key with his public key

	admin, err := models.GetUserByDNI(claims.UserDNI)

	if err != nil {
		utils.Response(w, false, "Error in GetUserByDNI: "+err.Error())
		return
	}

	publicKey, err := x509.ParsePKCS1PublicKey(admin.PubKey)

	encryptKey, err := rsa.EncryptOAEP(sha256.New(), rand.Reader, publicKey, company.CompanyKey, nil)
	if err != nil {
		utils.Response(w, false, err.Error())
	}
	//---------------------------------------------------------------------------------------------//
	//			We give and save permissions to the administrator of the database created
	//---------------------------------------------------------------------------------------------//

	permission := models.Permission{
		User:            claims.UserDNI,
		Company:         int(id),
		CompanyKey:      encryptKey,
		DataKey:         company.DataKey,
		ReadPermission:  true,
		WritePermission: true,
	}

	_, err = models.InsertPermission(permission)

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, strconv.FormatInt(id, 10))
}

// GetCompany allows us to handle requests to the '/ company' route with the GET method.
func GetCompany(w http.ResponseWriter, r *http.Request) {

	var companies []models.Company

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	companies, err = models.GetCompany(claims.StandardClaims.Issuer, claims.UserDNI)

	if err != nil {
		utils.Response(w, false, err.Error())
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", companies)
}

// GetCompanyByID allows us to handle requests to the '/ company/{id}' route with the GET method.
func GetCompanyByID(w http.ResponseWriter, r *http.Request) {

	var company models.Company // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &company); err != nil {
		panic(err)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	c, err := models.GetCompanyByID(company.ID, claims.StandardClaims.Issuer, claims.UserDNI)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", c)
}

// UpdateCompany allows us to handle requests to the '/ company/{id}' route with the PUT method.
func UpdateCompany(w http.ResponseWriter, r *http.Request) {

	var company models.Company

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &company); err != nil {
		panic(err)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	companyRequest := utils.MakeStruct(company)
	haveNils := utils.CheckNils(companyRequest)

	if haveNils {
		c, err := models.GetCompanyByID(company.ID, claims.StandardClaims.Issuer, claims.UserDNI)
		if err != nil {
			utils.Response(w, false, err.Error())
			return
		}
		utils.MergeStructs(&company, &c)
	}

	err = models.UpdateCompany(company)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row modified Successfully")
}

// DeleteCompany allows us to handle requests to the '/ company/' route with the DELETE method.
func DeleteCompany(w http.ResponseWriter, r *http.Request) {
	var company models.Company

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &company); err != nil {
		panic(err)
	}
	err = models.DeleteCompany(company.ID)

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row deleted Successfully")
}

// GetCompanyStruct allows us to handle requests to the '/ company/' route with the DELETE method.
func GetCompanyStruct(w http.ResponseWriter, r *http.Request) {
	company := new(models.Company)
	utils.ResponseData(w, true, "Struct send Successfully", company)
}
