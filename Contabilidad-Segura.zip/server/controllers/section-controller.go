package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"

	"../models"
	"../utils"
	"github.com/gorilla/mux"
)

// CreateSection allows us to handle requests to the '/ section' route with the POST method.
func CreateSection(w http.ResponseWriter, r *http.Request) {
	var section models.SectionKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &section); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(section.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	var id int64

	if section.Structure.ID == 0 {
		id, err = models.InsertSection(section.Structure)
		if err != nil {
			utils.Response(w, false, err.Error())
		}
	} else {
		_, err := models.GetSectionByID(section.Structure.ID)
		if err != nil {
			utils.Response(w, false, err.Error())
			return
		}
		id = 0
	}

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	utils.Response(w, true, strconv.FormatInt(id, 10))
}

// GetSection allows us to handle requests to the '/ section' route with the GET method.
func GetSection(w http.ResponseWriter, r *http.Request) {

	var sections []models.Section
	var key []byte

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &key); err != nil {
		panic(err)
	}
	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	sections, err = models.GetSection()
	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
	}

	w.Header().Set("Content-Type", "application/json")
	if sections != nil {
		utils.ResponseData(w, true, "Query Successfully", sections)
	} else {
		utils.ResponseData(w, true, "Query Successfully", nil)
	}
}

// GetSectionByID allows us to handle requests to the '/ section/{id}' route with the GET method.
func GetSectionByID(w http.ResponseWriter, r *http.Request) {

	var section models.SectionKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &section); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(section.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	s, err := models.GetSectionByID(section.Structure.ID)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", s)
}

// UpdateSection allows us to handle requests to the '/ section/{id}' route with the PUT method.
func UpdateSection(w http.ResponseWriter, r *http.Request) {

	var section models.SectionKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &section); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(section.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	err = models.UpdateSection(section.Structure)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row modified Successfully")
}

// DeleteSection allows us to handle requests to the '/ section/' route with the DELETE method.
func DeleteSection(w http.ResponseWriter, r *http.Request) {
	var section models.SectionKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &section); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(section.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	err = models.DeleteSection(section.Structure.ID)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row deleted Successfully")
}

// GetSectionStruct allows us to handle requests to the '/ section/' route with the DELETE method.
func GetSectionStruct(w http.ResponseWriter, r *http.Request) {
	section := new(models.Section)
	utils.ResponseData(w, true, "Struct send Successfully", section)
}
