package controllers

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"

	"../autentication"
	"../models"
	"../utils"
)

//UserJSON is the struct of send user to server
type UserJSON struct {
	DNI      string `json:"dni"`
	Name     string `json:"name"`
	Email    string `json:"email"`
	Role     string `json:"role"`
	Password string `json:"pass"`
	Salt     string `json:"salt"`
	PubKey   string `json:"pubkey"`
	PrivKey  string `json:"privkey"`
}

//Use to move the JSON to User struct
func moveDataUser(userJSON UserJSON) *models.User {

	u := &models.User{
		DNI:     userJSON.DNI,
		Name:    userJSON.Name,
		Email:   userJSON.Email,
		Role:    userJSON.Role,
		PubKey:  utils.UncompressData(utils.Decode64(userJSON.PubKey)),
		PrivKey: utils.UncompressData(utils.Decode64(userJSON.PrivKey)),
	}

	return u
}

//Use to move the JSON to User struct
func moveDataUserWithoutKeys(userJSON UserJSON) *models.User {

	u := &models.User{
		DNI:   userJSON.DNI,
		Name:  userJSON.Name,
		Email: userJSON.Email,
		Role:  userJSON.Role,
	}

	return u
}

// CreateUser allows us to handle requests to the '/ user' route with the POST method.
func CreateUser(w http.ResponseWriter, r *http.Request) {
	var userJSON UserJSON // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		utils.Response(w, false, err.Error())
	}
	if err := json.Unmarshal(body, &userJSON); err != nil {
		utils.Response(w, false, err.Error())
	}

	if models.UserExists(userJSON.DNI) {
		utils.Response(w, false, "User is already registered")
	} else {
		u := moveDataUser(userJSON)
		password, err := base64.StdEncoding.DecodeString(userJSON.Password)

		if err != nil {
			utils.Response(w, false, err.Error())
		}
		u.Hash(password, utils.RandStringBytes(10))

		err = models.InsertUser(u)

		if err != nil {
			utils.Response(w, false, err.Error())
		}

		//- If the one that creates the user is superadmin, it means that it is the change of
		//     the admin's credentials, so we will give it its corresponding token.
		//- If you are only admin, we will not give it to you since we are creating new users.
		claims, err := autentication.GetClaims(r)
		if err != nil {
			panic(err)
		}

		if claims.StandardClaims.Issuer == "superadmin" {
			token, err := autentication.GenerateJWT(u)
			msg := "Token from server"

			responseToken := models.ResponseToken{
				Ok:    true,
				Token: token,
				Msg:   msg,
			}
			jsonResponse, err := json.Marshal(responseToken)
			if err != nil {
				fmt.Println(err)
			}
			w.WriteHeader(http.StatusOK)
			w.Write(jsonResponse)
		} else {
			w.WriteHeader(http.StatusOK)
			utils.Response(w, true, "The user is create Successfully")
		}

	}
}

//LoginUser allows us to handle requests to the '/login' route with the GET method.
func LoginUser(w http.ResponseWriter, r *http.Request) {

	var userJSON UserJSON // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		utils.Response(w, false, err.Error())
	}
	if err := json.Unmarshal(body, &userJSON); err != nil {
		utils.Response(w, false, err.Error())
	}

	u, err := models.GetUserByDNI(userJSON.DNI)
	if err != nil {
		utils.Response(w, false, err.Error())
	}
	if u != nil {
		password, err := base64.StdEncoding.DecodeString(userJSON.Password)
		if err != nil {
			utils.Response(w, false, err.Error())
		}

		if u.CompareHash(password) { // The password hashed match

			token, err := autentication.GenerateJWT(u)
			msg := "Token from server"

			if u.Role == "superadmin" {
				msg = "superadmin"
			}
			responseToken := models.ResponseToken{
				Ok:    true,
				Token: token,
				Msg:   msg,
			}
			jsonResponse, err := json.Marshal(responseToken)
			if err != nil {
				fmt.Println(err)
			}
			w.WriteHeader(http.StatusOK)
			w.Write(jsonResponse)
		} else {
			utils.Response(w, false, "Error to compare Hash")
		}
	} else {
		utils.Response(w, false, "The user doesn't exist")
	}

}

//GetKeys returns the public and private key of user
func GetKeys(w http.ResponseWriter, r *http.Request) {
	claims, err := autentication.GetClaims(r)
	if err != nil {
		panic(err)
	}
	dni := claims.UserDNI
	u, err := models.GetUserByDNI(dni)
	if err != nil {
		utils.Response(w, false, "Error in GetUserByDNI: "+err.Error())
	}
	pubKey := utils.Encode64(utils.CompressData(u.PubKey))
	privKey := utils.Encode64(utils.CompressData(u.PrivKey))

	JSONKeys := UserJSON{
		PubKey:  pubKey,
		PrivKey: privKey,
	}
	rJSON, err := json.Marshal(&JSONKeys)
	if err != nil {
		panic(err)
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	w.Write(rJSON)
}

//ValidateAndEraseSA check if is real the user get a superadmin token.
//	if it is true, the super user will be deleted from the database.
func ValidateAndEraseSA(w http.ResponseWriter, r *http.Request) {
	claims, err := autentication.GetClaims(r)
	if err != nil {
		panic(err)
	}
	if claims.Issuer == "superadmin" {
		u := new(models.User)
		u.DNI = "admin"
		err := models.DeleteUser(u)
		if err != nil {
			utils.Response(w, false, err.Error())
		}

		utils.Response(w, true, "The superUser is delete")
	} else {
		utils.Response(w, false, "The user is a fake!")
	}
}

// GetUser allows us to handle requests to the '/ user' route with the GET method.
func GetUser(w http.ResponseWriter, r *http.Request) {

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	u, err := models.GetUser(claims.StandardClaims.Issuer, claims.UserDNI)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", u)
}

// GetUserByID allows us to handle requests to the '/ user/{id}' route with the GET method.
func GetUserByID(w http.ResponseWriter, r *http.Request) {

	user := new(models.User)

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &user); err != nil {
		panic(err)
	}
	u, err := models.GetUserByDNI(user.DNI)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", u)
}

// GetUserByIDClient allows us to handle requests to the '/ userclient7' route with the GET method and UsesJSON response.
func GetUserByIDClient(w http.ResponseWriter, r *http.Request) {

	var dni string

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &dni); err != nil {
		panic(err)
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		panic(err)
	}
	if claims.Issuer == "admin" {
		u, err := models.GetUserByDNI(dni)
		if err != nil {
			utils.Response(w, false, "Error in GetUserByDNI: "+err.Error())
		}
		pubKey := utils.Encode64(utils.CompressData(u.PubKey))
		privKey := utils.Encode64(utils.CompressData(u.PrivKey))

		JSONKeys := UserJSON{
			DNI:     u.DNI,
			PubKey:  pubKey,
			PrivKey: privKey,
		}
		rJSON, err := json.Marshal(&JSONKeys)
		if err != nil {
			panic(err)
		}
		w.WriteHeader(http.StatusOK)
		w.Header().Set("Content-Type", "application/json")
		w.Write(rJSON)
	} else {
		utils.Response(w, false, "Operation invalid")
	}
}

// UpdateUser allows us to handle requests to the '/ user/{id}' route with the PUT method.
func UpdateUser(w http.ResponseWriter, r *http.Request) {
	var userJSON UserJSON // Tomando el cuerpo de la petición, en formato JSON, y

	var user *models.User
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		utils.Response(w, false, err.Error())
	}
	if err := json.Unmarshal(body, &userJSON); err != nil {
		utils.Response(w, false, err.Error())
	}
	if userJSON.PubKey == "" && userJSON.PrivKey == "" {
		user = moveDataUserWithoutKeys(userJSON)
	} else {
		user = moveDataUser(userJSON)
	}
	password, err := base64.StdEncoding.DecodeString(userJSON.Password)

	if err != nil {
		utils.Response(w, false, err.Error())
	}

	if bytes.NewReader(password).Len() != 0 { //password != nil
		user.Hash(password, utils.RandStringBytes(10))
	}

	userRequest := utils.MakeStruct(user)
	haveNils := utils.CheckNils(userRequest)

	if haveNils {
		u, err := models.GetUserByDNI(user.DNI)
		if err != nil {
			utils.Response(w, false, err.Error())
			return
		}
		utils.MergeStructs(user, u)
	}

	err = models.ModifyUser(user)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row modified Successfully")
}

// DeleteUser allows us to handle requests to the '/ user/' route with the DELETE method.
func DeleteUser(w http.ResponseWriter, r *http.Request) {

	var user *models.User

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &user); err != nil {
		panic(err)
	}
	err = models.DeleteUser(user)

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row deleted Successfully")
}

// GetUserStruct allows us to handle requests to the '/ user/' route with the DELETE method.
func GetUserStruct(w http.ResponseWriter, r *http.Request) {
	user := models.User{}
	utils.ResponseData(w, true, "Struct send Successfully", user)
}

//RefreshToken check the issue token and send new for client
func RefreshToken(w http.ResponseWriter, r *http.Request) {
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
	}

	token, err := autentication.RefreshJWT(claims.StandardClaims.Issuer, claims.UserDNI)
	msg := "Token from server"

	responseToken := models.ResponseToken{
		Ok:    true,
		Token: token,
		Msg:   msg,
	}
	jsonResponse, err := json.Marshal(responseToken)
	if err != nil {
		fmt.Println(err)
	}
	w.WriteHeader(http.StatusOK)
	w.Write(jsonResponse)
}
