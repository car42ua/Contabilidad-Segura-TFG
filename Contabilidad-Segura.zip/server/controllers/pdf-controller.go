package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"
	"../utils"
	"../models"
	"github.com/gorilla/mux"
)
// CreateJournalPDF allows us to handle requests to the '/ note' route with the POST method.
func CreateJournalPDF(w http.ResponseWriter, r *http.Request) {
	var pdfJounal models.PDFJournalKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &pdfJounal); err != nil {
		panic(err)
	}
	//First upload the data of pdf
	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(pdfJounal.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	pdflist, err := models.GetJournalPDF(pdfJounal.Structure.AcYear, pdfJounal.Structure.Company)
	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
	}
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", pdflist)
}

// CreateAccountPDF allows us to handle requests to the '/ note' route with the POST method.
func CreateAccountPDF(w http.ResponseWriter, r *http.Request) {
	var pdfAccount models.PDFAccountKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &pdfAccount); err != nil {
		panic(err)
	}
	//First upload the data of pdf
	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(pdfAccount.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	pdflist, err := models.GetAccountPDF(pdfAccount.Structure.AcYear, pdfAccount.Structure.Company, pdfAccount.Structure.From, pdfAccount.Structure.To)
	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
	}
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", pdflist)
}
