package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"

	"../autentication"
	"../models"
	"../utils"
)

// CreatePermission allows us to handle requests to the '/ permission' route with the POST method.
func CreatePermission(w http.ResponseWriter, r *http.Request) {
	//var permission models.PermissionKey // Tomando el cuerpo de la petición, en formato JSON, y
	var permission models.Permission // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	if err := json.Unmarshal(body, &permission); err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	fmt.Println(permission)

	id, err := models.InsertPermission(permission)

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, strconv.FormatInt(id, 10))
}

// GetPermissionByID use to send permission to client and the public key of server
func GetPermissionByID(w http.ResponseWriter, r *http.Request) {

	var permission models.Permission // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	if err := json.Unmarshal(body, &permission); err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	p, err := models.GetPermissionByID(permission.User, permission.Company, claims.StandardClaims.Issuer, claims.UserDNI)

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	//utils.ResponseData(w, true, "Query Successfully", p)

	rJSON, err := json.Marshal(&p)
	if err != nil {
		panic(err)
	}
	w.Write(rJSON)
}

// GetPermissionParcialID allows us to handle requests to the '/ permission/{id}' route with the GET method.
func GetPermissionParcialID(w http.ResponseWriter, r *http.Request) {
	var permission models.Permission // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	if err := json.Unmarshal(body, &permission); err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	var a []models.Permission

	if permission.User != "" {
		a, err = models.GetPermissionParcialUser(permission.User, claims.StandardClaims.Issuer, claims.UserDNI)
	} else {
		a, err = models.GetPermissionParcialCompany(permission.Company, claims.StandardClaims.Issuer, claims.UserDNI)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", a)
}

// UpdatePermission allows us to handle requests to the '/ permission/{id}' route with the PUT method.
func UpdatePermission(w http.ResponseWriter, r *http.Request) {

	var permission models.Permission

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	if err := json.Unmarshal(body, &permission); err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	claims, err := autentication.GetClaims(r)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	permissionRequest := utils.MakeStruct(permission)
	haveNils := utils.CheckNils(permissionRequest)

	if haveNils {
		a, err := models.GetPermissionByID(permission.User, permission.Company, claims.StandardClaims.Issuer, claims.UserDNI)
		if err != nil {
			utils.Response(w, false, err.Error())
			return
		}
		utils.MergeStructs(&permission, &a)
	}

	err = models.UpdatePermission(permission)

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row modified Successfully")
}

// DeletePermission allows us to handle requests to the '/ permission/' route with the DELETE method.
func DeletePermission(w http.ResponseWriter, r *http.Request) {
	var permission models.Permission

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	if err := json.Unmarshal(body, &permission); err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	err = models.DeletePermission(permission)

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row deleted Successfully")
}

// GetPermissionStruct allows us to handle requests to the '/ permission/' route with the DELETE method.
func GetPermissionStruct(w http.ResponseWriter, r *http.Request) {
	permission := models.Permission{}
	utils.ResponseData(w, true, "Struct send Successfully", permission)
}
