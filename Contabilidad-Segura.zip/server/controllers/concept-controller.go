package controllers

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"

	"../models"
	"../utils"
	"github.com/gorilla/mux"
)

// CreateConcept allows us to handle requests to the '/ concept' route with the POST method.
func CreateConcept(w http.ResponseWriter, r *http.Request) {
	var concept models.ConceptKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &concept); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(concept.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	var id int64

	if concept.Structure.ID == 0 {
		id, err = models.InsertConcept(concept.Structure)
		if err != nil {
			utils.Response(w, false, err.Error())
		}
	} else {
		_, err := models.GetConceptByID(concept.Structure.ID)
		if err != nil {
			utils.Response(w, false, err.Error())
			return
		}
		id = 0
	}
	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	utils.Response(w, true, strconv.FormatInt(id, 10))
}

// GetConcept allows us to handle requests to the '/ concept' route with the GET method.
func GetConcept(w http.ResponseWriter, r *http.Request) {

	var concepts []models.Concept
	var key []byte

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &key); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	concepts, err = models.GetConcept()

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", concepts)
}

// GetConceptByID allows us to handle requests to the '/ concept/{id}' route with the GET method.
func GetConceptByID(w http.ResponseWriter, r *http.Request) {

	var concept models.ConceptKey // Tomando el cuerpo de la petición, en formato JSON, y

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &concept); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(concept.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	c, err := models.GetConceptByID(concept.Structure.ID)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	utils.ResponseData(w, true, "Query Successfully", c)
}

// UpdateConcept allows us to handle requests to the '/ concept/{id}' route with the PUT method.
func UpdateConcept(w http.ResponseWriter, r *http.Request) {

	var concept models.ConceptKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &concept); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(concept.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	err = models.UpdateConcept(concept.Structure)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row modified Successfully")
}

// DeleteConcept allows us to handle requests to the '/ concept/' route with the DELETE method.
func DeleteConcept(w http.ResponseWriter, r *http.Request) {
	var concept models.ConceptKey

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		fmt.Println(err)
	}
	if err := json.Unmarshal(body, &concept); err != nil {
		panic(err)
	}

	companydb, err := strconv.Atoi(mux.Vars(r)["company"])

	errAttach := models.AttachDatabase(concept.Key, companydb)
	if errAttach != nil {
		panic(errAttach)
	}

	err = models.DeleteConcept(concept.Structure.ID)

	errAttach = models.DetachDatabase()
	if errAttach != nil {
		panic(errAttach)
	}

	if err != nil {
		utils.Response(w, false, err.Error())
		return
	}

	utils.Response(w, true, "Row deleted Successfully")
}

// GetConceptStruct allows us to handle requests to the '/ concept/' route with the DELETE method.
func GetConceptStruct(w http.ResponseWriter, r *http.Request) {
	concept := new(models.Concept)
	utils.ResponseData(w, true, "Struct send Successfully", concept)
}
