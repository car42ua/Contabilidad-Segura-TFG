package models

import (
	jwt "github.com/dgrijalva/jwt-go"
)

//Claim is the Payload of JWT
type Claim struct {
	UserDNI string `json:"userdni"`
	jwt.StandardClaims
}
