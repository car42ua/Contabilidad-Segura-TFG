package models

import (
	"errors"
	"fmt"

	_ "github.com/mutecomm/go-sqlcipher"
)

//PermissionKey is the struct of the table permission
type PermissionKey struct {
	Structure Permission
	Key       []byte
}

//Permission is the model of table Permision
type Permission struct {
	User            string `json:"user"`
	Company         int    `json:"company"`
	CompanyKey      []byte `json:"companykey"`
	DataKey         []byte `json:"datakey"`
	ReadPermission  bool   `json:"read_permission"`
	WritePermission bool   `json:"write_permission"`
}

//CreatePermisionTable is used to create Permision table when creating database for the first time
func CreatePermisionTable() error {
	db := GetConnection()

	stmt, err :=
		db.Prepare(`CREATE TABLE permission(
						company INTEGER(3) NOT NULL,
						user TEXT NOT NULL,
						companykey TEXT NOT NULL,
						datakey TEXT NOT NULL,
						read_permission BOOL,
						write_permission BOOL,
						PRIMARY KEY(company,user),
						CONSTRAINT fkcompany FOREIGN KEY(company) REFERENCES company(id),
						CONSTRAINT fkuser FOREIGN KEY(user) REFERENCES user(dni)
					);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())

	} else {
		fmt.Println("Table created successfully..")
	}
	return err
}

//InsertPermission Insert a new permission with autoincrement id
func InsertPermission(p Permission) (int64, error) {

	db := GetConnection()
	q := `INSERT INTO permission (company,user,companykey,datakey,read_permission,write_permission)
            VALUES(?, ?, ?, ?, ?, ?);`

	stmt, err := db.Prepare(q)
	if err != nil {
		return 0, err
	}

	defer stmt.Close()

	r, err := stmt.Exec(p.Company, p.User, p.CompanyKey, p.DataKey, p.ReadPermission, p.WritePermission)

	if err != nil {
		return 0, err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return 0, errors.New("ERROR: Se esperaba una fila afectada")
	}
	id, err := r.LastInsertId()

	if err != nil {
		return 0, err
	}

	return id, nil
}

//GetPermission is the method to get all the permission of table Permission
func GetPermission(role string, dni string) ([]Permission, error) {
	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	company,user,companykey,datakey,read_permission,write_permission
				FROM permission` // Ejecutamos la query
	} else {
		q = `SELECT company,user,companykey,datakey,read_permission,write_permission	
				FROM permission 
				WHERE p.user = ?;` // Ejecutamos la query
	}

	rows, err := db.Query(q, dni)
	if err != nil {
		return []Permission{}, err
	}
	defer rows.Close()
	permissions := []Permission{}
	for rows.Next() {
		p := Permission{}
		rows.Scan(
			&p.Company,
			&p.User,
			&p.CompanyKey,
			&p.DataKey,
			&p.ReadPermission,
			&p.WritePermission)
		permissions = append(permissions, p)
	}
	return permissions, nil
}

//GetPermissionByID is the method to get all the permission of table Permission
func GetPermissionByID(user string, company int, role string, dni string) (*Permission, error) {
	p := Permission{}

	db := GetConnection()
	var q string

	if role == "admin" {

		q = `SELECT	company,user,companykey,datakey,read_permission,write_permission
				FROM permission
				WHERE company = ?
				AND user = ?`
	} else {

		q = `SELECT company,user,companykey,datakey,read_permission,write_permission	
				FROM permission
				WHERE company = ? 
				AND user = ?
				AND user = ?;`
	}
	row := db.QueryRow(q, company, user, dni)

	err := row.Scan(
		&p.Company,
		&p.User,
		&p.CompanyKey,
		&p.DataKey,
		&p.ReadPermission,
		&p.WritePermission,
	)

	if err != nil {
		return &p, err
	}

	return &p, nil
}

//GetPermissionParcialUser is the method to get all the permission of table Permission
func GetPermissionParcialUser(user string, role string, dni string) ([]Permission, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	p.company,p.user,p.companykey,p.datakey,p.read_permission,p.write_permission
				FROM permission AS p JOIN company AS c ON p.company = c.id
				WHERE p.user = ?
				ORDER BY p.company,p.user,p.companykey,p.read_permission,p.write_permission;`
	} else {

		q = `SELECT	p.company,p.user,p.companykey,p.datakey,p.read_permission,p.write_permission
				FROM permission AS p JOIN company AS c ON p.company = c.id
				WHERE p.user = ? 
				AND p.user = ?
				ORDER BY p.company,p.user,p.companykey,p.datakey,p.read_permission,p.write_permission;`
	}
	rows, err := db.Query(q, user, dni)
	if err != nil {
		return []Permission{}, err
	}
	defer rows.Close()
	permissions := []Permission{}
	for rows.Next() {
		p := Permission{}
		rows.Scan(
			&p.Company,
			&p.User,
			&p.CompanyKey,
			&p.DataKey,
			&p.ReadPermission,
			&p.WritePermission,
		)
		permissions = append(permissions, p)
	}
	return permissions, nil
}

//GetPermissionParcialCompany is the method to get all the permission of table Permission
func GetPermissionParcialCompany(company int, role string, dni string) ([]Permission, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	p.company,p.user,p.companykey,p.datakey,p.read_permission,p.write_permission
				FROM permission AS p LEFT JOIN company AS c ON p.company = c.id
				WHERE p.company = ?
				ORDER BY p.company,p.user,p.companykey,p.datakey,p.read_permission,p.write_permission;`
	} else {

		q = `SELECT	p.company,p.user,p.companykey,p.datakey,p.read_permission,p.write_permission
				FROM permission AS p LEFT JOIN company AS c ON p.company = c.id
				WHERE p.company = ? 
				AND p.user = ?
				ORDER BY p.company,p.user,p.companykey,p.datakey,p.read_permission,p.write_permission;`
	}
	rows, err := db.Query(q, company, dni)
	if err != nil {
		return []Permission{}, err
	}
	defer rows.Close()
	permissions := []Permission{}
	for rows.Next() {
		p := Permission{}
		rows.Scan(
			&p.Company,
			&p.User,
			&p.CompanyKey,
			&p.DataKey,
			&p.ReadPermission,
			&p.WritePermission,
		)
		permissions = append(permissions, p)
	}
	return permissions, nil
}

//UpdatePermission Insert a new permission with autoincrement id
func UpdatePermission(p Permission) error {

	db := GetConnection()
	q := `UPDATE permission
	 		SET   companykey = ?, datakey = ?, read_permission = ?, write_permission = ? 
			WHERE company = ?
			AND user = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(p.CompanyKey, p.DataKey, p.ReadPermission, p.WritePermission, p.Company, p.User)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//DeletePermission Insert a new permission with autoincrement id
func DeletePermission(p Permission) error {

	db := GetConnection()
	q := `DELETE FROM permission
			WHERE company = ?
			AND user = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(p.Company, p.User)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}
