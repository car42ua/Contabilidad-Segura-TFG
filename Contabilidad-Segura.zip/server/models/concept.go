package models

import (
	"errors"
	"fmt"

	_ "github.com/mutecomm/go-sqlcipher"
)

//ConceptKey is the struct of the table concept
type ConceptKey struct {
	Structure Concept
	Key       []byte
}

//Concept is the model of table Concept
type Concept struct {
	ID    int    `json:"id"`
	Title string `json:"title"`
}

//CreateConceptTable is used to create Concept table when creating database for the first time
func CreateConceptTable(id int, key []byte) error {
	db := GetConnectionCompany(id, key)

	stmt, err :=
		db.Prepare(`CREATE TABLE concept(
						id INTEGER CONSTRAINT cpconcept PRIMARY KEY AUTOINCREMENT,
						title VARCHAR(20)
					);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())

	} else {
		fmt.Println("Table created successfully..")
	}
	return err
}

//InsertConcept Insert a new company with autoincrement id
func InsertConcept(c Concept) (int64, error) {

	db := GetConnection()
	q := `INSERT INTO concept (title)
            VALUES(?);`

	stmt, err := db.Prepare(q)
	if err != nil {
		return 0, err
	}

	defer stmt.Close()

	r, err := stmt.Exec(c.Title)

	if err != nil {
		return 0, err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return 0, errors.New("ERROR: Se esperaba una fila afectada")
	}
	id, err := r.LastInsertId()

	if err != nil {
		return 0, err
	}

	return id, nil
}

//GetConcept is the method to get all de concepts of table Concept
func GetConcept() ([]Concept, error) {
	db := GetConnection()
	var q string

	q = `SELECT	id, title
			FROM concept;`

	rows, err := db.Query(q)
	if err != nil {
		return []Concept{}, err
	}
	defer rows.Close()
	concepts := []Concept{}
	for rows.Next() {
		s := Concept{}
		rows.Scan(
			&s.ID,
			&s.Title,
		)
		concepts = append(concepts, s)
	}
	return concepts, nil
}

//GetConceptByID is the method to get all de concepts of table Concept
func GetConceptByID(id int) (Concept, error) {
	c := Concept{}

	db := GetConnection()
	var q string

	q = `SELECT	id, title
			FROM concept
			WHERE id = ?`

	row := db.QueryRow(q, id)

	err := row.Scan(
		&c.ID,
		&c.Title,
	)

	if err != nil {
		return c, err
	}

	return c, nil
}

//UpdateConcept Insert a new concepts with autoincrement id
func UpdateConcept(c Concept) error {

	db := GetConnection()
	q := `UPDATE concept SET title = ? 
            WHERE id = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(c.Title, c.ID)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//DeleteConcept Insert a new concept with autoincrement id
func DeleteConcept(id int) error {

	db := GetConnection()
	q := `DELETE FROM concept
            WHERE id = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(id)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}
