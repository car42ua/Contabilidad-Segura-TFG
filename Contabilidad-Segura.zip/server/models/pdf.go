package models

import (
	_ "github.com/mutecomm/go-sqlcipher"
)

//PDFJournalKey is the struct of the table account
type PDFJournalKey struct {
	Structure PDFJournalStruct
	Key       []byte
}

//PDFJournalStruct is the struct of the pdf
type PDFJournalStruct struct {
	AcYear  int `json:"id"`
	Company int `json:"company"`
}

//PDFAccountKey is the struct of the table account
type PDFAccountKey struct {
	Structure PDFAccountStruct
	Key       []byte
}

//PDFAccountStruct is the struct of the pdf
type PDFAccountStruct struct {
	AcYear  int `json:"id"`
	Company int `json:"company"`
	From    int `json:"from"`
	To      int `json:"to"`
}

//GetJournalPDF is the method to get the notes of general journal to create the pdf
func GetJournalPDF(acyear, company int) ([]SeatNoteEnc, error) {
	db := GetConnection()
	var q string

	q = `SELECT n.id,n.seat,js.journal,n.account,n.company,n.concept,n.amount,n.dc,s.section,sec.title,c.title,s.seatdate,ac.title
			FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
			JOIN dbcomp.journalseat AS js ON n.seat = js.seat
			JOIN journal AS j ON j.id = js.journal AND j.general = 0
			JOIN section AS sec ON sec.id = s.section
			JOIN concept AS c ON c.id = n.concept
			JOIN dbcomp.account AS ac ON n.account = ac.id
			WHERE j.ac_year = ?
			AND j.company = ?;`

	rows, err := db.Query(q, acyear, company)
	if err != nil {
		return []SeatNoteEnc{}, err
	}
	defer rows.Close()
	notes := []SeatNoteEnc{}
	for rows.Next() {
		n := SeatNoteEnc{}
		rows.Scan(
			&n.ID,
			&n.Seat,
			&n.Journal,
			&n.Account,
			&n.Company,
			&n.Concept,
			&n.Amount,
			&n.DC,
			&n.Section,
			&n.TitleSection,
			&n.TitleConcept,
			&n.SeatDate,
			&n.TitleAccount,
		)
		notes = append(notes, n)
	}
	return notes, nil
}

//GetAccountPDF is the method to get all de companies of table Account
func GetAccountPDF(acyear, company, from, to int) ([]SeatNoteEnc, error) {
	db := GetConnection()
	var q string

	q = `SELECT n.id,n.seat,js.journal,n.account,n.company,n.concept,n.amount,n.dc,s.section,sec.title,c.title,s.seatdate,ac.title
			FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
			JOIN dbcomp.journalseat AS js ON n.seat = js.seat
			JOIN journal AS j ON j.id = js.journal AND j.general = 0
			JOIN section AS sec ON sec.id = s.section
			JOIN concept AS c ON c.id = n.concept
			JOIN dbcomp.account AS ac ON n.account = ac.id
			WHERE j.ac_year = ?
			AND j.company = ?
			AND n.account BETWEEN ? AND ? ;`

	rows, err := db.Query(q, acyear, company,from,to)
	if err != nil {
		return []SeatNoteEnc{}, err
	}
	defer rows.Close()
	notes := []SeatNoteEnc{}
	for rows.Next() {
		n := SeatNoteEnc{}
		rows.Scan(
			&n.ID,
			&n.Seat,
			&n.Journal,
			&n.Account,
			&n.Company,
			&n.Concept,
			&n.Amount,
			&n.DC,
			&n.Section,
			&n.TitleSection,
			&n.TitleConcept,
			&n.SeatDate,
			&n.TitleAccount,
		)
		notes = append(notes, n)
	}
	return notes, nil
}
