package models

import (
	"errors"
	"fmt"

	_ "github.com/mutecomm/go-sqlcipher"
)

//SeatKey is the struct of the table seat
type SeatKey struct {
	Structure Seat
	Key       []byte
}

//Seat is the model of table Seat
type Seat struct {
	ID       int    `json:"id"`
	Journal  int    `json:"journal"`
	Section  int    `json:"section"`
	SeatDate string `json:"seatdate"`
}

//SendSeat is the model of table Seat  to response from the server
type SendSeat struct {
	ID           int    `json:"id"`
	Journal      int    `json:"journal"`
	Section      int    `json:"section"`
	SeatDate     string `json:"seatdate"`
	TitleSection string `json:"titlesection"`
}

//CreateSeatTable is used to create Seat table when creating database for the first time
func CreateSeatTable(id int, key []byte) error {
	db := GetConnectionCompany(id, key)

	stmt, err :=
		db.Prepare(`CREATE TABLE seat(
								id INTEGER CONSTRAINT cpseat PRIMARY KEY AUTOINCREMENT,
								section INTEGER(2),
								seatdate TEXT,
								CONSTRAINT fkseat FOREIGN KEY (section) REFERENCES section(id)
							);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("Table seat created successfully..")
	}
	trigger := `
	CREATE TRIGGER seat_aft_del AFTER DELETE ON seat

	BEGIN                   
          DELETE FROM journalseat
          WHERE seat = seat;

          DELETE FROM auto_increment_note
          WHERE seat = seat; 
    END;`
	_, err = db.Exec(trigger)

	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("Trigger seat_aft_del created successfully..")
	}

	return err
}

//InsertSeat Insert a new seat with autoincrement id
func InsertSeat(s Seat) (int64, error) {

	db := GetConnection()

	q := `INSERT INTO dbcomp.seat (section,seatdate)
            VALUES(?, ?);`

	stmt, err := db.Prepare(q)
	if err != nil {
		return 0, err
	}

	defer stmt.Close()

	r, err := stmt.Exec(s.Section, s.SeatDate)
	if err != nil {
		return 0, err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return 0, errors.New("ERROR: Se esperaba una fila afectada")
	}
	id, err := r.LastInsertId()
	if err != nil {
		return 0, err
	}
	/// Now create a row in journalseat
	js := JournalSeat{
		Seat:       int(id),
		Journal:    s.Journal,
		OldJournal: 0,
	}
	err = InsertJournalSeat(js)

	if err != nil {
		return 0, err
	}
	return id, nil
}

//GetSeat is the method to get all the seat of table Seat
func GetSeat(role string, dni string) ([]SendSeat, error) {
	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	s.id,js.journal,s.section,s.seatdate,sec.title
				FROM dbcomp.seat AS s JOIN section AS sec ON sec.id = s.section
				JOIN dbcomp.journalseat AS js ON s.id = js.seat ;`
	} else {
		q = `SELECT s.id,js.journal,s.section,s.seatdate,sec.title
				FROM dbcomp.seat AS s JOIN dbcomp.journalseat AS js ON s.id = js.seat
				JOIN ac_year AS a ON a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON a.company = p.company 
				JOIN section AS sec ON sec.id = s.section
				WHERE p.user = ?
				AND a.opened = 1;`
	}

	rows, err := db.Query(q, dni)
	if err != nil {
		return []SendSeat{}, err
	}
	defer rows.Close()
	seats := []SendSeat{}
	for rows.Next() {
		s := SendSeat{}
		rows.Scan(
			&s.ID,
			&s.Journal,
			&s.Section,
			&s.SeatDate,
			&s.TitleSection,
		)
		seats = append(seats, s)
	}
	return seats, nil
}

//GetSeatByID is the method to get all the seats by ID of table Seat
func GetSeatByID(id int, role string, dni string) (SendSeat, error) {

	s := SendSeat{}

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	s.id,js.journal,s.section,s.seatdate,sec.title
				FROM dbcomp.seat AS s JOIN section AS sec ON sec.id = s.section 
				JOIN dbcomp.journalseat AS js ON s.id = js.seat 
				WHERE id = ?;`
	} else {
		q = `SELECT s.id,js.journal,s.section,s.seatdate,sec.title
				FROM dbcomp.seat AS s 	JOIN dbcomp.journalseat AS js ON s.id = js.seat 
				JOIN dbcomp.journal AS j ON j.id = js.journal
				JOIN ac_year AS a ON  a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON a.company = p.company 
				JOIN section AS sec ON sec.id = s.section
				WHERE s.id = ? 
				AND p.user = ?
				AND a.opened = 1;`
	}
	row := db.QueryRow(q, id, dni)

	err := row.Scan(
		&s.ID,
		&s.Journal,
		&s.Section,
		&s.SeatDate,
		&s.TitleSection,
	)

	if err != nil {
		return s, err
	}
	return s, nil
}

//GetSeatParcialJournal is the method to get all the seats by seat of table Seat
func GetSeatParcialJournal(journal int, role string, dni string) ([]SendSeat, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	s.id,js.journal,s.section,s.seatdate,sec.title
				FROM dbcomp.seat AS s JOIN section AS sec ON sec.id = s.section 
				JOIN dbcomp.journalseat AS js ON s.id = js.seat 
				WHERE js.journal = ?;`
	} else {
		q = `SELECT s.id,js.journal,s.section,s.seatdate,sec.title
				FROM dbcomp.seat AS s JOIN dbcomp.journalseat AS js ON s.id = js.seat 
				JOIN dbcomp.journal AS j ON j.id = js.journal
				JOIN ac_year AS a ON a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON a.company = p.company 
				JOIN section AS sec ON sec.id = s.section
				WHERE js.journal = ? 
				AND p.user = ?
				AND a.opened = 1;`
	}
	rows, err := db.Query(q, journal, dni)
	if err != nil {
		return []SendSeat{}, err
	}
	defer rows.Close()
	seats := []SendSeat{}
	for rows.Next() {
		s := SendSeat{}
		rows.Scan(
			&s.ID,
			&s.Journal,
			&s.Section,
			&s.SeatDate,
			&s.TitleSection,
		)
		seats = append(seats, s)
	}
	return seats, nil
}

//UpdateSeat Insert a new seat with autoincrement id
func UpdateSeat(s Seat) error {

	db := GetConnection()
	q := `UPDATE dbcomp.seat SET section = ?, seatdate = ?
            WHERE id = ? ;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(s.Section, s.SeatDate, s.ID)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//DeleteSeat Delete a seat by id 
func DeleteSeat(id int) error {

	db := GetConnection()
	q := `DELETE FROM dbcomp.seat
            WHERE id = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(id)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}
