package models

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	"errors"
	"fmt"
	"io"
	"log"

	_ "github.com/mutecomm/go-sqlcipher"
)

//User is the model of table User
type User struct {
	DNI            string `json:"dni"`
	Name           string `json:"name"`
	Email          string `json:"email"`
	Role           string `json:"role"`
	PasswordHashed []byte `json:"pass"`
	Salt           []byte `json:"salt"`
	PubKey         []byte `json:"pubkey"`
	PrivKey        []byte `json:"privkey"`
}

//Hash we will hash the server to have 0 knowledge of the password.
func (u *User) Hash(password, salt []byte) {
	hash := sha256.New()
	//Write the password in the buffer
	_, err := hash.Write(password)
	if err != nil {
		panic(err)
	}
	//Write the salt in the buffer
	_, err = hash.Write(salt)
	if err != nil {
		panic(err)
	}
	//Save the salt to be used in the future
	u.Salt = salt
	u.PasswordHashed = hash.Sum(nil)
}

//CompareHash will check the password saved by the user to verify if it is correct
func (u *User) CompareHash(passwordToCompare []byte) bool {
	hash := sha256.New()
	_, err := hash.Write(passwordToCompare)
	if err != nil {
		panic(err)
	}
	_, err = hash.Write(u.Salt)
	if err != nil {
		panic(err)
	}
	passwordHashed := hash.Sum(nil)

	return bytes.Compare(u.PasswordHashed, passwordHashed) == 0
}

//EncryptContent receives an array of bytes and returns the same but encrypted
func (u *User) EncryptContent(content []byte) ([]byte, error) {
	//Creates the cipher
	c, err := aes.NewCipher(u.PasswordHashed)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(c)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err = io.ReadFull(rand.Reader, nonce); err != nil {
		fmt.Println(err)
	}
	//Seal the content to be retorned encrypted
	encryptedContent := gcm.Seal(nonce, nonce, content, nil)

	return encryptedContent, nil
}

//DecryptContent receives an array of bytes encrypted and returns the same but decrypted
func (u *User) DecryptContent(content []byte) ([]byte, error) {
	//Creates the cipher
	c, err := aes.NewCipher(u.PasswordHashed)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(c)
	if err != nil {
		return nil, err
	}
	nonceSize := gcm.NonceSize()
	if len(content) < nonceSize {
		return nil, fmt.Errorf("Error: the encrypted content doens't correspond to this key because it's too small")
	}
	//Get the content without nonce and decrypt that
	nonce, content := content[:nonceSize], content[nonceSize:]
	decryptedContent, err := gcm.Open(nil, nonce, content, nil)
	if err != nil {
		return nil, err
	}

	return decryptedContent, nil
}

//CreateUserTable is used to create User table when creating database for the first time
func CreateUserTable() error {
	db := GetConnection()

	stmt, err :=
		db.Prepare(`
		CREATE TABLE user(dni TEXT PRIMARY KEY,	name TEXT,email TEXT,role TEXT,
							pass TEXT,salt TEXT,pubkey int,privkey int);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())

	} else {
		fmt.Println("Table created successfully..")
	}
	return err
}

//InsertUser Insert a new user with autoincrement id
func InsertUser(u *User) error {

	db := GetConnection()
	q := `INSERT INTO user (dni, name, email, role , pass, salt , pubkey, privkey)
            VALUES(?, ?, ?, ?, ?, ?, ?, ?);`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(u.DNI, u.Name, u.Email, u.Role, u.PasswordHashed, u.Salt, u.PubKey, u.PrivKey)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//GetUser is the method to get all the user of table User
func GetUser(role string, dni string) ([]User, error) {
	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	dni, name, email, role , pass, salt , pubkey, privkey 
				FROM user` // Ejecutamos la query
	} else {
		q = `SELECT u.dni, u.name, u.email, u.role , u.pass, u.salt , u.pubkey, u.privkey 
				FROM user AS u
				WHERE u.dni = ?;` // Ejecutamos la query
	}

	rows, err := db.Query(q, dni)
	if err != nil {
		return []User{}, err
	}
	defer rows.Close()
	users := []User{}
	for rows.Next() {
		u := User{}
		rows.Scan(
			&u.DNI,
			&u.Name,
			&u.Email,
			&u.Role,
			&u.PasswordHashed,
			&u.Salt,
			&u.PubKey,
			&u.PrivKey,
		)
		users = append(users, u)
	}
	return users, nil
}

//GetUserByDNI is a method to identify if the administrator exists.
func GetUserByDNI(dni string) (*User, error) {
	u := User{}

	db := GetConnection()
	q := `SELECT  u.dni, u.name, u.email, u.role , u.pass, u.salt , u.pubkey, u.privkey 
			FROM user AS u  
			WHERE u.dni = ?`

	row := db.QueryRow(q, dni)

	err := row.Scan(
		&u.DNI,
		&u.Name,
		&u.Email,
		&u.Role,
		&u.PasswordHashed,
		&u.Salt,
		&u.PubKey,
		&u.PrivKey,
	)

	if err != nil {
		return &u, err
	}

	return &u, nil
}

//GetUsers is a method to identify if the administrator exists.
func GetUsers() (users []User, err error) {

	db := GetConnection()
	q := `SELECT u.* FROM user AS u `

	rows, err := db.Query(q)

	if err != nil {
		return
	}

	defer rows.Close()
	var u *User

	for rows.Next() {
		rows.Scan(
			&u.DNI,
			&u.Name,
			&u.Email,
			&u.Role,
			&u.PasswordHashed,
			&u.Salt,
			&u.PubKey,
			&u.PrivKey,
		)
		users = append(users, *u)
	}
	return users, nil
}

//UserExists Check if the user exist in the db
func UserExists(dni string) bool {

	db := GetConnection()
	sqlStmt := `SELECT dni FROM user WHERE dni = ?`
	err := db.QueryRow(sqlStmt, dni).Scan(&dni)
	if err != nil {
		if err != sql.ErrNoRows {
			log.Print(err)
		}
		return false
	}
	return true
}

//ModifyUser is the method to UPDATE a new USER
func ModifyUser(u *User) error {

	db := GetConnection()
	q := `UPDATE user 
			SET name = ?,email = ?,role = ?,pass = ?,salt = ?,pubkey = ?,privkey = ?
            WHERE dni = ?`
	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()
	r, err := stmt.Exec(u.Name, u.Email, u.Role, u.PasswordHashed, u.Salt, u.PubKey, u.PrivKey, u.DNI)
	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}
	return nil
}

//DeleteUser is the method to DELETE a new USER
func DeleteUser(u *User) error {

	db := GetConnection()
	q := `DELETE FROM user 
            WHERE dni = ?`
	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()
	r, err := stmt.Exec(u.DNI)
	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}
	return nil
}
