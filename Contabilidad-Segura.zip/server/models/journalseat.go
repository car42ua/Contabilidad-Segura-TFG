package models

import (
	"errors"
	"fmt"

	_ "github.com/mutecomm/go-sqlcipher"
)

//JournalSeatKey is the struct of the table journalseat
type JournalSeatKey struct {
	Structure JournalSeat
	Key       []byte
}

//JournalSeat is the model of table Permision
type JournalSeat struct {
	OldJournal int `json:"oldjournal"`
	Journal    int `json:"journal"`
	Seat       int `json:"seat"`
}

//CreateJournalSeatTable is used to create Permision table when creating database for the first time
func CreateJournalSeatTable(id int, key []byte) error {
	db := GetConnectionCompany(id, key)

	stmt, err :=
		db.Prepare(`CREATE TABLE journalseat(
						seat INTEGER(3) NOT NULL,
						journal TEXT NOT NULL,
						PRIMARY KEY(seat,journal),
						CONSTRAINT fkseat FOREIGN KEY(seat) REFERENCES seat(id),
						CONSTRAINT fkjournal FOREIGN KEY(journal) REFERENCES journal(id)
					);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())

	} else {
		fmt.Println("Table journalseat created successfully..")
	}
	return err
}

//InsertJournalSeat Insert a new journalseat with autoincrement id
func InsertJournalSeat(js JournalSeat) error {

	db := GetConnection()
	q := `INSERT INTO journalseat (seat,journal)
            VALUES(?, ?);`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	_, err = stmt.Exec(js.Seat, js.Journal)

	if err != nil {
		return err
	}

	if js.OldJournal != 0 {
		q = `DELETE FROM journalseat
						WHERE seat = ?
						AND journal = ?;`

		stmt, err = db.Prepare(q)
		if err != nil {
			return err
		}

		defer stmt.Close()

		r, err := stmt.Exec(js.Seat, js.OldJournal)

		if err != nil {
			return err
		}
		if i, err := r.RowsAffected(); err != nil || i != 1 {
			return errors.New("ERROR: Se esperaba una fila afectada")
		}
	}
	return nil
}

//GetJournalSeat is the method to get all de journalseat of table JournalSeat
func GetJournalSeat(role string, id string) ([]JournalSeat, error) {
	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	seat,journal
				FROM journalseat` // Ejecutamos la query
	} else {
		q = `SELECT js.seat,js.journal	
				FROM journalseat AS js
				JOIN journal AS j ON j.id = js.journal
				JOIN ac_year AS a ON a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON a.company = p.company 
				WHERE p.user = ?` // Ejecutamos la query
	}

	rows, err := db.Query(q, id)
	if err != nil {
		return []JournalSeat{}, err
	}
	defer rows.Close()
	journalseats := []JournalSeat{}
	for rows.Next() {
		js := JournalSeat{}
		rows.Scan(
			&js.Seat,
			&js.Journal,
		)
	}
	return journalseats, nil
}

//GetJournalSeatByID is the method to get all the journalseat of table JournalSeat
func GetJournalSeatByID(journal int, seat int, role string, id string) (*JournalSeat, error) {
	js := JournalSeat{}

	db := GetConnection()
	var q string
	// var err error
	// var rows *sql.Rows

	if role == "admin" {

		q = `SELECT	seat,journal
				FROM journalseat
				WHERE seat = ?
				AND journal = ?`
	} else {

		q = `SELECT js.seat,js.journal	
				FROM journalseat AS js
				JOIN journal AS j ON j.id = js.journal
				JOIN ac_year AS a ON a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON a.company = p.company 
				WHERE seat = ? 
				AND journal = ?
				AND p.user = ?;`
	}
	row := db.QueryRow(q, seat, journal, id)

	err := row.Scan(
		&js.Seat,
		&js.Journal,
	)
	if err != nil {
		return &js, err
	}

	return &js, nil
}

//GetJournalSeatParcialJournal is the method to get all the journalseat of table Seat
func GetJournalSeatParcialJournal(journal int, role string, id string) ([]JournalSeat, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	js.seat,js.journal
				FROM journalseat AS js JOIN seat AS s ON js.seat = s.id
				WHERE js.journal = ?
				ORDER BY js.seat,js.journal;`
	} else {

		q = `SELECT	js.seat,js.journal
				FROM journalseat AS js JOIN seat AS s ON js.seat = s.id
				JOIN journal AS j ON j.id = js.journal
				JOIN ac_year AS a ON a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON a.company = p.company 
				WHERE js.journal = ?
				and p.user = ?
				ORDER BY js.seat,js.journal;`
	}
	rows, err := db.Query(q, journal, id)
	if err != nil {
		return []JournalSeat{}, err
	}
	defer rows.Close()
	journalseats := []JournalSeat{}
	for rows.Next() {
		js := JournalSeat{}
		rows.Scan(
			&js.Seat,
			&js.Journal,
		)
		journalseats = append(journalseats, js)
	}
	return journalseats, nil
}

//GetJournalSeatParcialSeat is the method to get all the journalseat of table Seat
func GetJournalSeatParcialSeat(seat int, role string, id string) ([]JournalSeat, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	js.seat,js.journal
				FROM journalseat AS js JOIN seat AS s ON js.seat = s.id
				WHERE js.seat = ?
				ORDER BY js.seat,js.journal;`
	} else {

		q = `SELECT	js.seat,js.journal
				FROM journalseat AS js JOIN seat AS s ON js.seat = s.id
				JOIN journal AS j ON j.id = js.journal
				JOIN ac_year AS a ON a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON a.company = p.company 
				WHERE js.seat = ?
				and p.user = ?
				ORDER BY js.seat,js.journal;`
	}
	rows, err := db.Query(q, seat, id)
	if err != nil {
		return []JournalSeat{}, err
	}
	defer rows.Close()
	journalseats := []JournalSeat{}
	for rows.Next() {
		js := JournalSeat{}
		rows.Scan(
			&js.Seat,
			&js.Journal,
		)
		journalseats = append(journalseats, js)
	}
	return journalseats, nil
}

//DeleteJournalSeat Insert a new journalseat with autoincrement id
func DeleteJournalSeat(js JournalSeat) error {

	db := GetConnection()
	q := `DELETE FROM journalseat
			WHERE seat = ?
			AND journal = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(js.Seat, js.Journal)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}
