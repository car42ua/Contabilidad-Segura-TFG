package models

import (
	"errors"
	"fmt"
)

//AccountKey is the struct of the table account
type AccountKey struct {
	Structure Account
	Key       []byte
}

//Account is the struct of the table Account
type Account struct {
	ID      int    `json:"id"`
	Company int    `json:"company"`
	Title   string `json:"title"`
}

//SendAccount is the struct for get one account.
type SendAccount struct {
	ID          int     `json:"id"`
	Company     int     `json:"company"`
	Title       string  `json:"title"`
	TotalDebit  float64 `json:"totaldebit"`
	TotalCredit float64 `json:"totalcredit"`
	Balance     float64 `json:"balance"`
}

//CreateAccountTable is used to create Account table when creating database for the first time
func CreateAccountTable(id int, key []byte) error {
	db := GetConnectionCompany(id, key)

	stmt, err :=
		db.Prepare(`CREATE TABLE account(
						id INTEGER(8),
						company INTEGER(3),
						title VARCHAR(20),
						CONSTRAINT fkcompany FOREIGN KEY(company) REFERENCES company(id),
						CONSTRAINT cpaccount PRIMARY KEY(id,company)
					);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())

	} else {
		fmt.Println("Table account created successfully..")
	}
	return err
}

//InsertAccount Insert a new Account with autoincrement id
func InsertAccount(a Account) (int64, error) {

	db := GetConnection()

	q := `INSERT INTO dbcomp.account (id,company,title)
            VALUES(?, ?, ?);`

	stmt, err := db.Prepare(q)
	if err != nil {
		return 0, err
	}

	defer stmt.Close()

	r, err := stmt.Exec(a.ID, a.Company, a.Title)
	if err != nil {
		return 0, err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return 0, errors.New("ERROR: Se esperaba una fila afectada")
	}
	id, err := r.LastInsertId()

	if err != nil {
		return 0, err
	}

	return id, nil
}

//GetAccount is the method to get all de account of table Account
func GetAccount(role string, dni string) ([]Account, error) {
	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	id,company,title
				FROM dbcomp.account`
	} else {
		q = `SELECT a.id,a.company,a.title
				FROM dbcomp.account AS a JOIN company AS c ON a.company = c.id
				JOIN permission AS p ON p.company = a.company
				WHERE p.user = ?
				AND a.opened = 1;`
	}

	rows, err := db.Query(q, dni)
	if err != nil {
		return []Account{}, err
	}
	defer rows.Close()
	accounts := []Account{}
	for rows.Next() {
		a := Account{}
		rows.Scan(
			&a.ID,
			&a.Company,
			&a.Title,
		)
		accounts = append(accounts, a)
	}
	return accounts, nil
}

//GetAccountByID is the method to get account of table Account by id
func GetAccountByID(id, company int, role string, dni string) (SendAccount, error) {
	a := SendAccount{}

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT a.id, a.company, a.title,
			sum(CASE WHEN n.dc ="D"
				THEN n.amount ELSE 0 END) AS totaldebit,
			sum(CASE WHEN n.dc ="C"
				THEN n.amount ELSE 0 END) AS totalcredit,
			sum(CASE WHEN n.dc ="D"
				THEN n.amount ELSE 0 END) -
			sum(CASE WHEN n.dc ="C"
				THEN n.amount ELSE 0 END) AS Balance
			FROM dbcomp.account AS a JOIN permission AS p on a.company = p.company
			JOIN dbcomp.note AS n ON a.id = n.account
			WHERE a.id = ? 
			AND a.company = ? 
			GROUP BY a.id, a.company, a.title;`
	} else {
		q = `SELECT a.id, a.company, a.title,
		sum(CASE WHEN n.dc ="D"
			THEN n.amount ELSE 0 END) AS totaldebit,
		sum(CASE WHEN n.dc ="C"
			THEN n.amount ELSE 0 END) AS totalcredit,
		sum(CASE WHEN n.dc ="D"
			THEN n.amount ELSE 0 END) -
		sum(CASE WHEN n.dc ="C"
			THEN n.amount ELSE 0 END) AS balance
			FROM dbcomp.account AS a JOIN permission AS p on a.company = p.company
			JOIN dbcomp.note AS n ON a.id = n.account
			WHERE a.id = ?
			AND a.company = ?
			AND p.user = ? 
			GROUP BY a.id, a.company, a.title;`
	}

	row := db.QueryRow(q, id, company, dni)

	err := row.Scan(
		&a.ID,
		&a.Company,
		&a.Title,
		&a.TotalDebit,
		&a.TotalCredit,
		&a.Balance,
	)

	if err != nil {
		return a, err
	}

	return a, nil
}

//GetAccountParcialCompany is the method to get all account of table Account
func GetAccountParcialCompany(company int, role string, dni string) ([]Account, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	id, company, title
				FROM dbcomp.account
				WHERE company = ?;`
	} else {

		q = `SELECT a.id, a.company, a.title
				FROM dbcomp.account AS a JOIN permission AS p on a.company = p.company
				WHERE a.company = ? 
				AND p.user = ?;`
	}
	rows, err := db.Query(q, company, dni)
	if err != nil {
		return []Account{}, err
	}
	defer rows.Close()
	accounts := []Account{}
	for rows.Next() {
		a := Account{}
		rows.Scan(
			&a.ID,
			&a.Company,
			&a.Title,
		)
		accounts = append(accounts, a)
	}
	return accounts, nil
}

//UpdateAccount Insert a new account with autoincrement id
func UpdateAccount(a Account) error {

	db := GetConnection()
	q := `UPDATE dbcomp.account SET title = ?
            WHERE id = ? AND company = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(a.ID, a.Company, a.Title)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//DeleteAccount Insert a new account with autoincrement id
func DeleteAccount(id, company int) error {

	db := GetConnection()
	q := `DELETE FROM dbcomp.account
            WHERE id = ? AND company = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(id, company)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}
