package models

import (
	"errors"
	"fmt"

	_ "github.com/mutecomm/go-sqlcipher"
)

//SectionKey is the struct of the table section
type SectionKey struct {
	Structure Section
	Key       []byte
}

//Section is the model of table Section
type Section struct {
	ID    int    `json:"id"`
	Title string `json:"title"`
}

//CreateSectionTable is used to create Section table when creating database for the first time
func CreateSectionTable(id int, key []byte) error {
	db := GetConnectionCompany(id, key)

	stmt, err :=
		db.Prepare(`CREATE TABLE section(
						id INTEGER CONSTRAINT cpsection PRIMARY KEY AUTOINCREMENT,
						title VARCHAR(20)
					);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())

	} else {
		fmt.Println("Table created successfully..")
	}
	return err
}

//InsertSection Insert a new section with autoincrement id
func InsertSection(s Section) (int64, error) {

	db := GetConnection()
	q := `INSERT INTO dbcomp.section (title)
            VALUES(?);`

	stmt, err := db.Prepare(q)
	if err != nil {
		return 0, err
	}

	defer stmt.Close()

	r, err := stmt.Exec(s.Title)

	if err != nil {
		return 0, err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return 0, errors.New("ERROR: Se esperaba una fila afectada")
	}
	id, err := r.LastInsertId()

	if err != nil {
		return 0, err
	}

	return id, nil
}

//GetSection is the method to get all de sections of table Section
func GetSection() ([]Section, error) {
	db := GetConnection()
	var q string

	q = `SELECT	id, title
			FROM dbcomp.section;`

	rows, err := db.Query(q)
	if err != nil {
		return []Section{}, err
	}
	defer rows.Close()
	sections := []Section{}
	for rows.Next() {
		s := Section{}
		rows.Scan(
			&s.ID,
			&s.Title,
		)
		sections = append(sections, s)
	}
	return sections, nil
}

//GetSectionByID is the method to get all the sections of table Section
func GetSectionByID(id int) (Section, error) {
	s := Section{}

	db := GetConnection()
	var q string

	q = `SELECT	id, title
			FROM dbcomp.section
			WHERE id = ?`

	row := db.QueryRow(q, id)

	err := row.Scan(
		&s.ID,
		&s.Title,
	)

	if err != nil {
		return s, err
	}

	return s, nil
}

//UpdateSection Insert a new section with autoincrement id
func UpdateSection(s Section) error {

	db := GetConnection()
	q := `UPDATE dbcomp.section SET title = ? 
            WHERE id = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(s.Title, s.ID)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//DeleteSection Insert a new section with autoincrement id
func DeleteSection(id int) error {

	db := GetConnection()
	q := `DELETE FROM dbcomp.section
            WHERE id = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(id)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}
