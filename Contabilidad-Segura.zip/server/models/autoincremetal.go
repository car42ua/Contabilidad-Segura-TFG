package models

import (
	"fmt"

	_ "github.com/mutecomm/go-sqlcipher"
)

//AutoIncrementalNote is the model of table auto_increment_note
type AutoIncrementalNote struct {
	ID   int `json:"id"`
	Seat int `json:"seat"`
}

//CreateAutoIncrementalTables is used to create AutoIncremental tables when creating database for the first time
func CreateAutoIncrementalTables(id int, key []byte) error {
	db := GetConnectionCompany(id, key)

	stmt, err :=
		db.Prepare(`CREATE TABLE auto_increment_note (id INT, seat INT);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("Table created successfully..")
	}

	return err
}

//GetAutoIncrementalNoteBySeat is the method to get the number of autoincremental note by seat and journal
func GetAutoIncrementalNoteBySeat(seat int) (int, error) {

	a := AutoIncrementalNote{}

	db := GetConnection()
	var q string

	q = `SELECT	id 
			FROM dbcomp.auto_increment_note
			WHERE seat = ?;`

	row := db.QueryRow(q, seat)

	err := row.Scan(
		&a.ID,
	)

	if err != nil {
		return 0, err
	}

	return a.ID, nil
}
