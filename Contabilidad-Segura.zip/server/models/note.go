package models

import (
	"errors"
	"fmt"

	_ "github.com/mutecomm/go-sqlcipher"
)

//NoteKey is the struct of the table note
type NoteKey struct {
	Structure Note
	Key       []byte
}

//Note is the model of table Note
type Note struct {
	ID      int     `json:"id"`
	Seat    int     `json:"seat"`
	Journal int     `json:"journal"`
	Account int     `json:"account"`
	Company int     `json:"company"`
	Concept int     `json:"concept"`
	Amount  float64 `json:"amount"`
	DC      string  `json:"dc"`
}

//NoteEncKey is the struct of the table note
type NoteEncKey struct {
	Structure NoteEnc
	Key       []byte
}

//NoteEnc is the model of table Note with Amount and DC encrypt
type NoteEnc struct {
	ID      int    `json:"id"`
	Seat    int    `json:"seat"`
	Journal int    `json:"journal"`
	Account int    `json:"account"`
	Company int    `json:"company"`
	Concept int    `json:"concept"`
	Amount  []byte `json:"amount"`
	DC      []byte `json:"dc"`
}

//SeatNoteEncKey is the struct of the table sentnote
type SeatNoteEncKey struct {
	Structure SeatNoteEnc
	Key       []byte
}

//SeatNoteKey is the struct of the table sentnote
type SeatNoteKey struct {
	Structure SeatNote
	Key       []byte
}

//SeatNote is the struct merge Note and Seat to response from the server
type SeatNote struct {
	ID           int     `json:"id"`
	Seat         int     `json:"seat"`
	Journal      int     `json:"journal"`
	Account      int     `json:"account"`
	Company      int     `json:"company"`
	Concept      int     `json:"concept"`
	Amount       float64 `json:"amount"`
	DC           string  `json:"dc"`
	Section      int     `json:"section"`
	TitleSection string  `json:"titlesection"`
	TitleConcept string  `json:"titleconcept"`
	SeatDate     string  `json:"seatdate"`
	TitleAccount string  `json:"titleaccount"`
}

//SeatNoteEnc is the struct with encrypt data to send the note to server
type SeatNoteEnc struct {
	ID           int    `json:"id"`
	Seat         int    `json:"seat"`
	Journal      int    `json:"journal"`
	Account      int    `json:"account"`
	Company      int    `json:"company"`
	Concept      int    `json:"concept"`
	Amount       []byte `json:"amount"`
	DC           []byte `json:"dc"`
	Section      int    `json:"section"`
	TitleSection string `json:"titlesection"`
	TitleConcept string `json:"titleconcept"`
	SeatDate     string `json:"seatdate"`
	TitleAccount string `json:"titleaccount"`
}

//CreateNoteTable is used to create Note table when creating database for the first time
func CreateNoteTable(id int, key []byte) error {
	db := GetConnectionCompany(id, key)

	stmt, err :=
		db.Prepare(`CREATE TABLE note(
								id INTEGER(8) CONSTRAINT cpnote,
								seat INTEGER,
								account INTEGER(8) NOT NULL,
								company INTEGER(3) NOT NULL,
								concept VARCHAR(20),
								amount DOUBLE(7,2),
								dc CHAR(1),
								CONSTRAINT fkaccount FOREIGN KEY(account,company) REFERENCES account(id,company),
								CONSTRAINT fkseat FOREIGN KEY(seat) REFERENCES seat(id),
								CONSTRAINT cpnote PRIMARY KEY (id,seat)
							);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())

	} else {
		fmt.Println("Table note created successfully..")
	}
	trigger := `
				CREATE TRIGGER note_bef_ins BEFORE INSERT ON note
				WHEN NOT EXISTS( SELECT 1 FROM auto_increment_note 
									WHERE (seat = new.seat))
				BEGIN                   
						INSERT INTO auto_increment_note (id,seat) VALUES (0,new.seat);
				END;`
	_, err = db.Exec(trigger)

	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("Trigger note_bef_ins created successfully..")
	}
	trigger = `
				CREATE TRIGGER note_aft_ins AFTER INSERT ON note
				BEGIN
					UPDATE  auto_increment_note
					SET     id = id + 1 
					WHERE   seat = new.seat ;
				
					UPDATE  note
					SET     id = (
								SELECT id 
								FROM auto_increment_note
								WHERE seat = new.seat)
					WHERE   ROWID = new.ROWID;
				END;`
	_, err = db.Exec(trigger)

	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("Trigger note_aft_ins created successfully..")
	}
	trigger = `
				CREATE TRIGGER note_aft_del AFTER DELETE ON note

				WHEN NOT EXISTS( SELECT 1 FROM note
									WHERE seat = seat)
				BEGIN                   
					DELETE FROM seat 
					WHERE id = id;
				END;`
	_, err = db.Exec(trigger)

	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("Trigger note_aft_del created successfully..")
	}
	return err
}

//InsertNote Insert a new note with autoincrement id
func InsertNote(n NoteEnc) (int, error) {

	db := GetConnection()

	q := `INSERT INTO dbcomp.note (id,seat,account,company,concept,amount,dc)
            VALUES(?, ?, ?, ?, ?, ?, ?);`

	stmt, err := db.Prepare(q)
	if err != nil {
		return 0, err
	}

	defer stmt.Close()

	r, err := stmt.Exec(n.ID, n.Seat, n.Account, n.Company, n.Concept, n.Amount, n.DC)
	if err != nil {
		return 0, err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return 0, errors.New("ERROR: Se esperaba una fila afectada")
	}

	id, err := GetAutoIncrementalNoteBySeat(n.Seat)
	if err != nil {
		return 0, err
	}

	return id, nil
}

//GetNoteByID is the method to get note of table Note by id
func GetNoteByID(id, seat int, role, dni string) (NoteEnc, error) {
	n := NoteEnc{}

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT id,seat,account,company,concept,amount,dc
				FROM dbcomp.note 
				WHERE id = ? 
				AND seat = ?;`
	} else {
		q = `SELECT id,seat,account,company,concept,amount,dc
				FROM dbcomp.note 
				WHERE id = ? 
				AND seat = ?;`
	}

	row := db.QueryRow(q, id, seat, dni)

	err := row.Scan(
		&n.ID,
		&n.Seat,
		&n.Account,
		&n.Company,
		&n.Concept,
		&n.Amount,
		&n.DC,
	)

	if err != nil {
		return n, err
	}

	return n, nil
}

//GetNoteParcialJournal is the method to get all de notes by ID of table Note
func GetNoteParcialJournal(journal int, role, dni string) ([]SeatNoteEnc, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT n.id,n.seat,js.journal,n.account,n.company,n.concept,n.amount,n.dc,s.section,sec.title,c.title,s.seatdate,ac.title
				FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
				JOIN dbcomp.journalseat AS js ON n.seat = js.seat
				JOIN section AS sec ON sec.id = s.section;
				JOIN concept AS c ON c.id = n.concept
				JOIN dbcomp.account AS ac ON n.account = ac.id;
				WHERE js.journal = ?`
	} else {
		q = `SELECT n.id,n.seat,js.journal,n.account,n.company,n.concept,n.amount,n.dc,s.section,sec.title,c.title,s.seatdate,ac.title
				FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
				JOIN dbcomp.journalseat AS js ON js.seat = n.seat
				JOIN dbcomp.journal AS j ON j.id = js.journal
				JOIN ac_year AS a ON a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON n.company = p.company
				JOIN section AS sec ON sec.id = s.section
				JOIN concept AS c ON c.id = n.concept
				JOIN dbcomp.account AS ac ON n.account = ac.id
				WHERE js.journal = ?
				AND p.user = ?
				AND a.opened = 1;`
	}

	rows, err := db.Query(q, journal, dni)
	if err != nil {
		return []SeatNoteEnc{}, err
	}
	defer rows.Close()

	notes := []SeatNoteEnc{}
	for rows.Next() {
		n := SeatNoteEnc{}
		rows.Scan(
			&n.ID,
			&n.Seat,
			&n.Journal,
			&n.Account,
			&n.Company,
			&n.Concept,
			&n.Amount,
			&n.DC,
			&n.Section,
			&n.TitleSection,
			&n.TitleConcept,
			&n.SeatDate,
			&n.TitleAccount,
		)
		notes = append(notes, n)
	}
	return notes, nil
}

//GetNoteParcialIDJournal is the method to get all the notes by ID of table Note
func GetNoteParcialIDJournal(id, journal int, role, dni string) ([]SeatNoteEnc, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT n.id,n.seat,js.journal,n.account,n.company,n.concept,n.amount,n.dc,s.section,sec.title,c.title,s.seatdate,ac.title
				FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
				JOIN dbcomp.journalseat AS js ON n.seat = js.seat
				JOIN section AS sec ON sec.id = s.section
				JOIN concept AS c ON c.id = n.concept
				JOIN dbcomp.account AS ac ON n.account = ac.id
				WHERE n.id = ?
				AND js.journal = ?;`
	} else {
		q = `SELECT n.id,n.seat,js.journal,n.account,n.company,n.concept,n.amount,n.dc,s.section,sec.title,c.title,s.seatdate,ac.title
				FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
				JOIN dbcomp.journalseat AS js ON js.seat = n.seat
				JOIN dbcomp.journal AS j ON j.id = js.journal
				JOIN ac_year AS a ON a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON n.company = p.company 
				JOIN section AS sec ON sec.id = s.section
				JOIN concept AS c ON c.id = n.concept
				JOIN dbcomp.account AS ac ON n.account = ac.id
				WHERE n.id = ?
				AND js.journal = ?
				AND p.user = ?
				AND a.opened = 1;`
	}
	rows, err := db.Query(q, id, journal, dni)
	if err != nil {
		return []SeatNoteEnc{}, err
	}
	defer rows.Close()
	notes := []SeatNoteEnc{}
	for rows.Next() {
		n := SeatNoteEnc{}
		rows.Scan(
			&n.ID,
			&n.Seat,
			&n.Journal,
			&n.Account,
			&n.Company,
			&n.Concept,
			&n.Amount,
			&n.DC,
			&n.Section,
			&n.TitleSection,
			&n.TitleConcept,
			&n.SeatDate,
			&n.TitleAccount,
		)
		notes = append(notes, n)
	}
	return notes, nil
}

//GetNoteParcialSeatJournal is the method to get all the notes by company of table Note
func GetNoteParcialSeatJournal(seat, journal int, role, dni string) ([]SeatNoteEnc, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT n.id,n.seat,js.journal,n.account,n.company,n.concept,n.amount,n.dc,s.section,sec.title,c.title,s.seatdate,ac.title
				FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
				JOIN dbcomp.journalseat AS js ON n.seat = js.seat
				JOIN section AS sec ON sec.id = s.section
				JOIN concept AS c ON c.id = n.concept
				JOIN dbcomp.account AS ac ON n.account = ac.id
				WHERE n.seat = ?
				AND js.journal = ?;`
	} else {
		q = `SELECT n.id,n.seat,js.journal,n.account,n.company,n.concept,n.amount,n.dc,s.section,sec.title,c.title,s.seatdate,ac.title
				FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
				JOIN dbcomp.journalseat AS js ON js.seat = n.seat
				JOIN dbcomp.journal AS j ON j.id = js.journal
				JOIN ac_year AS a ON a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON n.company = p.company 
				JOIN section AS sec ON sec.id = s.section
				JOIN concept AS c ON c.id = n.concept
				JOIN dbcomp.account AS ac ON n.account = ac.id
				WHERE n.seat = ?
				AND js.journal = ?
				AND p.user = ?
				AND a.opened = 1;`
	}
	rows, err := db.Query(q, seat, journal, dni)
	if err != nil {
		return []SeatNoteEnc{}, err
	}
	defer rows.Close()
	notes := []SeatNoteEnc{}
	for rows.Next() {
		n := SeatNoteEnc{}
		rows.Scan(
			&n.ID,
			&n.Seat,
			&n.Journal,
			&n.Account,
			&n.Company,
			&n.Concept,
			&n.Amount,
			&n.DC,
			&n.Section,
			&n.TitleSection,
			&n.TitleConcept,
			&n.SeatDate,
			&n.TitleAccount,
		)
		notes = append(notes, n)
	}
	return notes, nil
}

//GetNoteParcialIDAccountJournal is the method to get all the notes by ID of table Note
func GetNoteParcialIDAccountJournal(account, journal int, role, dni string) ([]SeatNoteEnc, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT n.id,n.seat,js.journal,n.account,n.company,n.concept,n.amount,n.dc,s.section,sec.title,c.title,s.seatdate,ac.title
				FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
				JOIN dbcomp.journalseat AS js ON n.seat = js.seat
				JOIN section AS sec ON sec.id = s.section
				JOIN concept AS c ON c.id = n.concept
				JOIN dbcomp.account AS ac ON n.account = ac.id
				WHERE n.account = ?
				AND js.journal = ?;`
	} else {
		q = `SELECT n.id,n.seat,js.journal,n.account,n.company,n.concept,n.amount,n.dc,s.section,sec.title,c.title,s.seatdate,ac.title
				FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
				JOIN dbcomp.journalseat AS js ON js.seat = n.seat
				JOIN dbcomp.journal AS j ON j.id = js.journal
				JOIN ac_year AS a ON a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON n.company = p.company 
				JOIN section AS sec ON sec.id = s.section
				JOIN concept AS c ON c.id = n.concept
				JOIN dbcomp.account AS ac ON n.account = ac.id
				WHERE n.account = ?
				AND js.journal = ?
				AND p.user = ?
				AND a.opened = 1;`
	}
	rows, err := db.Query(q, account, journal, dni)
	if err != nil {
		return []SeatNoteEnc{}, err
	}
	defer rows.Close()
	notes := []SeatNoteEnc{}
	for rows.Next() {
		n := SeatNoteEnc{}
		rows.Scan(
			&n.ID,
			&n.Seat,
			&n.Journal,
			&n.Account,
			&n.Company,
			&n.Concept,
			&n.Amount,
			&n.DC,
			&n.Section,
			&n.TitleSection,
			&n.TitleConcept,
			&n.SeatDate,
			&n.TitleAccount,
		)
		notes = append(notes, n)
	}
	return notes, nil
}
//UpdateNote Insert a new note with autoincrement id
func UpdateNote(n NoteEnc) error {

	db := GetConnection()
	q := `UPDATE dbcomp.note SET account = ?, company = ?,concept = ?,amount = ? ,dc = ?
            WHERE id = ? AND seat = ? ;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(n.Account, n.Company, n.Concept, n.Amount, n.DC, n.ID, n.Seat)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//DeleteNote Delete a note by id and seat
func DeleteNote(id, seat int) error {

	db := GetConnection()
	q := `DELETE FROM dbcomp.note
			WHERE id = ? AND seat = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(id, seat)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//GetCountSeatsOfNote is the method to get note of table Note by id
func GetCountSeatsOfNote(seat int, role, dni string) (int, error) {
	var count int

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT count(*)
		    	FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
				JOIN section AS sec ON sec.id = s.section
				JOIN concept AS c ON c.id = n.concept
				WHERE n.seat = ? ;`
	} else {
		q = `SELECT count(*)
				FROM dbcomp.note AS n JOIN dbcomp.seat AS s ON n.seat = s.id
				JOIN dbcomp.journalseat AS js ON js.seat = n.seat
				JOIN dbcomp.journal AS j ON j.id = js.journal
				JOIN ac_year AS a ON a.id = j.ac_year AND a.company = j.company
				JOIN permission AS p ON n.company = p.company 
				JOIN section AS sec ON sec.id = s.section
				JOIN concept AS c ON c.id = n.concept
				WHERE n.seat = ?
				AND p.user = ?
				AND a.opened = 1;`
	}

	row := db.QueryRow(q, seat, dni)

	err := row.Scan(
		&count,
	)

	if err != nil {
		return count, err
	}

	return count, nil
}
