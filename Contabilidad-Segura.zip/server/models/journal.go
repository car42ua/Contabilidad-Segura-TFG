package models

import (
	"database/sql"
	"errors"
	"fmt"

	_ "github.com/mutecomm/go-sqlcipher"
)

//JournalKey is the struct of the table journal
type JournalKey struct {
	Structure Journal
	Key       []byte
}

//Journal is the model of table Journal
type Journal struct {
	ID      int    `json:"id"`
	General int    `json:"general"`
	AcYear  int    `json:"ac_year"`
	Company int    `json:"company"`
	Title   string `json:"title"`
}

//CreateJournalTable is used to create Journal table when creating database for the first time
func CreateJournalTable(id int, key []byte) error {
	db := GetConnectionCompany(id, key)

	stmt, err :=
		db.Prepare(`CREATE TABLE journal(
						id INTEGER CONSTRAINT cpjournal PRIMARY KEY AUTOINCREMENT,
						general INTEGER(4),
						ac_year INTEGER(4) NOT NULL,
						company INTEGER(3) NOT NULL,
						title VARCHAR(20),
						CONSTRAINT fkjournal FOREIGN KEY (ac_year,company)REFERENCES ac_year(id,company),
						CONSTRAINT fkjournale FOREIGN KEY (general)REFERENCES journal(id)
					);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())

	} else {
		fmt.Println("Table journal created successfully..")
	}
	return err
}

//InsertJournal Insert a new journal with autoincrement id
func InsertJournal(j Journal) (int64, error) {

	db := GetConnection()
	q := `INSERT INTO dbcomp.journal (general, ac_year, company, title)
            VALUES(?, ?, ?, ?);`

	stmt, err := db.Prepare(q)
	if err != nil {
		return 0, err
	}

	defer stmt.Close()
	r, err := stmt.Exec(j.General, j.AcYear, j.Company, j.Title)

	if err != nil {
		return 0, err
	}

	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return 0, errors.New("ERROR: Se esperaba una fila afectada")
	}
	id, err := r.LastInsertId()

	if err != nil {
		return 0, err
	}

	return id, nil
}

//GetJournal is the method to get all de journals of table Journal
func GetJournal(role string, dni string) ([]Journal, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	id, general, ac_year, company, title
				FROM dbcomp.journal`
	} else {
		q = `SELECT j.id, j.general, j.ac_year, j.company, j.title	
				FROM dbcomp.journal AS j JOIN permission AS p on j.company = p.company
				WHERE p.user = ?;`
	}

	rows, err := db.Query(q, dni)
	if err != nil {
		return []Journal{}, err
	}
	defer rows.Close()
	journals := []Journal{}
	for rows.Next() {
		j := Journal{}
		rows.Scan(
			&j.ID,
			&j.General,
			&j.AcYear,
			&j.Company,
			&j.Title,
		)
		journals = append(journals, j)
	}
	return journals, nil
}

//GetJournalByID is the method to get all de journals of table Journal
func GetJournalByID(id int, role string, dni string) (Journal, error) {
	j := Journal{}

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	id, general, ac_year, company, title
				FROM dbcomp.journal
				WHERE id = ?`
	} else {
		q = `SELECT j.id, j.general, j.ac_year, j.company, j.title	
				FROM dbcomp.journal AS j JOIN permission AS p on j.company = p.company
				WHERE j.id= ?
				AND p.user = ?;`
	}

	row := db.QueryRow(q, id, dni)

	err := row.Scan(
		&j.ID,
		&j.General,
		&j.AcYear,
		&j.Company,
		&j.Title,
	)

	if err != nil {
		return j, err
	}

	return j, nil
}

//GetJournalByAcYear is the method to get all de journals of table Journal
func GetJournalByAcYear(acyear int, company int, role string, dni string) ([]Journal, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	id, general, ac_year, company, title
				FROM dbcomp.journal
				WHERE ac_year = ?
				AND company = ?`
	} else {
		q = `SELECT j.id, j.general, j.ac_year, j.company, j.title	
				FROM dbcomp.journal AS j JOIN permission AS p on j.company = p.company
				WHERE j.ac_year = ?
				AND j.company = ?
				AND p.user = ?;`
	}

	rows, err := db.Query(q, acyear, company, dni)
	if err != nil {
		return []Journal{}, err
	}
	defer rows.Close()
	journals := []Journal{}
	for rows.Next() {
		j := Journal{}
		rows.Scan(
			&j.ID,
			&j.General,
			&j.AcYear,
			&j.Company,
			&j.Title,
		)
		journals = append(journals, j)
	}
	return journals, nil
}

//UpdateJournal Insert a new journal with autoincrement id
func UpdateJournal(j Journal) error {

	db := GetConnection()
	q := `UPDATE dbcomp.journal SET   general = ?, ac_year = ?, company = ?, title = ?
            WHERE id = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(j.General, j.AcYear, j.Company, j.Title, j.ID)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//DeleteJournal Insert a new journal with autoincrement id
func DeleteJournal(id int) error {

	db := GetConnection()
	q := `DELETE FROM dbcomp.journal
            WHERE id = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(id)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//IsGeneralJournal check if journal is general or not.
func IsGeneralJournal(journal int) (bool, error) {
	result := true

	db := GetConnection()
	sqlStmt := `SELECT id FROM dbcomp.journal 
					WHERE id = ?
					AND general = 0;`

	err := db.QueryRow(sqlStmt, journal).Scan(&journal)
	if err != nil {
		result = false
		if err == sql.ErrNoRows {
			err = nil
		}
	}
	return result, nil
}
