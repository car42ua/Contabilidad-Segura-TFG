package models

//ResponseToken is struct of response token in string format
type ResponseToken struct {
	Ok    bool   `json:"ok"`
	Token string `json:"token"`
	Msg   string `json:"msg"`
}
