//Package models content the model of tables and CRUD method of all the tables
package models

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"fmt"
	"io/ioutil"
	"strconv"

	jwt "github.com/dgrijalva/jwt-go"
	_ "github.com/mutecomm/go-sqlcipher"
)

var db *sql.DB

//GetConnection make the connection with the DB
func GetConnection() *sql.DB {
	if db != nil {
		return db
	}
	var err error
	db, err = sql.Open("sqlite3", "./database.db?foreign_keys=on")
	if err != nil {
		panic(err)
	}
	return db
}

//GetConnectionCompany make the connection with the DB
func GetConnectionCompany(company int, keybyte []byte) *sql.DB {
	var dbcompany *sql.DB
	var err error
	fmt.Print("keybyte")
	fmt.Println(keybyte)
	//key := url.QueryEscape(string(keybyte))
	key := hex.EncodeToString(keybyte)
	fmt.Print("key en string")
	fmt.Println(key)

	dbname := fmt.Sprintf("./"+strconv.Itoa(company)+".db?_pragma_key=%s&_pragma_cipher_page_size=4096", key)
	dbcompany, err = sql.Open("sqlite3", dbname)
	if err != nil {
		panic(err)
	}

	return dbcompany
}

//DecryptKey use to decrypt the the key of db with de privatersa server key
func DecryptKey(content []byte) ([]byte, error) {

	privateBytes, err := ioutil.ReadFile("./autentication/privateKey.pem")
	if err != nil {
		fmt.Println("Error in read file!!!" + err.Error())
		panic(err)
	}
	privateKey, err := jwt.ParseRSAPrivateKeyFromPEM(privateBytes)
	if err != nil {
		fmt.Println("Error in parse file!!!" + err.Error())
		panic(err)
	}
	decryptedContent, err := rsa.DecryptOAEP(sha256.New(), rand.Reader, privateKey, content, nil)
	if err != nil {
		fmt.Println("Error in decrypt file!!!" + err.Error())
		panic(err)
	}

	return decryptedContent, nil
}

//AttachDatabase use for attach the body database with de particular company database
func AttachDatabase(key []byte, id int) error {

	keyD, err := DecryptKey(key)

	if err != nil {
		fmt.Println("Error in DecryptKey!!!" + err.Error())
		return err
	}
	db := GetConnection()

	//_, err = db.Exec("ATTACH DATABASE '" + strconv.Itoa(id) + ".db' AS dbcomp KEY '" + string(keyD) + "';")
	keyS := hex.EncodeToString(keyD)
	_, err = db.Exec("ATTACH DATABASE '" + strconv.Itoa(id) + ".db' AS dbcomp KEY '" + keyS + "';")

	if err != nil {
		fmt.Println("Error in Attach!!!" + err.Error())
		return err
	}
	//fmt.Println("Successfully attach database..")

	return nil
}

//DetachDatabase use for detach the body database with de particular company database
func DetachDatabase() error {
	db := GetConnection()
	_, err := db.Exec("DETACH DATABASE dbcomp;")
	if err != nil {
		fmt.Println(err.Error())
	}
	//fmt.Println("Successfully detach database..")

	return nil
}
