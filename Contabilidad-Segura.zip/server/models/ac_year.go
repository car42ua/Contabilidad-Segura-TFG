package models

import (
	"errors"
	"fmt"

	_ "github.com/mutecomm/go-sqlcipher"
)

//AcYearKey is the struct of the table ac_year
type AcYearKey struct {
	Structure AcYear
	Key       []byte
}

//AcYear is the struct of the table ac_year
type AcYear struct {
	ID        int    `json:"id"`
	Company   int    `json:"company"`
	OpenDate  string `json:"open_date"`
	CloseDate string `json:"close_date"`
	Opened    bool   `json:"opened"`
}

//CreateAcYearTable is used to create AcYear table when creating database for the first time
func CreateAcYearTable() error {
	db := GetConnection()

	stmt, err :=
		db.Prepare(`CREATE TABLE ac_year(
						id INTEGER(4),
						company INTEGER(3),
						open_date TEXT,
						close_date TEXT,
						opened BOOL,
						CONSTRAINT fkid FOREIGN KEY (company) REFERENCES company (id),
						CONSTRAINT cpac_year PRIMARY KEY(id,company)
					);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())

	} else {
		fmt.Println("Table created successfully..")
	}
	return err
}

//InsertAcYear Insert a new company with autoincrement id
func InsertAcYear(a AcYear) (int64, error) {

	db := GetConnection()

	q := `INSERT INTO ac_year (id,company,open_date,close_date,opened)
            VALUES(?, ?, ?, ?, ?);`

	stmt, err := db.Prepare(q)
	if err != nil {
		return 0, err
	}

	defer stmt.Close()

	r, err := stmt.Exec(a.ID, a.Company, a.OpenDate, a.CloseDate, a.Opened)
	if err != nil {
		return 0, err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return 0, errors.New("ERROR: Se esperaba una fila afectada")
	}
	id, err := r.LastInsertId()

	if err != nil {
		return 0, err
	}

	return id, nil
}

//GetAcYear is the method to get all de companies of table AcYear
func GetAcYear(role string, dni string) ([]AcYear, error) {
	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	id,company,open_date,close_date,opened
				FROM ac_year`
	} else {
		q = `SELECT a.id,a.company,a.open_date,a.close_date,a.opened
				FROM ac_year AS a JOIN permission AS p ON a.company = p.company
				WHERE p.user = ?
				AND a.opened = 1;`
	}

	rows, err := db.Query(q, dni)
	if err != nil {
		return []AcYear{}, err
	}
	defer rows.Close()
	acyears := []AcYear{}
	for rows.Next() {
		a := AcYear{}
		rows.Scan(
			&a.ID,
			&a.Company,
			&a.OpenDate,
			&a.CloseDate,
			&a.Opened,
		)
		acyears = append(acyears, a)
	}
	return acyears, nil
}

//GetAcYearByID is the method to get acyear of table AcYear by id
func GetAcYearByID(id int, company int, role string, dni string) (AcYear, error) {
	a := AcYear{}

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	id, company, open_date, close_date, opened
				FROM ac_year
				WHERE id = ? 
				AND company = ?`
	} else {
		q = `SELECT a.id, a.company, a.open_date, a.close_date, a.opened
				FROM acyear AS a JOIN permission AS p on a.company = p.company
				WHERE a.id = ? 
				AND a.company = ?
				AND p.user = ?;`
	}

	row := db.QueryRow(q, id, company, dni)

	err := row.Scan(
		&a.ID,
		&a.Company,
		&a.OpenDate,
		&a.CloseDate,
		&a.Opened,
	)

	if err != nil {
		return a, err
	}

	return a, nil
}

//GetAcYearParcialID is the method to get all de acyear of table AcYear
func GetAcYearParcialID(id int, role string, dni string) ([]AcYear, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	id, company, open_date, close_date, opened
				FROM ac_year
				WHERE id = ?;`
	} else {

		q = `SELECT a.id, a.company, a.open_date, a.close_date, a.opened	
				FROM ac_year AS a JOIN permission AS p on a.company = p.company
				WHERE a.id = ? 
				AND p.user = ?;`
	}
	rows, err := db.Query(q, id, dni)
	if err != nil {
		return []AcYear{}, err
	}
	defer rows.Close()
	acyears := []AcYear{}
	for rows.Next() {
		a := AcYear{}
		rows.Scan(
			&a.ID,
			&a.Company,
			&a.OpenDate,
			&a.CloseDate,
			&a.Opened,
		)
		acyears = append(acyears, a)
	}
	return acyears, nil
}

//GetAcYearParcialCompany is the method to get all de acyear of table AcYear
func GetAcYearParcialCompany(company int, role string, dni string) ([]AcYear, error) {

	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	id, company, open_date, close_date, opened
				FROM ac_year
				WHERE company = ?;`
	} else {

		q = `SELECT a.id, a.company, a.open_date, a.close_date, a.opened	
				FROM ac_year AS a JOIN permission AS p on a.company = p.company
				WHERE a.company = ? 
				AND p.user = ?;`
	}
	rows, err := db.Query(q, company, dni)
	if err != nil {
		return []AcYear{}, err
	}
	defer rows.Close()
	acyears := []AcYear{}
	for rows.Next() {
		a := AcYear{}
		rows.Scan(
			&a.ID,
			&a.Company,
			&a.OpenDate,
			&a.CloseDate,
			&a.Opened,
		)
		acyears = append(acyears, a)
	}
	return acyears, nil
}

//UpdateAcYear Insert a new acyear with autoincrement id
func UpdateAcYear(a AcYear) error {
	fmt.Print(a)
	db := GetConnection()
	q := `UPDATE ac_year SET open_date = ?, close_date = ?, opened = ?
            WHERE id = ? AND company = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(a.OpenDate, a.CloseDate, a.Opened, a.ID, a.Company)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//DeleteAcYear Insert a new AcYear with autoincrement id
func DeleteAcYear(id, company int) error {

	db := GetConnection()
	q := `DELETE FROM ac_year
            WHERE id = ? AND company = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(id, company)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}
