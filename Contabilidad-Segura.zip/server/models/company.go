package models

import (
	"errors"
	"fmt"

	_ "github.com/mutecomm/go-sqlcipher"
)

//CompanyAndKeys is the struct to use if the table need send the DatabaseKey
type CompanyAndKeys struct {
	Company    Company
	CompanyKey []byte
	DataKey    []byte
}

//Company is the struct of the table company
type Company struct {
	ID    int    `json:"id"`
	Title string `json:"title"`
	CIF   string `json:"cif"`
}

//CreateCompanyTable is used to create User table when creating database for the first time
func CreateCompanyTable() error {
	db := GetConnection()

	stmt, err :=
		db.Prepare(`CREATE TABLE company(
						id INTEGER CONSTRAINT cpcompany PRIMARY KEY AUTOINCREMENT,
						title VARCHAR(30),
						cif VARCHAR(9)
					);`)
	if err != nil {
		fmt.Println(err.Error())
	}

	_, err = stmt.Exec()
	if err != nil {
		fmt.Println(err.Error())
	} else {
		fmt.Println("Table created successfully..")
	}

	return err
}

//CreateTablesCompany is used to create all the tables of Journals for the parameter company
func CreateTablesCompany(id int, key []byte) error {

	err := CreateAutoIncrementalTables(id, key)
	if err != nil {
		panic(err)
	}
	err = CreateSectionTable(id, key)
	if err != nil {
		panic(err)
	}
	err = CreateConceptTable(id, key)
	if err != nil {
		panic(err)
	}
	err = CreateAccountTable(id, key)
	if err != nil {
		panic(err)
	}
	err = CreateJournalTable(id, key)
	if err != nil {
		panic(err)
	}
	err = CreateSeatTable(id, key)
	if err != nil {
		panic(err)
	}
	err = CreateNoteTable(id, key)
	if err != nil {
		panic(err)
	}
	err = CreateJournalSeatTable(id, key)
	if err != nil {
		panic(err)
	}

	return nil
}

//InsertCompany Insert a new company with autoincrement id
func InsertCompany(c Company) (int64, error) {

	db := GetConnection()
	q := `INSERT INTO company (title, cif)
            VALUES(?, ?);`

	stmt, err := db.Prepare(q)
	if err != nil {
		return 0, err
	}

	defer stmt.Close()

	r, err := stmt.Exec(c.Title, c.CIF)

	if err != nil {
		return 0, err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return 0, errors.New("ERROR: Se esperaba una fila afectada")
	}
	id, err := r.LastInsertId()

	if err != nil {
		return 0, err
	}

	return id, nil
}

//GetCompany is the method to get all de companies of table Company
func GetCompany(role string, dni string) ([]Company, error) {
	db := GetConnection()
	var q string

	if role == "admin" {
		q = `SELECT	id, title, CIF
				FROM company`
	} else {
		q = `SELECT c.id, c.title, c.CIF	
				FROM company AS c JOIN permission AS p ON c.id = p.company
				WHERE p.user = ?;`
	}

	rows, err := db.Query(q, dni)
	if err != nil {
		return []Company{}, err
	}
	defer rows.Close()
	companies := []Company{}
	for rows.Next() {
		c := Company{}
		rows.Scan(
			&c.ID,
			&c.Title,
			&c.CIF,
		)
		companies = append(companies, c)
	}
	return companies, nil
}

//GetCompanyByID is the method to get all de companies of table Company
func GetCompanyByID(id int, role string, dni string) (Company, error) {
	c := Company{}

	db := GetConnection()
	var q string

	if role == "admin" {

		q = `SELECT	id, title, CIF
				FROM company
				WHERE id = ?`
	} else {

		q = `SELECT c.id, c.title, c.CIF	
				FROM company AS c JOIN permission AS p on c.id = p.company
				WHERE p.company = ? 
				AND p.user = ?;`
	}

	row := db.QueryRow(q, id, dni)

	err := row.Scan(
		&c.ID,
		&c.Title,
		&c.CIF,
	)

	if err != nil {
		return c, err
	}

	return c, nil
}

//UpdateCompany Insert a new company with autoincrement id
func UpdateCompany(c Company) error {

	db := GetConnection()
	q := `UPDATE company SET   cif = ?,title = ? 
            WHERE id = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(c.CIF, c.Title, c.ID)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}

//DeleteCompany Insert a new company with autoincrement id
func DeleteCompany(id int) error {

	db := GetConnection()
	q := `DELETE FROM company
            WHERE id = ?;`

	stmt, err := db.Prepare(q)
	if err != nil {
		return err
	}

	defer stmt.Close()

	r, err := stmt.Exec(id)

	if err != nil {
		return err
	}
	if i, err := r.RowsAffected(); err != nil || i != 1 {
		return errors.New("ERROR: Se esperaba una fila afectada")
	}

	return nil
}
